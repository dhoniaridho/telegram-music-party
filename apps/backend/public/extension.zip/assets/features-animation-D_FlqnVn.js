import{b7 as e,e as a,g as n}from"../main.js";const s={renderer:n,...a,...e};export{s as d};
