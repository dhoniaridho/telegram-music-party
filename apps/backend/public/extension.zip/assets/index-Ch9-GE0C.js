import{d as o}from"./features-animation-D_FlqnVn.js";import"../main.js";import"./switchMap-BIOrVPpR.js";var m=o;export{m as default};
