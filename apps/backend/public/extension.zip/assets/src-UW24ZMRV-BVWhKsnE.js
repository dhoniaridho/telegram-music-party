import{d as a}from"./features-animation-D68NU6Dj.js";import"../main.js";var t=a;export{t as default};
