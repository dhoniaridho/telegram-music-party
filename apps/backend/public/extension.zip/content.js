(function(factory) {
  typeof define === "function" && define.amd ? define(factory) : factory();
})(function() {
  "use strict";var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", { value, configurable: true });

  var _a, _b, _c, _d, _e;
  var extendStatics = /* @__PURE__ */ __name(function(d, b) {
    extendStatics = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(d2, b2) {
      d2.__proto__ = b2;
    } || function(d2, b2) {
      for (var p in b2) if (Object.prototype.hasOwnProperty.call(b2, p)) d2[p] = b2[p];
    };
    return extendStatics(d, b);
  }, "extendStatics");
  function __extends(d, b) {
    if (typeof b !== "function" && b !== null)
      throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
    extendStatics(d, b);
    function __() {
      this.constructor = d;
    }
    __name(__, "__");
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }
  __name(__extends, "__extends");
  var __assign = /* @__PURE__ */ __name(function() {
    __assign = Object.assign || /* @__PURE__ */ __name(function __assign2(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];
        for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
      }
      return t;
    }, "__assign");
    return __assign.apply(this, arguments);
  }, "__assign");
  function __awaiter(thisArg, _arguments, P, generator) {
    function adopt(value2) {
      return value2 instanceof P ? value2 : new P(function(resolve) {
        resolve(value2);
      });
    }
    __name(adopt, "adopt");
    return new (P || (P = Promise))(function(resolve, reject) {
      function fulfilled(value2) {
        try {
          step(generator.next(value2));
        } catch (e) {
          reject(e);
        }
      }
      __name(fulfilled, "fulfilled");
      function rejected(value2) {
        try {
          step(generator["throw"](value2));
        } catch (e) {
          reject(e);
        }
      }
      __name(rejected, "rejected");
      function step(result) {
        result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected);
      }
      __name(step, "step");
      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  }
  __name(__awaiter, "__awaiter");
  function __generator(thisArg, body) {
    var _ = { label: 0, sent: /* @__PURE__ */ __name(function() {
      if (t[0] & 1) throw t[1];
      return t[1];
    }, "sent"), trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() {
      return this;
    }), g;
    function verb(n) {
      return function(v) {
        return step([n, v]);
      };
    }
    __name(verb, "verb");
    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");
      while (g && (g = 0, op[0] && (_ = 0)), _) try {
        if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
        if (y = 0, t) op = [op[0] & 2, t.value];
        switch (op[0]) {
          case 0:
          case 1:
            t = op;
            break;
          case 4:
            _.label++;
            return { value: op[1], done: false };
          case 5:
            _.label++;
            y = op[1];
            op = [0];
            continue;
          case 7:
            op = _.ops.pop();
            _.trys.pop();
            continue;
          default:
            if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
              _ = 0;
              continue;
            }
            if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
              _.label = op[1];
              break;
            }
            if (op[0] === 6 && _.label < t[1]) {
              _.label = t[1];
              t = op;
              break;
            }
            if (t && _.label < t[2]) {
              _.label = t[2];
              _.ops.push(op);
              break;
            }
            if (t[2]) _.ops.pop();
            _.trys.pop();
            continue;
        }
        op = body.call(thisArg, _);
      } catch (e) {
        op = [6, e];
        y = 0;
      } finally {
        f = t = 0;
      }
      if (op[0] & 5) throw op[1];
      return { value: op[0] ? op[1] : void 0, done: true };
    }
    __name(step, "step");
  }
  __name(__generator, "__generator");
  function __values(o) {
    var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
    if (m) return m.call(o);
    if (o && typeof o.length === "number") return {
      next: /* @__PURE__ */ __name(function() {
        if (o && i >= o.length) o = void 0;
        return { value: o && o[i++], done: !o };
      }, "next")
    };
    throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
  }
  __name(__values, "__values");
  function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o), r, ar = [], e;
    try {
      while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
    } catch (error) {
      e = { error };
    } finally {
      try {
        if (r && !r.done && (m = i["return"])) m.call(i);
      } finally {
        if (e) throw e.error;
      }
    }
    return ar;
  }
  __name(__read, "__read");
  function __spreadArray$1(to, from2, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from2.length, ar; i < l; i++) {
      if (ar || !(i in from2)) {
        if (!ar) ar = Array.prototype.slice.call(from2, 0, i);
        ar[i] = from2[i];
      }
    }
    return to.concat(ar || Array.prototype.slice.call(from2));
  }
  __name(__spreadArray$1, "__spreadArray$1");
  function __await(v) {
    return this instanceof __await ? (this.v = v, this) : new __await(v);
  }
  __name(__await, "__await");
  function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []), i, q = [];
    return i = Object.create((typeof AsyncIterator === "function" ? AsyncIterator : Object).prototype), verb("next"), verb("throw"), verb("return", awaitReturn), i[Symbol.asyncIterator] = function() {
      return this;
    }, i;
    function awaitReturn(f) {
      return function(v) {
        return Promise.resolve(v).then(f, reject);
      };
    }
    __name(awaitReturn, "awaitReturn");
    function verb(n, f) {
      if (g[n]) {
        i[n] = function(v) {
          return new Promise(function(a, b) {
            q.push([n, v, a, b]) > 1 || resume2(n, v);
          });
        };
        if (f) i[n] = f(i[n]);
      }
    }
    __name(verb, "verb");
    function resume2(n, v) {
      try {
        step(g[n](v));
      } catch (e) {
        settle2(q[0][3], e);
      }
    }
    __name(resume2, "resume");
    function step(r) {
      r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle2(q[0][2], r);
    }
    __name(step, "step");
    function fulfill(value2) {
      resume2("next", value2);
    }
    __name(fulfill, "fulfill");
    function reject(value2) {
      resume2("throw", value2);
    }
    __name(reject, "reject");
    function settle2(f, v) {
      if (f(v), q.shift(), q.length) resume2(q[0][0], q[0][1]);
    }
    __name(settle2, "settle");
  }
  __name(__asyncGenerator, "__asyncGenerator");
  function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator], i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function() {
      return this;
    }, i);
    function verb(n) {
      i[n] = o[n] && function(v) {
        return new Promise(function(resolve, reject) {
          v = o[n](v), settle2(resolve, reject, v.done, v.value);
        });
      };
    }
    __name(verb, "verb");
    function settle2(resolve, reject, d, v) {
      Promise.resolve(v).then(function(v2) {
        resolve({ value: v2, done: d });
      }, reject);
    }
    __name(settle2, "settle");
  }
  __name(__asyncValues, "__asyncValues");
  typeof SuppressedError === "function" ? SuppressedError : function(error, suppressed, message) {
    var e = new Error(message);
    return e.name = "SuppressedError", e.error = error, e.suppressed = suppressed, e;
  };
  function isFunction$1(value2) {
    return typeof value2 === "function";
  }
  __name(isFunction$1, "isFunction$1");
  function createErrorClass(createImpl) {
    var _super = /* @__PURE__ */ __name(function(instance) {
      Error.call(instance);
      instance.stack = new Error().stack;
    }, "_super");
    var ctorFunc = createImpl(_super);
    ctorFunc.prototype = Object.create(Error.prototype);
    ctorFunc.prototype.constructor = ctorFunc;
    return ctorFunc;
  }
  __name(createErrorClass, "createErrorClass");
  var UnsubscriptionError = createErrorClass(function(_super) {
    return /* @__PURE__ */ __name(function UnsubscriptionErrorImpl(errors) {
      _super(this);
      this.message = errors ? errors.length + " errors occurred during unsubscription:\n" + errors.map(function(err, i) {
        return i + 1 + ") " + err.toString();
      }).join("\n  ") : "";
      this.name = "UnsubscriptionError";
      this.errors = errors;
    }, "UnsubscriptionErrorImpl");
  });
  function arrRemove(arr, item) {
    if (arr) {
      var index = arr.indexOf(item);
      0 <= index && arr.splice(index, 1);
    }
  }
  __name(arrRemove, "arrRemove");
  var Subscription = function() {
    function Subscription2(initialTeardown) {
      this.initialTeardown = initialTeardown;
      this.closed = false;
      this._parentage = null;
      this._finalizers = null;
    }
    __name(Subscription2, "Subscription");
    Subscription2.prototype.unsubscribe = function() {
      var e_1, _a2, e_2, _b2;
      var errors;
      if (!this.closed) {
        this.closed = true;
        var _parentage = this._parentage;
        if (_parentage) {
          this._parentage = null;
          if (Array.isArray(_parentage)) {
            try {
              for (var _parentage_1 = __values(_parentage), _parentage_1_1 = _parentage_1.next(); !_parentage_1_1.done; _parentage_1_1 = _parentage_1.next()) {
                var parent_1 = _parentage_1_1.value;
                parent_1.remove(this);
              }
            } catch (e_1_1) {
              e_1 = { error: e_1_1 };
            } finally {
              try {
                if (_parentage_1_1 && !_parentage_1_1.done && (_a2 = _parentage_1.return)) _a2.call(_parentage_1);
              } finally {
                if (e_1) throw e_1.error;
              }
            }
          } else {
            _parentage.remove(this);
          }
        }
        var initialFinalizer = this.initialTeardown;
        if (isFunction$1(initialFinalizer)) {
          try {
            initialFinalizer();
          } catch (e) {
            errors = e instanceof UnsubscriptionError ? e.errors : [e];
          }
        }
        var _finalizers = this._finalizers;
        if (_finalizers) {
          this._finalizers = null;
          try {
            for (var _finalizers_1 = __values(_finalizers), _finalizers_1_1 = _finalizers_1.next(); !_finalizers_1_1.done; _finalizers_1_1 = _finalizers_1.next()) {
              var finalizer = _finalizers_1_1.value;
              try {
                execFinalizer(finalizer);
              } catch (err) {
                errors = errors !== null && errors !== void 0 ? errors : [];
                if (err instanceof UnsubscriptionError) {
                  errors = __spreadArray$1(__spreadArray$1([], __read(errors)), __read(err.errors));
                } else {
                  errors.push(err);
                }
              }
            }
          } catch (e_2_1) {
            e_2 = { error: e_2_1 };
          } finally {
            try {
              if (_finalizers_1_1 && !_finalizers_1_1.done && (_b2 = _finalizers_1.return)) _b2.call(_finalizers_1);
            } finally {
              if (e_2) throw e_2.error;
            }
          }
        }
        if (errors) {
          throw new UnsubscriptionError(errors);
        }
      }
    };
    Subscription2.prototype.add = function(teardown) {
      var _a2;
      if (teardown && teardown !== this) {
        if (this.closed) {
          execFinalizer(teardown);
        } else {
          if (teardown instanceof Subscription2) {
            if (teardown.closed || teardown._hasParent(this)) {
              return;
            }
            teardown._addParent(this);
          }
          (this._finalizers = (_a2 = this._finalizers) !== null && _a2 !== void 0 ? _a2 : []).push(teardown);
        }
      }
    };
    Subscription2.prototype._hasParent = function(parent) {
      var _parentage = this._parentage;
      return _parentage === parent || Array.isArray(_parentage) && _parentage.includes(parent);
    };
    Subscription2.prototype._addParent = function(parent) {
      var _parentage = this._parentage;
      this._parentage = Array.isArray(_parentage) ? (_parentage.push(parent), _parentage) : _parentage ? [_parentage, parent] : parent;
    };
    Subscription2.prototype._removeParent = function(parent) {
      var _parentage = this._parentage;
      if (_parentage === parent) {
        this._parentage = null;
      } else if (Array.isArray(_parentage)) {
        arrRemove(_parentage, parent);
      }
    };
    Subscription2.prototype.remove = function(teardown) {
      var _finalizers = this._finalizers;
      _finalizers && arrRemove(_finalizers, teardown);
      if (teardown instanceof Subscription2) {
        teardown._removeParent(this);
      }
    };
    Subscription2.EMPTY = function() {
      var empty2 = new Subscription2();
      empty2.closed = true;
      return empty2;
    }();
    return Subscription2;
  }();
  Subscription.EMPTY;
  function isSubscription(value2) {
    return value2 instanceof Subscription || value2 && "closed" in value2 && isFunction$1(value2.remove) && isFunction$1(value2.add) && isFunction$1(value2.unsubscribe);
  }
  __name(isSubscription, "isSubscription");
  function execFinalizer(finalizer) {
    if (isFunction$1(finalizer)) {
      finalizer();
    } else {
      finalizer.unsubscribe();
    }
  }
  __name(execFinalizer, "execFinalizer");
  var config = {
    Promise: void 0
  };
  var timeoutProvider = {
    setTimeout: /* @__PURE__ */ __name(function(handler, timeout) {
      var args = [];
      for (var _i = 2; _i < arguments.length; _i++) {
        args[_i - 2] = arguments[_i];
      }
      return setTimeout.apply(void 0, __spreadArray$1([handler, timeout], __read(args)));
    }, "setTimeout"),
    clearTimeout: /* @__PURE__ */ __name(function(handle) {
      return clearTimeout(handle);
    }, "clearTimeout"),
    delegate: void 0
  };
  function reportUnhandledError(err) {
    timeoutProvider.setTimeout(function() {
      {
        throw err;
      }
    });
  }
  __name(reportUnhandledError, "reportUnhandledError");
  function noop$1() {
  }
  __name(noop$1, "noop$1");
  function errorContext(cb) {
    {
      cb();
    }
  }
  __name(errorContext, "errorContext");
  var Subscriber = function(_super) {
    __extends(Subscriber2, _super);
    function Subscriber2(destination) {
      var _this = _super.call(this) || this;
      _this.isStopped = false;
      if (destination) {
        _this.destination = destination;
        if (isSubscription(destination)) {
          destination.add(_this);
        }
      } else {
        _this.destination = EMPTY_OBSERVER;
      }
      return _this;
    }
    __name(Subscriber2, "Subscriber");
    Subscriber2.create = function(next2, error, complete) {
      return new SafeSubscriber(next2, error, complete);
    };
    Subscriber2.prototype.next = function(value2) {
      if (this.isStopped) ;
      else {
        this._next(value2);
      }
    };
    Subscriber2.prototype.error = function(err) {
      if (this.isStopped) ;
      else {
        this.isStopped = true;
        this._error(err);
      }
    };
    Subscriber2.prototype.complete = function() {
      if (this.isStopped) ;
      else {
        this.isStopped = true;
        this._complete();
      }
    };
    Subscriber2.prototype.unsubscribe = function() {
      if (!this.closed) {
        this.isStopped = true;
        _super.prototype.unsubscribe.call(this);
        this.destination = null;
      }
    };
    Subscriber2.prototype._next = function(value2) {
      this.destination.next(value2);
    };
    Subscriber2.prototype._error = function(err) {
      try {
        this.destination.error(err);
      } finally {
        this.unsubscribe();
      }
    };
    Subscriber2.prototype._complete = function() {
      try {
        this.destination.complete();
      } finally {
        this.unsubscribe();
      }
    };
    return Subscriber2;
  }(Subscription);
  var ConsumerObserver = function() {
    function ConsumerObserver2(partialObserver) {
      this.partialObserver = partialObserver;
    }
    __name(ConsumerObserver2, "ConsumerObserver");
    ConsumerObserver2.prototype.next = function(value2) {
      var partialObserver = this.partialObserver;
      if (partialObserver.next) {
        try {
          partialObserver.next(value2);
        } catch (error) {
          handleUnhandledError(error);
        }
      }
    };
    ConsumerObserver2.prototype.error = function(err) {
      var partialObserver = this.partialObserver;
      if (partialObserver.error) {
        try {
          partialObserver.error(err);
        } catch (error) {
          handleUnhandledError(error);
        }
      } else {
        handleUnhandledError(err);
      }
    };
    ConsumerObserver2.prototype.complete = function() {
      var partialObserver = this.partialObserver;
      if (partialObserver.complete) {
        try {
          partialObserver.complete();
        } catch (error) {
          handleUnhandledError(error);
        }
      }
    };
    return ConsumerObserver2;
  }();
  var SafeSubscriber = function(_super) {
    __extends(SafeSubscriber2, _super);
    function SafeSubscriber2(observerOrNext, error, complete) {
      var _this = _super.call(this) || this;
      var partialObserver;
      if (isFunction$1(observerOrNext) || !observerOrNext) {
        partialObserver = {
          next: observerOrNext !== null && observerOrNext !== void 0 ? observerOrNext : void 0,
          error: error !== null && error !== void 0 ? error : void 0,
          complete: complete !== null && complete !== void 0 ? complete : void 0
        };
      } else {
        {
          partialObserver = observerOrNext;
        }
      }
      _this.destination = new ConsumerObserver(partialObserver);
      return _this;
    }
    __name(SafeSubscriber2, "SafeSubscriber");
    return SafeSubscriber2;
  }(Subscriber);
  function handleUnhandledError(error) {
    {
      reportUnhandledError(error);
    }
  }
  __name(handleUnhandledError, "handleUnhandledError");
  function defaultErrorHandler(err) {
    throw err;
  }
  __name(defaultErrorHandler, "defaultErrorHandler");
  var EMPTY_OBSERVER = {
    closed: true,
    next: noop$1,
    error: defaultErrorHandler,
    complete: noop$1
  };
  var observable = function() {
    return typeof Symbol === "function" && Symbol.observable || "@@observable";
  }();
  function identity(x) {
    return x;
  }
  __name(identity, "identity");
  function pipeFromArray(fns) {
    if (fns.length === 0) {
      return identity;
    }
    if (fns.length === 1) {
      return fns[0];
    }
    return /* @__PURE__ */ __name(function piped(input) {
      return fns.reduce(function(prev2, fn) {
        return fn(prev2);
      }, input);
    }, "piped");
  }
  __name(pipeFromArray, "pipeFromArray");
  var Observable = function() {
    function Observable2(subscribe) {
      if (subscribe) {
        this._subscribe = subscribe;
      }
    }
    __name(Observable2, "Observable");
    Observable2.prototype.lift = function(operator) {
      var observable2 = new Observable2();
      observable2.source = this;
      observable2.operator = operator;
      return observable2;
    };
    Observable2.prototype.subscribe = function(observerOrNext, error, complete) {
      var _this = this;
      var subscriber = isSubscriber(observerOrNext) ? observerOrNext : new SafeSubscriber(observerOrNext, error, complete);
      errorContext(function() {
        var _a2 = _this, operator = _a2.operator, source = _a2.source;
        subscriber.add(operator ? operator.call(subscriber, source) : source ? _this._subscribe(subscriber) : _this._trySubscribe(subscriber));
      });
      return subscriber;
    };
    Observable2.prototype._trySubscribe = function(sink) {
      try {
        return this._subscribe(sink);
      } catch (err) {
        sink.error(err);
      }
    };
    Observable2.prototype.forEach = function(next2, promiseCtor) {
      var _this = this;
      promiseCtor = getPromiseCtor(promiseCtor);
      return new promiseCtor(function(resolve, reject) {
        var subscriber = new SafeSubscriber({
          next: /* @__PURE__ */ __name(function(value2) {
            try {
              next2(value2);
            } catch (err) {
              reject(err);
              subscriber.unsubscribe();
            }
          }, "next"),
          error: reject,
          complete: resolve
        });
        _this.subscribe(subscriber);
      });
    };
    Observable2.prototype._subscribe = function(subscriber) {
      var _a2;
      return (_a2 = this.source) === null || _a2 === void 0 ? void 0 : _a2.subscribe(subscriber);
    };
    Observable2.prototype[observable] = function() {
      return this;
    };
    Observable2.prototype.pipe = function() {
      var operations = [];
      for (var _i = 0; _i < arguments.length; _i++) {
        operations[_i] = arguments[_i];
      }
      return pipeFromArray(operations)(this);
    };
    Observable2.prototype.toPromise = function(promiseCtor) {
      var _this = this;
      promiseCtor = getPromiseCtor(promiseCtor);
      return new promiseCtor(function(resolve, reject) {
        var value2;
        _this.subscribe(function(x) {
          return value2 = x;
        }, function(err) {
          return reject(err);
        }, function() {
          return resolve(value2);
        });
      });
    };
    Observable2.create = function(subscribe) {
      return new Observable2(subscribe);
    };
    return Observable2;
  }();
  function getPromiseCtor(promiseCtor) {
    var _a2;
    return (_a2 = promiseCtor !== null && promiseCtor !== void 0 ? promiseCtor : config.Promise) !== null && _a2 !== void 0 ? _a2 : Promise;
  }
  __name(getPromiseCtor, "getPromiseCtor");
  function isObserver(value2) {
    return value2 && isFunction$1(value2.next) && isFunction$1(value2.error) && isFunction$1(value2.complete);
  }
  __name(isObserver, "isObserver");
  function isSubscriber(value2) {
    return value2 && value2 instanceof Subscriber || isObserver(value2) && isSubscription(value2);
  }
  __name(isSubscriber, "isSubscriber");
  function hasLift(source) {
    return isFunction$1(source === null || source === void 0 ? void 0 : source.lift);
  }
  __name(hasLift, "hasLift");
  function operate(init) {
    return function(source) {
      if (hasLift(source)) {
        return source.lift(function(liftedSource) {
          try {
            return init(liftedSource, this);
          } catch (err) {
            this.error(err);
          }
        });
      }
      throw new TypeError("Unable to lift unknown Observable type");
    };
  }
  __name(operate, "operate");
  function createOperatorSubscriber(destination, onNext, onComplete, onError, onFinalize) {
    return new OperatorSubscriber(destination, onNext, onComplete, onError, onFinalize);
  }
  __name(createOperatorSubscriber, "createOperatorSubscriber");
  var OperatorSubscriber = function(_super) {
    __extends(OperatorSubscriber2, _super);
    function OperatorSubscriber2(destination, onNext, onComplete, onError, onFinalize, shouldUnsubscribe) {
      var _this = _super.call(this, destination) || this;
      _this.onFinalize = onFinalize;
      _this.shouldUnsubscribe = shouldUnsubscribe;
      _this._next = onNext ? function(value2) {
        try {
          onNext(value2);
        } catch (err) {
          destination.error(err);
        }
      } : _super.prototype._next;
      _this._error = onError ? function(err) {
        try {
          onError(err);
        } catch (err2) {
          destination.error(err2);
        } finally {
          this.unsubscribe();
        }
      } : _super.prototype._error;
      _this._complete = onComplete ? function() {
        try {
          onComplete();
        } catch (err) {
          destination.error(err);
        } finally {
          this.unsubscribe();
        }
      } : _super.prototype._complete;
      return _this;
    }
    __name(OperatorSubscriber2, "OperatorSubscriber");
    OperatorSubscriber2.prototype.unsubscribe = function() {
      var _a2;
      if (!this.shouldUnsubscribe || this.shouldUnsubscribe()) {
        var closed_1 = this.closed;
        _super.prototype.unsubscribe.call(this);
        !closed_1 && ((_a2 = this.onFinalize) === null || _a2 === void 0 ? void 0 : _a2.call(this));
      }
    };
    return OperatorSubscriber2;
  }(Subscriber);
  var isArrayLike = /* @__PURE__ */ __name(function(x) {
    return x && typeof x.length === "number" && typeof x !== "function";
  }, "isArrayLike");
  function isPromise$1(value2) {
    return isFunction$1(value2 === null || value2 === void 0 ? void 0 : value2.then);
  }
  __name(isPromise$1, "isPromise$1");
  function isInteropObservable(input) {
    return isFunction$1(input[observable]);
  }
  __name(isInteropObservable, "isInteropObservable");
  function isAsyncIterable(obj) {
    return Symbol.asyncIterator && isFunction$1(obj === null || obj === void 0 ? void 0 : obj[Symbol.asyncIterator]);
  }
  __name(isAsyncIterable, "isAsyncIterable");
  function createInvalidObservableTypeError(input) {
    return new TypeError("You provided " + (input !== null && typeof input === "object" ? "an invalid object" : "'" + input + "'") + " where a stream was expected. You can provide an Observable, Promise, ReadableStream, Array, AsyncIterable, or Iterable.");
  }
  __name(createInvalidObservableTypeError, "createInvalidObservableTypeError");
  function getSymbolIterator() {
    if (typeof Symbol !== "function" || !Symbol.iterator) {
      return "@@iterator";
    }
    return Symbol.iterator;
  }
  __name(getSymbolIterator, "getSymbolIterator");
  var iterator = getSymbolIterator();
  function isIterable(input) {
    return isFunction$1(input === null || input === void 0 ? void 0 : input[iterator]);
  }
  __name(isIterable, "isIterable");
  function readableStreamLikeToAsyncGenerator(readableStream) {
    return __asyncGenerator(this, arguments, /* @__PURE__ */ __name(function readableStreamLikeToAsyncGenerator_1() {
      var reader, _a2, value2, done;
      return __generator(this, function(_b2) {
        switch (_b2.label) {
          case 0:
            reader = readableStream.getReader();
            _b2.label = 1;
          case 1:
            _b2.trys.push([1, , 9, 10]);
            _b2.label = 2;
          case 2:
            return [4, __await(reader.read())];
          case 3:
            _a2 = _b2.sent(), value2 = _a2.value, done = _a2.done;
            if (!done) return [3, 5];
            return [4, __await(void 0)];
          case 4:
            return [2, _b2.sent()];
          case 5:
            return [4, __await(value2)];
          case 6:
            return [4, _b2.sent()];
          case 7:
            _b2.sent();
            return [3, 2];
          case 8:
            return [3, 10];
          case 9:
            reader.releaseLock();
            return [7];
          case 10:
            return [2];
        }
      });
    }, "readableStreamLikeToAsyncGenerator_1"));
  }
  __name(readableStreamLikeToAsyncGenerator, "readableStreamLikeToAsyncGenerator");
  function isReadableStreamLike(obj) {
    return isFunction$1(obj === null || obj === void 0 ? void 0 : obj.getReader);
  }
  __name(isReadableStreamLike, "isReadableStreamLike");
  function innerFrom(input) {
    if (input instanceof Observable) {
      return input;
    }
    if (input != null) {
      if (isInteropObservable(input)) {
        return fromInteropObservable(input);
      }
      if (isArrayLike(input)) {
        return fromArrayLike(input);
      }
      if (isPromise$1(input)) {
        return fromPromise(input);
      }
      if (isAsyncIterable(input)) {
        return fromAsyncIterable(input);
      }
      if (isIterable(input)) {
        return fromIterable(input);
      }
      if (isReadableStreamLike(input)) {
        return fromReadableStreamLike(input);
      }
    }
    throw createInvalidObservableTypeError(input);
  }
  __name(innerFrom, "innerFrom");
  function fromInteropObservable(obj) {
    return new Observable(function(subscriber) {
      var obs = obj[observable]();
      if (isFunction$1(obs.subscribe)) {
        return obs.subscribe(subscriber);
      }
      throw new TypeError("Provided object does not correctly implement Symbol.observable");
    });
  }
  __name(fromInteropObservable, "fromInteropObservable");
  function fromArrayLike(array) {
    return new Observable(function(subscriber) {
      for (var i = 0; i < array.length && !subscriber.closed; i++) {
        subscriber.next(array[i]);
      }
      subscriber.complete();
    });
  }
  __name(fromArrayLike, "fromArrayLike");
  function fromPromise(promise) {
    return new Observable(function(subscriber) {
      promise.then(function(value2) {
        if (!subscriber.closed) {
          subscriber.next(value2);
          subscriber.complete();
        }
      }, function(err) {
        return subscriber.error(err);
      }).then(null, reportUnhandledError);
    });
  }
  __name(fromPromise, "fromPromise");
  function fromIterable(iterable) {
    return new Observable(function(subscriber) {
      var e_1, _a2;
      try {
        for (var iterable_1 = __values(iterable), iterable_1_1 = iterable_1.next(); !iterable_1_1.done; iterable_1_1 = iterable_1.next()) {
          var value2 = iterable_1_1.value;
          subscriber.next(value2);
          if (subscriber.closed) {
            return;
          }
        }
      } catch (e_1_1) {
        e_1 = { error: e_1_1 };
      } finally {
        try {
          if (iterable_1_1 && !iterable_1_1.done && (_a2 = iterable_1.return)) _a2.call(iterable_1);
        } finally {
          if (e_1) throw e_1.error;
        }
      }
      subscriber.complete();
    });
  }
  __name(fromIterable, "fromIterable");
  function fromAsyncIterable(asyncIterable) {
    return new Observable(function(subscriber) {
      process$1(asyncIterable, subscriber).catch(function(err) {
        return subscriber.error(err);
      });
    });
  }
  __name(fromAsyncIterable, "fromAsyncIterable");
  function fromReadableStreamLike(readableStream) {
    return fromAsyncIterable(readableStreamLikeToAsyncGenerator(readableStream));
  }
  __name(fromReadableStreamLike, "fromReadableStreamLike");
  function process$1(asyncIterable, subscriber) {
    var asyncIterable_1, asyncIterable_1_1;
    var e_2, _a2;
    return __awaiter(this, void 0, void 0, function() {
      var value2, e_2_1;
      return __generator(this, function(_b2) {
        switch (_b2.label) {
          case 0:
            _b2.trys.push([0, 5, 6, 11]);
            asyncIterable_1 = __asyncValues(asyncIterable);
            _b2.label = 1;
          case 1:
            return [4, asyncIterable_1.next()];
          case 2:
            if (!(asyncIterable_1_1 = _b2.sent(), !asyncIterable_1_1.done)) return [3, 4];
            value2 = asyncIterable_1_1.value;
            subscriber.next(value2);
            if (subscriber.closed) {
              return [2];
            }
            _b2.label = 3;
          case 3:
            return [3, 1];
          case 4:
            return [3, 11];
          case 5:
            e_2_1 = _b2.sent();
            e_2 = { error: e_2_1 };
            return [3, 11];
          case 6:
            _b2.trys.push([6, , 9, 10]);
            if (!(asyncIterable_1_1 && !asyncIterable_1_1.done && (_a2 = asyncIterable_1.return))) return [3, 8];
            return [4, _a2.call(asyncIterable_1)];
          case 7:
            _b2.sent();
            _b2.label = 8;
          case 8:
            return [3, 10];
          case 9:
            if (e_2) throw e_2.error;
            return [7];
          case 10:
            return [7];
          case 11:
            subscriber.complete();
            return [2];
        }
      });
    });
  }
  __name(process$1, "process$1");
  function executeSchedule(parentSubscription, scheduler, work, delay, repeat) {
    if (delay === void 0) {
      delay = 0;
    }
    if (repeat === void 0) {
      repeat = false;
    }
    var scheduleSubscription = scheduler.schedule(function() {
      work();
      if (repeat) {
        parentSubscription.add(this.schedule(null, delay));
      } else {
        this.unsubscribe();
      }
    }, delay);
    parentSubscription.add(scheduleSubscription);
    if (!repeat) {
      return scheduleSubscription;
    }
  }
  __name(executeSchedule, "executeSchedule");
  function observeOn(scheduler, delay) {
    if (delay === void 0) {
      delay = 0;
    }
    return operate(function(source, subscriber) {
      source.subscribe(createOperatorSubscriber(subscriber, function(value2) {
        return executeSchedule(subscriber, scheduler, function() {
          return subscriber.next(value2);
        }, delay);
      }, function() {
        return executeSchedule(subscriber, scheduler, function() {
          return subscriber.complete();
        }, delay);
      }, function(err) {
        return executeSchedule(subscriber, scheduler, function() {
          return subscriber.error(err);
        }, delay);
      }));
    });
  }
  __name(observeOn, "observeOn");
  function subscribeOn(scheduler, delay) {
    if (delay === void 0) {
      delay = 0;
    }
    return operate(function(source, subscriber) {
      subscriber.add(scheduler.schedule(function() {
        return source.subscribe(subscriber);
      }, delay));
    });
  }
  __name(subscribeOn, "subscribeOn");
  function scheduleObservable(input, scheduler) {
    return innerFrom(input).pipe(subscribeOn(scheduler), observeOn(scheduler));
  }
  __name(scheduleObservable, "scheduleObservable");
  function schedulePromise(input, scheduler) {
    return innerFrom(input).pipe(subscribeOn(scheduler), observeOn(scheduler));
  }
  __name(schedulePromise, "schedulePromise");
  function scheduleArray(input, scheduler) {
    return new Observable(function(subscriber) {
      var i = 0;
      return scheduler.schedule(function() {
        if (i === input.length) {
          subscriber.complete();
        } else {
          subscriber.next(input[i++]);
          if (!subscriber.closed) {
            this.schedule();
          }
        }
      });
    });
  }
  __name(scheduleArray, "scheduleArray");
  function scheduleIterable(input, scheduler) {
    return new Observable(function(subscriber) {
      var iterator$1;
      executeSchedule(subscriber, scheduler, function() {
        iterator$1 = input[iterator]();
        executeSchedule(subscriber, scheduler, function() {
          var _a2;
          var value2;
          var done;
          try {
            _a2 = iterator$1.next(), value2 = _a2.value, done = _a2.done;
          } catch (err) {
            subscriber.error(err);
            return;
          }
          if (done) {
            subscriber.complete();
          } else {
            subscriber.next(value2);
          }
        }, 0, true);
      });
      return function() {
        return isFunction$1(iterator$1 === null || iterator$1 === void 0 ? void 0 : iterator$1.return) && iterator$1.return();
      };
    });
  }
  __name(scheduleIterable, "scheduleIterable");
  function scheduleAsyncIterable(input, scheduler) {
    if (!input) {
      throw new Error("Iterable cannot be null");
    }
    return new Observable(function(subscriber) {
      executeSchedule(subscriber, scheduler, function() {
        var iterator2 = input[Symbol.asyncIterator]();
        executeSchedule(subscriber, scheduler, function() {
          iterator2.next().then(function(result) {
            if (result.done) {
              subscriber.complete();
            } else {
              subscriber.next(result.value);
            }
          });
        }, 0, true);
      });
    });
  }
  __name(scheduleAsyncIterable, "scheduleAsyncIterable");
  function scheduleReadableStreamLike(input, scheduler) {
    return scheduleAsyncIterable(readableStreamLikeToAsyncGenerator(input), scheduler);
  }
  __name(scheduleReadableStreamLike, "scheduleReadableStreamLike");
  function scheduled(input, scheduler) {
    if (input != null) {
      if (isInteropObservable(input)) {
        return scheduleObservable(input, scheduler);
      }
      if (isArrayLike(input)) {
        return scheduleArray(input, scheduler);
      }
      if (isPromise$1(input)) {
        return schedulePromise(input, scheduler);
      }
      if (isAsyncIterable(input)) {
        return scheduleAsyncIterable(input, scheduler);
      }
      if (isIterable(input)) {
        return scheduleIterable(input, scheduler);
      }
      if (isReadableStreamLike(input)) {
        return scheduleReadableStreamLike(input, scheduler);
      }
    }
    throw createInvalidObservableTypeError(input);
  }
  __name(scheduled, "scheduled");
  function from(input, scheduler) {
    return scheduler ? scheduled(input, scheduler) : innerFrom(input);
  }
  __name(from, "from");
  var EmptyError = createErrorClass(function(_super) {
    return /* @__PURE__ */ __name(function EmptyErrorImpl() {
      _super(this);
      this.name = "EmptyError";
      this.message = "no elements in sequence";
    }, "EmptyErrorImpl");
  });
  function firstValueFrom(source, config2) {
    return new Promise(function(resolve, reject) {
      var subscriber = new SafeSubscriber({
        next: /* @__PURE__ */ __name(function(value2) {
          resolve(value2);
          subscriber.unsubscribe();
        }, "next"),
        error: reject,
        complete: /* @__PURE__ */ __name(function() {
          {
            reject(new EmptyError());
          }
        }, "complete")
      });
      source.subscribe(subscriber);
    });
  }
  __name(firstValueFrom, "firstValueFrom");
  function switchMap(project, resultSelector) {
    return operate(function(source, subscriber) {
      var innerSubscriber = null;
      var index = 0;
      var isComplete = false;
      var checkComplete = /* @__PURE__ */ __name(function() {
        return isComplete && !innerSubscriber && subscriber.complete();
      }, "checkComplete");
      source.subscribe(createOperatorSubscriber(subscriber, function(value2) {
        innerSubscriber === null || innerSubscriber === void 0 ? void 0 : innerSubscriber.unsubscribe();
        var innerIndex = 0;
        var outerIndex = index++;
        innerFrom(project(value2, outerIndex)).subscribe(innerSubscriber = createOperatorSubscriber(subscriber, function(innerValue) {
          return subscriber.next(resultSelector ? resultSelector(value2, innerValue, outerIndex, innerIndex++) : innerValue);
        }, function() {
          innerSubscriber = null;
          checkComplete();
        }));
      }, function() {
        isComplete = true;
        checkComplete();
      }));
    });
  }
  __name(switchMap, "switchMap");
  function tap(observerOrNext, error, complete) {
    var tapObserver = isFunction$1(observerOrNext) || error || complete ? { next: observerOrNext, error, complete } : observerOrNext;
    return tapObserver ? operate(function(source, subscriber) {
      var _a2;
      (_a2 = tapObserver.subscribe) === null || _a2 === void 0 ? void 0 : _a2.call(tapObserver);
      var isUnsub = true;
      source.subscribe(createOperatorSubscriber(subscriber, function(value2) {
        var _a3;
        (_a3 = tapObserver.next) === null || _a3 === void 0 ? void 0 : _a3.call(tapObserver, value2);
        subscriber.next(value2);
      }, function() {
        var _a3;
        isUnsub = false;
        (_a3 = tapObserver.complete) === null || _a3 === void 0 ? void 0 : _a3.call(tapObserver);
        subscriber.complete();
      }, function(err) {
        var _a3;
        isUnsub = false;
        (_a3 = tapObserver.error) === null || _a3 === void 0 ? void 0 : _a3.call(tapObserver, err);
        subscriber.error(err);
      }, function() {
        var _a3, _b2;
        if (isUnsub) {
          (_a3 = tapObserver.unsubscribe) === null || _a3 === void 0 ? void 0 : _a3.call(tapObserver);
        }
        (_b2 = tapObserver.finalize) === null || _b2 === void 0 ? void 0 : _b2.call(tapObserver);
      }));
    }) : identity;
  }
  __name(tap, "tap");
  const PACKET_TYPES = /* @__PURE__ */ Object.create(null);
  PACKET_TYPES["open"] = "0";
  PACKET_TYPES["close"] = "1";
  PACKET_TYPES["ping"] = "2";
  PACKET_TYPES["pong"] = "3";
  PACKET_TYPES["message"] = "4";
  PACKET_TYPES["upgrade"] = "5";
  PACKET_TYPES["noop"] = "6";
  const PACKET_TYPES_REVERSE = /* @__PURE__ */ Object.create(null);
  Object.keys(PACKET_TYPES).forEach((key) => {
    PACKET_TYPES_REVERSE[PACKET_TYPES[key]] = key;
  });
  const ERROR_PACKET = { type: "error", data: "parser error" };
  const withNativeBlob$1 = typeof Blob === "function" || typeof Blob !== "undefined" && Object.prototype.toString.call(Blob) === "[object BlobConstructor]";
  const withNativeArrayBuffer$2 = typeof ArrayBuffer === "function";
  const isView$1 = /* @__PURE__ */ __name((obj) => {
    return typeof ArrayBuffer.isView === "function" ? ArrayBuffer.isView(obj) : obj && obj.buffer instanceof ArrayBuffer;
  }, "isView$1");
  const encodePacket = /* @__PURE__ */ __name(({ type, data }, supportsBinary, callback) => {
    if (withNativeBlob$1 && data instanceof Blob) {
      if (supportsBinary) {
        return callback(data);
      } else {
        return encodeBlobAsBase64(data, callback);
      }
    } else if (withNativeArrayBuffer$2 && (data instanceof ArrayBuffer || isView$1(data))) {
      if (supportsBinary) {
        return callback(data);
      } else {
        return encodeBlobAsBase64(new Blob([data]), callback);
      }
    }
    return callback(PACKET_TYPES[type] + (data || ""));
  }, "encodePacket");
  const encodeBlobAsBase64 = /* @__PURE__ */ __name((data, callback) => {
    const fileReader = new FileReader();
    fileReader.onload = function() {
      const content = fileReader.result.split(",")[1];
      callback("b" + (content || ""));
    };
    return fileReader.readAsDataURL(data);
  }, "encodeBlobAsBase64");
  function toArray$1(data) {
    if (data instanceof Uint8Array) {
      return data;
    } else if (data instanceof ArrayBuffer) {
      return new Uint8Array(data);
    } else {
      return new Uint8Array(data.buffer, data.byteOffset, data.byteLength);
    }
  }
  __name(toArray$1, "toArray$1");
  let TEXT_ENCODER;
  function encodePacketToBinary(packet, callback) {
    if (withNativeBlob$1 && packet.data instanceof Blob) {
      return packet.data.arrayBuffer().then(toArray$1).then(callback);
    } else if (withNativeArrayBuffer$2 && (packet.data instanceof ArrayBuffer || isView$1(packet.data))) {
      return callback(toArray$1(packet.data));
    }
    encodePacket(packet, false, (encoded) => {
      if (!TEXT_ENCODER) {
        TEXT_ENCODER = new TextEncoder();
      }
      callback(TEXT_ENCODER.encode(encoded));
    });
  }
  __name(encodePacketToBinary, "encodePacketToBinary");
  const chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  const lookup$1 = typeof Uint8Array === "undefined" ? [] : new Uint8Array(256);
  for (let i = 0; i < chars.length; i++) {
    lookup$1[chars.charCodeAt(i)] = i;
  }
  const decode$1 = /* @__PURE__ */ __name((base64) => {
    let bufferLength = base64.length * 0.75, len = base64.length, i, p = 0, encoded1, encoded2, encoded3, encoded4;
    if (base64[base64.length - 1] === "=") {
      bufferLength--;
      if (base64[base64.length - 2] === "=") {
        bufferLength--;
      }
    }
    const arraybuffer = new ArrayBuffer(bufferLength), bytes = new Uint8Array(arraybuffer);
    for (i = 0; i < len; i += 4) {
      encoded1 = lookup$1[base64.charCodeAt(i)];
      encoded2 = lookup$1[base64.charCodeAt(i + 1)];
      encoded3 = lookup$1[base64.charCodeAt(i + 2)];
      encoded4 = lookup$1[base64.charCodeAt(i + 3)];
      bytes[p++] = encoded1 << 2 | encoded2 >> 4;
      bytes[p++] = (encoded2 & 15) << 4 | encoded3 >> 2;
      bytes[p++] = (encoded3 & 3) << 6 | encoded4 & 63;
    }
    return arraybuffer;
  }, "decode$1");
  const withNativeArrayBuffer$1 = typeof ArrayBuffer === "function";
  const decodePacket = /* @__PURE__ */ __name((encodedPacket, binaryType) => {
    if (typeof encodedPacket !== "string") {
      return {
        type: "message",
        data: mapBinary(encodedPacket, binaryType)
      };
    }
    const type = encodedPacket.charAt(0);
    if (type === "b") {
      return {
        type: "message",
        data: decodeBase64Packet(encodedPacket.substring(1), binaryType)
      };
    }
    const packetType = PACKET_TYPES_REVERSE[type];
    if (!packetType) {
      return ERROR_PACKET;
    }
    return encodedPacket.length > 1 ? {
      type: PACKET_TYPES_REVERSE[type],
      data: encodedPacket.substring(1)
    } : {
      type: PACKET_TYPES_REVERSE[type]
    };
  }, "decodePacket");
  const decodeBase64Packet = /* @__PURE__ */ __name((data, binaryType) => {
    if (withNativeArrayBuffer$1) {
      const decoded = decode$1(data);
      return mapBinary(decoded, binaryType);
    } else {
      return { base64: true, data };
    }
  }, "decodeBase64Packet");
  const mapBinary = /* @__PURE__ */ __name((data, binaryType) => {
    switch (binaryType) {
      case "blob":
        if (data instanceof Blob) {
          return data;
        } else {
          return new Blob([data]);
        }
      case "arraybuffer":
      default:
        if (data instanceof ArrayBuffer) {
          return data;
        } else {
          return data.buffer;
        }
    }
  }, "mapBinary");
  const SEPARATOR = String.fromCharCode(30);
  const encodePayload = /* @__PURE__ */ __name((packets, callback) => {
    const length = packets.length;
    const encodedPackets = new Array(length);
    let count = 0;
    packets.forEach((packet, i) => {
      encodePacket(packet, false, (encodedPacket) => {
        encodedPackets[i] = encodedPacket;
        if (++count === length) {
          callback(encodedPackets.join(SEPARATOR));
        }
      });
    });
  }, "encodePayload");
  const decodePayload = /* @__PURE__ */ __name((encodedPayload, binaryType) => {
    const encodedPackets = encodedPayload.split(SEPARATOR);
    const packets = [];
    for (let i = 0; i < encodedPackets.length; i++) {
      const decodedPacket = decodePacket(encodedPackets[i], binaryType);
      packets.push(decodedPacket);
      if (decodedPacket.type === "error") {
        break;
      }
    }
    return packets;
  }, "decodePayload");
  function createPacketEncoderStream() {
    return new TransformStream({
      transform(packet, controller) {
        encodePacketToBinary(packet, (encodedPacket) => {
          const payloadLength = encodedPacket.length;
          let header;
          if (payloadLength < 126) {
            header = new Uint8Array(1);
            new DataView(header.buffer).setUint8(0, payloadLength);
          } else if (payloadLength < 65536) {
            header = new Uint8Array(3);
            const view = new DataView(header.buffer);
            view.setUint8(0, 126);
            view.setUint16(1, payloadLength);
          } else {
            header = new Uint8Array(9);
            const view = new DataView(header.buffer);
            view.setUint8(0, 127);
            view.setBigUint64(1, BigInt(payloadLength));
          }
          if (packet.data && typeof packet.data !== "string") {
            header[0] |= 128;
          }
          controller.enqueue(header);
          controller.enqueue(encodedPacket);
        });
      }
    });
  }
  __name(createPacketEncoderStream, "createPacketEncoderStream");
  let TEXT_DECODER;
  function totalLength(chunks) {
    return chunks.reduce((acc, chunk) => acc + chunk.length, 0);
  }
  __name(totalLength, "totalLength");
  function concatChunks(chunks, size) {
    if (chunks[0].length === size) {
      return chunks.shift();
    }
    const buffer = new Uint8Array(size);
    let j = 0;
    for (let i = 0; i < size; i++) {
      buffer[i] = chunks[0][j++];
      if (j === chunks[0].length) {
        chunks.shift();
        j = 0;
      }
    }
    if (chunks.length && j < chunks[0].length) {
      chunks[0] = chunks[0].slice(j);
    }
    return buffer;
  }
  __name(concatChunks, "concatChunks");
  function createPacketDecoderStream(maxPayload, binaryType) {
    if (!TEXT_DECODER) {
      TEXT_DECODER = new TextDecoder();
    }
    const chunks = [];
    let state = 0;
    let expectedLength = -1;
    let isBinary2 = false;
    return new TransformStream({
      transform(chunk, controller) {
        chunks.push(chunk);
        while (true) {
          if (state === 0) {
            if (totalLength(chunks) < 1) {
              break;
            }
            const header = concatChunks(chunks, 1);
            isBinary2 = (header[0] & 128) === 128;
            expectedLength = header[0] & 127;
            if (expectedLength < 126) {
              state = 3;
            } else if (expectedLength === 126) {
              state = 1;
            } else {
              state = 2;
            }
          } else if (state === 1) {
            if (totalLength(chunks) < 2) {
              break;
            }
            const headerArray = concatChunks(chunks, 2);
            expectedLength = new DataView(headerArray.buffer, headerArray.byteOffset, headerArray.length).getUint16(0);
            state = 3;
          } else if (state === 2) {
            if (totalLength(chunks) < 8) {
              break;
            }
            const headerArray = concatChunks(chunks, 8);
            const view = new DataView(headerArray.buffer, headerArray.byteOffset, headerArray.length);
            const n = view.getUint32(0);
            if (n > Math.pow(2, 53 - 32) - 1) {
              controller.enqueue(ERROR_PACKET);
              break;
            }
            expectedLength = n * Math.pow(2, 32) + view.getUint32(4);
            state = 3;
          } else {
            if (totalLength(chunks) < expectedLength) {
              break;
            }
            const data = concatChunks(chunks, expectedLength);
            controller.enqueue(decodePacket(isBinary2 ? data : TEXT_DECODER.decode(data), binaryType));
            state = 0;
          }
          if (expectedLength === 0 || expectedLength > maxPayload) {
            controller.enqueue(ERROR_PACKET);
            break;
          }
        }
      }
    });
  }
  __name(createPacketDecoderStream, "createPacketDecoderStream");
  const protocol$1 = 4;
  function Emitter(obj) {
    if (obj) return mixin(obj);
  }
  __name(Emitter, "Emitter");
  function mixin(obj) {
    for (var key in Emitter.prototype) {
      obj[key] = Emitter.prototype[key];
    }
    return obj;
  }
  __name(mixin, "mixin");
  Emitter.prototype.on = Emitter.prototype.addEventListener = function(event, fn) {
    this._callbacks = this._callbacks || {};
    (this._callbacks["$" + event] = this._callbacks["$" + event] || []).push(fn);
    return this;
  };
  Emitter.prototype.once = function(event, fn) {
    function on2() {
      this.off(event, on2);
      fn.apply(this, arguments);
    }
    __name(on2, "on");
    on2.fn = fn;
    this.on(event, on2);
    return this;
  };
  Emitter.prototype.off = Emitter.prototype.removeListener = Emitter.prototype.removeAllListeners = Emitter.prototype.removeEventListener = function(event, fn) {
    this._callbacks = this._callbacks || {};
    if (0 == arguments.length) {
      this._callbacks = {};
      return this;
    }
    var callbacks = this._callbacks["$" + event];
    if (!callbacks) return this;
    if (1 == arguments.length) {
      delete this._callbacks["$" + event];
      return this;
    }
    var cb;
    for (var i = 0; i < callbacks.length; i++) {
      cb = callbacks[i];
      if (cb === fn || cb.fn === fn) {
        callbacks.splice(i, 1);
        break;
      }
    }
    if (callbacks.length === 0) {
      delete this._callbacks["$" + event];
    }
    return this;
  };
  Emitter.prototype.emit = function(event) {
    this._callbacks = this._callbacks || {};
    var args = new Array(arguments.length - 1), callbacks = this._callbacks["$" + event];
    for (var i = 1; i < arguments.length; i++) {
      args[i - 1] = arguments[i];
    }
    if (callbacks) {
      callbacks = callbacks.slice(0);
      for (var i = 0, len = callbacks.length; i < len; ++i) {
        callbacks[i].apply(this, args);
      }
    }
    return this;
  };
  Emitter.prototype.emitReserved = Emitter.prototype.emit;
  Emitter.prototype.listeners = function(event) {
    this._callbacks = this._callbacks || {};
    return this._callbacks["$" + event] || [];
  };
  Emitter.prototype.hasListeners = function(event) {
    return !!this.listeners(event).length;
  };
  const nextTick = (() => {
    const isPromiseAvailable = typeof Promise === "function" && typeof Promise.resolve === "function";
    if (isPromiseAvailable) {
      return (cb) => Promise.resolve().then(cb);
    } else {
      return (cb, setTimeoutFn) => setTimeoutFn(cb, 0);
    }
  })();
  const globalThisShim = (() => {
    if (typeof self !== "undefined") {
      return self;
    } else if (typeof window !== "undefined") {
      return window;
    } else {
      return Function("return this")();
    }
  })();
  const defaultBinaryType = "arraybuffer";
  function createCookieJar() {
  }
  __name(createCookieJar, "createCookieJar");
  function pick(obj, ...attr) {
    return attr.reduce((acc, k) => {
      if (obj.hasOwnProperty(k)) {
        acc[k] = obj[k];
      }
      return acc;
    }, {});
  }
  __name(pick, "pick");
  const NATIVE_SET_TIMEOUT = globalThisShim.setTimeout;
  const NATIVE_CLEAR_TIMEOUT = globalThisShim.clearTimeout;
  function installTimerFunctions(obj, opts) {
    if (opts.useNativeTimers) {
      obj.setTimeoutFn = NATIVE_SET_TIMEOUT.bind(globalThisShim);
      obj.clearTimeoutFn = NATIVE_CLEAR_TIMEOUT.bind(globalThisShim);
    } else {
      obj.setTimeoutFn = globalThisShim.setTimeout.bind(globalThisShim);
      obj.clearTimeoutFn = globalThisShim.clearTimeout.bind(globalThisShim);
    }
  }
  __name(installTimerFunctions, "installTimerFunctions");
  const BASE64_OVERHEAD = 1.33;
  function byteLength(obj) {
    if (typeof obj === "string") {
      return utf8Length(obj);
    }
    return Math.ceil((obj.byteLength || obj.size) * BASE64_OVERHEAD);
  }
  __name(byteLength, "byteLength");
  function utf8Length(str) {
    let c = 0, length = 0;
    for (let i = 0, l = str.length; i < l; i++) {
      c = str.charCodeAt(i);
      if (c < 128) {
        length += 1;
      } else if (c < 2048) {
        length += 2;
      } else if (c < 55296 || c >= 57344) {
        length += 3;
      } else {
        i++;
        length += 4;
      }
    }
    return length;
  }
  __name(utf8Length, "utf8Length");
  function randomString() {
    return Date.now().toString(36).substring(3) + Math.random().toString(36).substring(2, 5);
  }
  __name(randomString, "randomString");
  function encode$2(obj) {
    let str = "";
    for (let i in obj) {
      if (obj.hasOwnProperty(i)) {
        if (str.length)
          str += "&";
        str += encodeURIComponent(i) + "=" + encodeURIComponent(obj[i]);
      }
    }
    return str;
  }
  __name(encode$2, "encode$2");
  function decode(qs) {
    let qry = {};
    let pairs = qs.split("&");
    for (let i = 0, l = pairs.length; i < l; i++) {
      let pair = pairs[i].split("=");
      qry[decodeURIComponent(pair[0])] = decodeURIComponent(pair[1]);
    }
    return qry;
  }
  __name(decode, "decode");
  const _TransportError = class _TransportError extends Error {
    constructor(reason, description, context) {
      super(reason);
      this.description = description;
      this.context = context;
      this.type = "TransportError";
    }
  };
  __name(_TransportError, "TransportError");
  let TransportError = _TransportError;
  const _Transport = class _Transport extends Emitter {
    /**
     * Transport abstract constructor.
     *
     * @param {Object} opts - options
     * @protected
     */
    constructor(opts) {
      super();
      this.writable = false;
      installTimerFunctions(this, opts);
      this.opts = opts;
      this.query = opts.query;
      this.socket = opts.socket;
      this.supportsBinary = !opts.forceBase64;
    }
    /**
     * Emits an error.
     *
     * @param {String} reason
     * @param description
     * @param context - the error context
     * @return {Transport} for chaining
     * @protected
     */
    onError(reason, description, context) {
      super.emitReserved("error", new TransportError(reason, description, context));
      return this;
    }
    /**
     * Opens the transport.
     */
    open() {
      this.readyState = "opening";
      this.doOpen();
      return this;
    }
    /**
     * Closes the transport.
     */
    close() {
      if (this.readyState === "opening" || this.readyState === "open") {
        this.doClose();
        this.onClose();
      }
      return this;
    }
    /**
     * Sends multiple packets.
     *
     * @param {Array} packets
     */
    send(packets) {
      if (this.readyState === "open") {
        this.write(packets);
      }
    }
    /**
     * Called upon open
     *
     * @protected
     */
    onOpen() {
      this.readyState = "open";
      this.writable = true;
      super.emitReserved("open");
    }
    /**
     * Called with data.
     *
     * @param {String} data
     * @protected
     */
    onData(data) {
      const packet = decodePacket(data, this.socket.binaryType);
      this.onPacket(packet);
    }
    /**
     * Called with a decoded packet.
     *
     * @protected
     */
    onPacket(packet) {
      super.emitReserved("packet", packet);
    }
    /**
     * Called upon close.
     *
     * @protected
     */
    onClose(details) {
      this.readyState = "closed";
      super.emitReserved("close", details);
    }
    /**
     * Pauses the transport, in order not to lose packets during an upgrade.
     *
     * @param onPause
     */
    pause(onPause) {
    }
    createUri(schema, query = {}) {
      return schema + "://" + this._hostname() + this._port() + this.opts.path + this._query(query);
    }
    _hostname() {
      const hostname = this.opts.hostname;
      return hostname.indexOf(":") === -1 ? hostname : "[" + hostname + "]";
    }
    _port() {
      if (this.opts.port && (this.opts.secure && Number(this.opts.port !== 443) || !this.opts.secure && Number(this.opts.port) !== 80)) {
        return ":" + this.opts.port;
      } else {
        return "";
      }
    }
    _query(query) {
      const encodedQuery = encode$2(query);
      return encodedQuery.length ? "?" + encodedQuery : "";
    }
  };
  __name(_Transport, "Transport");
  let Transport = _Transport;
  const _Polling = class _Polling extends Transport {
    constructor() {
      super(...arguments);
      this._polling = false;
    }
    get name() {
      return "polling";
    }
    /**
     * Opens the socket (triggers polling). We write a PING message to determine
     * when the transport is open.
     *
     * @protected
     */
    doOpen() {
      this._poll();
    }
    /**
     * Pauses polling.
     *
     * @param {Function} onPause - callback upon buffers are flushed and transport is paused
     * @package
     */
    pause(onPause) {
      this.readyState = "pausing";
      const pause2 = /* @__PURE__ */ __name(() => {
        this.readyState = "paused";
        onPause();
      }, "pause");
      if (this._polling || !this.writable) {
        let total = 0;
        if (this._polling) {
          total++;
          this.once("pollComplete", function() {
            --total || pause2();
          });
        }
        if (!this.writable) {
          total++;
          this.once("drain", function() {
            --total || pause2();
          });
        }
      } else {
        pause2();
      }
    }
    /**
     * Starts polling cycle.
     *
     * @private
     */
    _poll() {
      this._polling = true;
      this.doPoll();
      this.emitReserved("poll");
    }
    /**
     * Overloads onData to detect payloads.
     *
     * @protected
     */
    onData(data) {
      const callback = /* @__PURE__ */ __name((packet) => {
        if ("opening" === this.readyState && packet.type === "open") {
          this.onOpen();
        }
        if ("close" === packet.type) {
          this.onClose({ description: "transport closed by the server" });
          return false;
        }
        this.onPacket(packet);
      }, "callback");
      decodePayload(data, this.socket.binaryType).forEach(callback);
      if ("closed" !== this.readyState) {
        this._polling = false;
        this.emitReserved("pollComplete");
        if ("open" === this.readyState) {
          this._poll();
        }
      }
    }
    /**
     * For polling, send a close packet.
     *
     * @protected
     */
    doClose() {
      const close = /* @__PURE__ */ __name(() => {
        this.write([{ type: "close" }]);
      }, "close");
      if ("open" === this.readyState) {
        close();
      } else {
        this.once("open", close);
      }
    }
    /**
     * Writes a packets payload.
     *
     * @param {Array} packets - data packets
     * @protected
     */
    write(packets) {
      this.writable = false;
      encodePayload(packets, (data) => {
        this.doWrite(data, () => {
          this.writable = true;
          this.emitReserved("drain");
        });
      });
    }
    /**
     * Generates uri for connection.
     *
     * @private
     */
    uri() {
      const schema = this.opts.secure ? "https" : "http";
      const query = this.query || {};
      if (false !== this.opts.timestampRequests) {
        query[this.opts.timestampParam] = randomString();
      }
      if (!this.supportsBinary && !query.sid) {
        query.b64 = 1;
      }
      return this.createUri(schema, query);
    }
  };
  __name(_Polling, "Polling");
  let Polling = _Polling;
  let value = false;
  try {
    value = typeof XMLHttpRequest !== "undefined" && "withCredentials" in new XMLHttpRequest();
  } catch (err) {
  }
  const hasCORS = value;
  function empty() {
  }
  __name(empty, "empty");
  const _BaseXHR = class _BaseXHR extends Polling {
    /**
     * XHR Polling constructor.
     *
     * @param {Object} opts
     * @package
     */
    constructor(opts) {
      super(opts);
      if (typeof location !== "undefined") {
        const isSSL = "https:" === location.protocol;
        let port = location.port;
        if (!port) {
          port = isSSL ? "443" : "80";
        }
        this.xd = typeof location !== "undefined" && opts.hostname !== location.hostname || port !== opts.port;
      }
    }
    /**
     * Sends data.
     *
     * @param {String} data to send.
     * @param {Function} called upon flush.
     * @private
     */
    doWrite(data, fn) {
      const req = this.request({
        method: "POST",
        data
      });
      req.on("success", fn);
      req.on("error", (xhrStatus, context) => {
        this.onError("xhr post error", xhrStatus, context);
      });
    }
    /**
     * Starts a poll cycle.
     *
     * @private
     */
    doPoll() {
      const req = this.request();
      req.on("data", this.onData.bind(this));
      req.on("error", (xhrStatus, context) => {
        this.onError("xhr poll error", xhrStatus, context);
      });
      this.pollXhr = req;
    }
  };
  __name(_BaseXHR, "BaseXHR");
  let BaseXHR = _BaseXHR;
  let Request$1 = (_a = class extends Emitter {
    /**
     * Request constructor
     *
     * @param {Object} options
     * @package
     */
    constructor(createRequest, uri, opts) {
      super();
      this.createRequest = createRequest;
      installTimerFunctions(this, opts);
      this._opts = opts;
      this._method = opts.method || "GET";
      this._uri = uri;
      this._data = void 0 !== opts.data ? opts.data : null;
      this._create();
    }
    /**
     * Creates the XHR object and sends the request.
     *
     * @private
     */
    _create() {
      var _a2;
      const opts = pick(this._opts, "agent", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "autoUnref");
      opts.xdomain = !!this._opts.xd;
      const xhr = this._xhr = this.createRequest(opts);
      try {
        xhr.open(this._method, this._uri, true);
        try {
          if (this._opts.extraHeaders) {
            xhr.setDisableHeaderCheck && xhr.setDisableHeaderCheck(true);
            for (let i in this._opts.extraHeaders) {
              if (this._opts.extraHeaders.hasOwnProperty(i)) {
                xhr.setRequestHeader(i, this._opts.extraHeaders[i]);
              }
            }
          }
        } catch (e) {
        }
        if ("POST" === this._method) {
          try {
            xhr.setRequestHeader("Content-type", "text/plain;charset=UTF-8");
          } catch (e) {
          }
        }
        try {
          xhr.setRequestHeader("Accept", "*/*");
        } catch (e) {
        }
        (_a2 = this._opts.cookieJar) === null || _a2 === void 0 ? void 0 : _a2.addCookies(xhr);
        if ("withCredentials" in xhr) {
          xhr.withCredentials = this._opts.withCredentials;
        }
        if (this._opts.requestTimeout) {
          xhr.timeout = this._opts.requestTimeout;
        }
        xhr.onreadystatechange = () => {
          var _a3;
          if (xhr.readyState === 3) {
            (_a3 = this._opts.cookieJar) === null || _a3 === void 0 ? void 0 : _a3.parseCookies(
              // @ts-ignore
              xhr.getResponseHeader("set-cookie")
            );
          }
          if (4 !== xhr.readyState)
            return;
          if (200 === xhr.status || 1223 === xhr.status) {
            this._onLoad();
          } else {
            this.setTimeoutFn(() => {
              this._onError(typeof xhr.status === "number" ? xhr.status : 0);
            }, 0);
          }
        };
        xhr.send(this._data);
      } catch (e) {
        this.setTimeoutFn(() => {
          this._onError(e);
        }, 0);
        return;
      }
      if (typeof document !== "undefined") {
        this._index = _a.requestsCount++;
        _a.requests[this._index] = this;
      }
    }
    /**
     * Called upon error.
     *
     * @private
     */
    _onError(err) {
      this.emitReserved("error", err, this._xhr);
      this._cleanup(true);
    }
    /**
     * Cleans up house.
     *
     * @private
     */
    _cleanup(fromError) {
      if ("undefined" === typeof this._xhr || null === this._xhr) {
        return;
      }
      this._xhr.onreadystatechange = empty;
      if (fromError) {
        try {
          this._xhr.abort();
        } catch (e) {
        }
      }
      if (typeof document !== "undefined") {
        delete _a.requests[this._index];
      }
      this._xhr = null;
    }
    /**
     * Called upon load.
     *
     * @private
     */
    _onLoad() {
      const data = this._xhr.responseText;
      if (data !== null) {
        this.emitReserved("data", data);
        this.emitReserved("success");
        this._cleanup();
      }
    }
    /**
     * Aborts the request.
     *
     * @package
     */
    abort() {
      this._cleanup();
    }
  }, __name(_a, "Request"), _a);
  Request$1.requestsCount = 0;
  Request$1.requests = {};
  if (typeof document !== "undefined") {
    if (typeof attachEvent === "function") {
      attachEvent("onunload", unloadHandler);
    } else if (typeof addEventListener === "function") {
      const terminationEvent = "onpagehide" in globalThisShim ? "pagehide" : "unload";
      addEventListener(terminationEvent, unloadHandler, false);
    }
  }
  function unloadHandler() {
    for (let i in Request$1.requests) {
      if (Request$1.requests.hasOwnProperty(i)) {
        Request$1.requests[i].abort();
      }
    }
  }
  __name(unloadHandler, "unloadHandler");
  const hasXHR2 = function() {
    const xhr = newRequest({
      xdomain: false
    });
    return xhr && xhr.responseType !== null;
  }();
  const _XHR = class _XHR extends BaseXHR {
    constructor(opts) {
      super(opts);
      const forceBase64 = opts && opts.forceBase64;
      this.supportsBinary = hasXHR2 && !forceBase64;
    }
    request(opts = {}) {
      Object.assign(opts, { xd: this.xd }, this.opts);
      return new Request$1(newRequest, this.uri(), opts);
    }
  };
  __name(_XHR, "XHR");
  let XHR = _XHR;
  function newRequest(opts) {
    const xdomain = opts.xdomain;
    try {
      if ("undefined" !== typeof XMLHttpRequest && (!xdomain || hasCORS)) {
        return new XMLHttpRequest();
      }
    } catch (e) {
    }
    if (!xdomain) {
      try {
        return new globalThisShim[["Active"].concat("Object").join("X")]("Microsoft.XMLHTTP");
      } catch (e) {
      }
    }
  }
  __name(newRequest, "newRequest");
  const isReactNative = typeof navigator !== "undefined" && typeof navigator.product === "string" && navigator.product.toLowerCase() === "reactnative";
  const _BaseWS = class _BaseWS extends Transport {
    get name() {
      return "websocket";
    }
    doOpen() {
      const uri = this.uri();
      const protocols = this.opts.protocols;
      const opts = isReactNative ? {} : pick(this.opts, "agent", "perMessageDeflate", "pfx", "key", "passphrase", "cert", "ca", "ciphers", "rejectUnauthorized", "localAddress", "protocolVersion", "origin", "maxPayload", "family", "checkServerIdentity");
      if (this.opts.extraHeaders) {
        opts.headers = this.opts.extraHeaders;
      }
      try {
        this.ws = this.createSocket(uri, protocols, opts);
      } catch (err) {
        return this.emitReserved("error", err);
      }
      this.ws.binaryType = this.socket.binaryType;
      this.addEventListeners();
    }
    /**
     * Adds event listeners to the socket
     *
     * @private
     */
    addEventListeners() {
      this.ws.onopen = () => {
        if (this.opts.autoUnref) {
          this.ws._socket.unref();
        }
        this.onOpen();
      };
      this.ws.onclose = (closeEvent) => this.onClose({
        description: "websocket connection closed",
        context: closeEvent
      });
      this.ws.onmessage = (ev) => this.onData(ev.data);
      this.ws.onerror = (e) => this.onError("websocket error", e);
    }
    write(packets) {
      this.writable = false;
      for (let i = 0; i < packets.length; i++) {
        const packet = packets[i];
        const lastPacket = i === packets.length - 1;
        encodePacket(packet, this.supportsBinary, (data) => {
          try {
            this.doWrite(packet, data);
          } catch (e) {
          }
          if (lastPacket) {
            nextTick(() => {
              this.writable = true;
              this.emitReserved("drain");
            }, this.setTimeoutFn);
          }
        });
      }
    }
    doClose() {
      if (typeof this.ws !== "undefined") {
        this.ws.onerror = () => {
        };
        this.ws.close();
        this.ws = null;
      }
    }
    /**
     * Generates uri for connection.
     *
     * @private
     */
    uri() {
      const schema = this.opts.secure ? "wss" : "ws";
      const query = this.query || {};
      if (this.opts.timestampRequests) {
        query[this.opts.timestampParam] = randomString();
      }
      if (!this.supportsBinary) {
        query.b64 = 1;
      }
      return this.createUri(schema, query);
    }
  };
  __name(_BaseWS, "BaseWS");
  let BaseWS = _BaseWS;
  const WebSocketCtor = globalThisShim.WebSocket || globalThisShim.MozWebSocket;
  const _WS = class _WS extends BaseWS {
    createSocket(uri, protocols, opts) {
      return !isReactNative ? protocols ? new WebSocketCtor(uri, protocols) : new WebSocketCtor(uri) : new WebSocketCtor(uri, protocols, opts);
    }
    doWrite(_packet, data) {
      this.ws.send(data);
    }
  };
  __name(_WS, "WS");
  let WS = _WS;
  const _WT = class _WT extends Transport {
    get name() {
      return "webtransport";
    }
    doOpen() {
      try {
        this._transport = new WebTransport(this.createUri("https"), this.opts.transportOptions[this.name]);
      } catch (err) {
        return this.emitReserved("error", err);
      }
      this._transport.closed.then(() => {
        this.onClose();
      }).catch((err) => {
        this.onError("webtransport error", err);
      });
      this._transport.ready.then(() => {
        this._transport.createBidirectionalStream().then((stream) => {
          const decoderStream = createPacketDecoderStream(Number.MAX_SAFE_INTEGER, this.socket.binaryType);
          const reader = stream.readable.pipeThrough(decoderStream).getReader();
          const encoderStream = createPacketEncoderStream();
          encoderStream.readable.pipeTo(stream.writable);
          this._writer = encoderStream.writable.getWriter();
          const read = /* @__PURE__ */ __name(() => {
            reader.read().then(({ done, value: value2 }) => {
              if (done) {
                return;
              }
              this.onPacket(value2);
              read();
            }).catch((err) => {
            });
          }, "read");
          read();
          const packet = { type: "open" };
          if (this.query.sid) {
            packet.data = `{"sid":"${this.query.sid}"}`;
          }
          this._writer.write(packet).then(() => this.onOpen());
        });
      });
    }
    write(packets) {
      this.writable = false;
      for (let i = 0; i < packets.length; i++) {
        const packet = packets[i];
        const lastPacket = i === packets.length - 1;
        this._writer.write(packet).then(() => {
          if (lastPacket) {
            nextTick(() => {
              this.writable = true;
              this.emitReserved("drain");
            }, this.setTimeoutFn);
          }
        });
      }
    }
    doClose() {
      var _a2;
      (_a2 = this._transport) === null || _a2 === void 0 ? void 0 : _a2.close();
    }
  };
  __name(_WT, "WT");
  let WT = _WT;
  const transports = {
    websocket: WS,
    webtransport: WT,
    polling: XHR
  };
  const re = /^(?:(?![^:@\/?#]+:[^:@\/]*@)(http|https|ws|wss):\/\/)?((?:(([^:@\/?#]*)(?::([^:@\/?#]*))?)?@)?((?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}|[^:\/?#]*)(?::(\d*))?)(((\/(?:[^?#](?![^?#\/]*\.[^?#\/.]+(?:[?#]|$)))*\/?)?([^?#\/]*))(?:\?([^#]*))?(?:#(.*))?)/;
  const parts = [
    "source",
    "protocol",
    "authority",
    "userInfo",
    "user",
    "password",
    "host",
    "port",
    "relative",
    "path",
    "directory",
    "file",
    "query",
    "anchor"
  ];
  function parse(str) {
    if (str.length > 8e3) {
      throw "URI too long";
    }
    const src = str, b = str.indexOf("["), e = str.indexOf("]");
    if (b != -1 && e != -1) {
      str = str.substring(0, b) + str.substring(b, e).replace(/:/g, ";") + str.substring(e, str.length);
    }
    let m = re.exec(str || ""), uri = {}, i = 14;
    while (i--) {
      uri[parts[i]] = m[i] || "";
    }
    if (b != -1 && e != -1) {
      uri.source = src;
      uri.host = uri.host.substring(1, uri.host.length - 1).replace(/;/g, ":");
      uri.authority = uri.authority.replace("[", "").replace("]", "").replace(/;/g, ":");
      uri.ipv6uri = true;
    }
    uri.pathNames = pathNames(uri, uri["path"]);
    uri.queryKey = queryKey(uri, uri["query"]);
    return uri;
  }
  __name(parse, "parse");
  function pathNames(obj, path) {
    const regx = /\/{2,9}/g, names = path.replace(regx, "/").split("/");
    if (path.slice(0, 1) == "/" || path.length === 0) {
      names.splice(0, 1);
    }
    if (path.slice(-1) == "/") {
      names.splice(names.length - 1, 1);
    }
    return names;
  }
  __name(pathNames, "pathNames");
  function queryKey(uri, query) {
    const data = {};
    query.replace(/(?:^|&)([^&=]*)=?([^&]*)/g, function($0, $1, $2) {
      if ($1) {
        data[$1] = $2;
      }
    });
    return data;
  }
  __name(queryKey, "queryKey");
  const withEventListeners = typeof addEventListener === "function" && typeof removeEventListener === "function";
  const OFFLINE_EVENT_LISTENERS = [];
  if (withEventListeners) {
    addEventListener("offline", () => {
      OFFLINE_EVENT_LISTENERS.forEach((listener) => listener());
    }, false);
  }
  const _SocketWithoutUpgrade = class _SocketWithoutUpgrade extends Emitter {
    /**
     * Socket constructor.
     *
     * @param {String|Object} uri - uri or options
     * @param {Object} opts - options
     */
    constructor(uri, opts) {
      super();
      this.binaryType = defaultBinaryType;
      this.writeBuffer = [];
      this._prevBufferLen = 0;
      this._pingInterval = -1;
      this._pingTimeout = -1;
      this._maxPayload = -1;
      this._pingTimeoutTime = Infinity;
      if (uri && "object" === typeof uri) {
        opts = uri;
        uri = null;
      }
      if (uri) {
        const parsedUri = parse(uri);
        opts.hostname = parsedUri.host;
        opts.secure = parsedUri.protocol === "https" || parsedUri.protocol === "wss";
        opts.port = parsedUri.port;
        if (parsedUri.query)
          opts.query = parsedUri.query;
      } else if (opts.host) {
        opts.hostname = parse(opts.host).host;
      }
      installTimerFunctions(this, opts);
      this.secure = null != opts.secure ? opts.secure : typeof location !== "undefined" && "https:" === location.protocol;
      if (opts.hostname && !opts.port) {
        opts.port = this.secure ? "443" : "80";
      }
      this.hostname = opts.hostname || (typeof location !== "undefined" ? location.hostname : "localhost");
      this.port = opts.port || (typeof location !== "undefined" && location.port ? location.port : this.secure ? "443" : "80");
      this.transports = [];
      this._transportsByName = {};
      opts.transports.forEach((t) => {
        const transportName = t.prototype.name;
        this.transports.push(transportName);
        this._transportsByName[transportName] = t;
      });
      this.opts = Object.assign({
        path: "/engine.io",
        agent: false,
        withCredentials: false,
        upgrade: true,
        timestampParam: "t",
        rememberUpgrade: false,
        addTrailingSlash: true,
        rejectUnauthorized: true,
        perMessageDeflate: {
          threshold: 1024
        },
        transportOptions: {},
        closeOnBeforeunload: false
      }, opts);
      this.opts.path = this.opts.path.replace(/\/$/, "") + (this.opts.addTrailingSlash ? "/" : "");
      if (typeof this.opts.query === "string") {
        this.opts.query = decode(this.opts.query);
      }
      if (withEventListeners) {
        if (this.opts.closeOnBeforeunload) {
          this._beforeunloadEventListener = () => {
            if (this.transport) {
              this.transport.removeAllListeners();
              this.transport.close();
            }
          };
          addEventListener("beforeunload", this._beforeunloadEventListener, false);
        }
        if (this.hostname !== "localhost") {
          this._offlineEventListener = () => {
            this._onClose("transport close", {
              description: "network connection lost"
            });
          };
          OFFLINE_EVENT_LISTENERS.push(this._offlineEventListener);
        }
      }
      if (this.opts.withCredentials) {
        this._cookieJar = createCookieJar();
      }
      this._open();
    }
    /**
     * Creates transport of the given type.
     *
     * @param {String} name - transport name
     * @return {Transport}
     * @private
     */
    createTransport(name) {
      const query = Object.assign({}, this.opts.query);
      query.EIO = protocol$1;
      query.transport = name;
      if (this.id)
        query.sid = this.id;
      const opts = Object.assign({}, this.opts, {
        query,
        socket: this,
        hostname: this.hostname,
        secure: this.secure,
        port: this.port
      }, this.opts.transportOptions[name]);
      return new this._transportsByName[name](opts);
    }
    /**
     * Initializes transport to use and starts probe.
     *
     * @private
     */
    _open() {
      if (this.transports.length === 0) {
        this.setTimeoutFn(() => {
          this.emitReserved("error", "No transports available");
        }, 0);
        return;
      }
      const transportName = this.opts.rememberUpgrade && _SocketWithoutUpgrade.priorWebsocketSuccess && this.transports.indexOf("websocket") !== -1 ? "websocket" : this.transports[0];
      this.readyState = "opening";
      const transport = this.createTransport(transportName);
      transport.open();
      this.setTransport(transport);
    }
    /**
     * Sets the current transport. Disables the existing one (if any).
     *
     * @private
     */
    setTransport(transport) {
      if (this.transport) {
        this.transport.removeAllListeners();
      }
      this.transport = transport;
      transport.on("drain", this._onDrain.bind(this)).on("packet", this._onPacket.bind(this)).on("error", this._onError.bind(this)).on("close", (reason) => this._onClose("transport close", reason));
    }
    /**
     * Called when connection is deemed open.
     *
     * @private
     */
    onOpen() {
      this.readyState = "open";
      _SocketWithoutUpgrade.priorWebsocketSuccess = "websocket" === this.transport.name;
      this.emitReserved("open");
      this.flush();
    }
    /**
     * Handles a packet.
     *
     * @private
     */
    _onPacket(packet) {
      if ("opening" === this.readyState || "open" === this.readyState || "closing" === this.readyState) {
        this.emitReserved("packet", packet);
        this.emitReserved("heartbeat");
        switch (packet.type) {
          case "open":
            this.onHandshake(JSON.parse(packet.data));
            break;
          case "ping":
            this._sendPacket("pong");
            this.emitReserved("ping");
            this.emitReserved("pong");
            this._resetPingTimeout();
            break;
          case "error":
            const err = new Error("server error");
            err.code = packet.data;
            this._onError(err);
            break;
          case "message":
            this.emitReserved("data", packet.data);
            this.emitReserved("message", packet.data);
            break;
        }
      }
    }
    /**
     * Called upon handshake completion.
     *
     * @param {Object} data - handshake obj
     * @private
     */
    onHandshake(data) {
      this.emitReserved("handshake", data);
      this.id = data.sid;
      this.transport.query.sid = data.sid;
      this._pingInterval = data.pingInterval;
      this._pingTimeout = data.pingTimeout;
      this._maxPayload = data.maxPayload;
      this.onOpen();
      if ("closed" === this.readyState)
        return;
      this._resetPingTimeout();
    }
    /**
     * Sets and resets ping timeout timer based on server pings.
     *
     * @private
     */
    _resetPingTimeout() {
      this.clearTimeoutFn(this._pingTimeoutTimer);
      const delay = this._pingInterval + this._pingTimeout;
      this._pingTimeoutTime = Date.now() + delay;
      this._pingTimeoutTimer = this.setTimeoutFn(() => {
        this._onClose("ping timeout");
      }, delay);
      if (this.opts.autoUnref) {
        this._pingTimeoutTimer.unref();
      }
    }
    /**
     * Called on `drain` event
     *
     * @private
     */
    _onDrain() {
      this.writeBuffer.splice(0, this._prevBufferLen);
      this._prevBufferLen = 0;
      if (0 === this.writeBuffer.length) {
        this.emitReserved("drain");
      } else {
        this.flush();
      }
    }
    /**
     * Flush write buffers.
     *
     * @private
     */
    flush() {
      if ("closed" !== this.readyState && this.transport.writable && !this.upgrading && this.writeBuffer.length) {
        const packets = this._getWritablePackets();
        this.transport.send(packets);
        this._prevBufferLen = packets.length;
        this.emitReserved("flush");
      }
    }
    /**
     * Ensure the encoded size of the writeBuffer is below the maxPayload value sent by the server (only for HTTP
     * long-polling)
     *
     * @private
     */
    _getWritablePackets() {
      const shouldCheckPayloadSize = this._maxPayload && this.transport.name === "polling" && this.writeBuffer.length > 1;
      if (!shouldCheckPayloadSize) {
        return this.writeBuffer;
      }
      let payloadSize = 1;
      for (let i = 0; i < this.writeBuffer.length; i++) {
        const data = this.writeBuffer[i].data;
        if (data) {
          payloadSize += byteLength(data);
        }
        if (i > 0 && payloadSize > this._maxPayload) {
          return this.writeBuffer.slice(0, i);
        }
        payloadSize += 2;
      }
      return this.writeBuffer;
    }
    /**
     * Checks whether the heartbeat timer has expired but the socket has not yet been notified.
     *
     * Note: this method is private for now because it does not really fit the WebSocket API, but if we put it in the
     * `write()` method then the message would not be buffered by the Socket.IO client.
     *
     * @return {boolean}
     * @private
     */
    /* private */
    _hasPingExpired() {
      if (!this._pingTimeoutTime)
        return true;
      const hasExpired = Date.now() > this._pingTimeoutTime;
      if (hasExpired) {
        this._pingTimeoutTime = 0;
        nextTick(() => {
          this._onClose("ping timeout");
        }, this.setTimeoutFn);
      }
      return hasExpired;
    }
    /**
     * Sends a message.
     *
     * @param {String} msg - message.
     * @param {Object} options.
     * @param {Function} fn - callback function.
     * @return {Socket} for chaining.
     */
    write(msg, options, fn) {
      this._sendPacket("message", msg, options, fn);
      return this;
    }
    /**
     * Sends a message. Alias of {@link Socket#write}.
     *
     * @param {String} msg - message.
     * @param {Object} options.
     * @param {Function} fn - callback function.
     * @return {Socket} for chaining.
     */
    send(msg, options, fn) {
      this._sendPacket("message", msg, options, fn);
      return this;
    }
    /**
     * Sends a packet.
     *
     * @param {String} type: packet type.
     * @param {String} data.
     * @param {Object} options.
     * @param {Function} fn - callback function.
     * @private
     */
    _sendPacket(type, data, options, fn) {
      if ("function" === typeof data) {
        fn = data;
        data = void 0;
      }
      if ("function" === typeof options) {
        fn = options;
        options = null;
      }
      if ("closing" === this.readyState || "closed" === this.readyState) {
        return;
      }
      options = options || {};
      options.compress = false !== options.compress;
      const packet = {
        type,
        data,
        options
      };
      this.emitReserved("packetCreate", packet);
      this.writeBuffer.push(packet);
      if (fn)
        this.once("flush", fn);
      this.flush();
    }
    /**
     * Closes the connection.
     */
    close() {
      const close = /* @__PURE__ */ __name(() => {
        this._onClose("forced close");
        this.transport.close();
      }, "close");
      const cleanupAndClose = /* @__PURE__ */ __name(() => {
        this.off("upgrade", cleanupAndClose);
        this.off("upgradeError", cleanupAndClose);
        close();
      }, "cleanupAndClose");
      const waitForUpgrade = /* @__PURE__ */ __name(() => {
        this.once("upgrade", cleanupAndClose);
        this.once("upgradeError", cleanupAndClose);
      }, "waitForUpgrade");
      if ("opening" === this.readyState || "open" === this.readyState) {
        this.readyState = "closing";
        if (this.writeBuffer.length) {
          this.once("drain", () => {
            if (this.upgrading) {
              waitForUpgrade();
            } else {
              close();
            }
          });
        } else if (this.upgrading) {
          waitForUpgrade();
        } else {
          close();
        }
      }
      return this;
    }
    /**
     * Called upon transport error
     *
     * @private
     */
    _onError(err) {
      _SocketWithoutUpgrade.priorWebsocketSuccess = false;
      if (this.opts.tryAllTransports && this.transports.length > 1 && this.readyState === "opening") {
        this.transports.shift();
        return this._open();
      }
      this.emitReserved("error", err);
      this._onClose("transport error", err);
    }
    /**
     * Called upon transport close.
     *
     * @private
     */
    _onClose(reason, description) {
      if ("opening" === this.readyState || "open" === this.readyState || "closing" === this.readyState) {
        this.clearTimeoutFn(this._pingTimeoutTimer);
        this.transport.removeAllListeners("close");
        this.transport.close();
        this.transport.removeAllListeners();
        if (withEventListeners) {
          if (this._beforeunloadEventListener) {
            removeEventListener("beforeunload", this._beforeunloadEventListener, false);
          }
          if (this._offlineEventListener) {
            const i = OFFLINE_EVENT_LISTENERS.indexOf(this._offlineEventListener);
            if (i !== -1) {
              OFFLINE_EVENT_LISTENERS.splice(i, 1);
            }
          }
        }
        this.readyState = "closed";
        this.id = null;
        this.emitReserved("close", reason, description);
        this.writeBuffer = [];
        this._prevBufferLen = 0;
      }
    }
  };
  __name(_SocketWithoutUpgrade, "SocketWithoutUpgrade");
  let SocketWithoutUpgrade = _SocketWithoutUpgrade;
  SocketWithoutUpgrade.protocol = protocol$1;
  const _SocketWithUpgrade = class _SocketWithUpgrade extends SocketWithoutUpgrade {
    constructor() {
      super(...arguments);
      this._upgrades = [];
    }
    onOpen() {
      super.onOpen();
      if ("open" === this.readyState && this.opts.upgrade) {
        for (let i = 0; i < this._upgrades.length; i++) {
          this._probe(this._upgrades[i]);
        }
      }
    }
    /**
     * Probes a transport.
     *
     * @param {String} name - transport name
     * @private
     */
    _probe(name) {
      let transport = this.createTransport(name);
      let failed = false;
      SocketWithoutUpgrade.priorWebsocketSuccess = false;
      const onTransportOpen = /* @__PURE__ */ __name(() => {
        if (failed)
          return;
        transport.send([{ type: "ping", data: "probe" }]);
        transport.once("packet", (msg) => {
          if (failed)
            return;
          if ("pong" === msg.type && "probe" === msg.data) {
            this.upgrading = true;
            this.emitReserved("upgrading", transport);
            if (!transport)
              return;
            SocketWithoutUpgrade.priorWebsocketSuccess = "websocket" === transport.name;
            this.transport.pause(() => {
              if (failed)
                return;
              if ("closed" === this.readyState)
                return;
              cleanup();
              this.setTransport(transport);
              transport.send([{ type: "upgrade" }]);
              this.emitReserved("upgrade", transport);
              transport = null;
              this.upgrading = false;
              this.flush();
            });
          } else {
            const err = new Error("probe error");
            err.transport = transport.name;
            this.emitReserved("upgradeError", err);
          }
        });
      }, "onTransportOpen");
      function freezeTransport() {
        if (failed)
          return;
        failed = true;
        cleanup();
        transport.close();
        transport = null;
      }
      __name(freezeTransport, "freezeTransport");
      const onerror = /* @__PURE__ */ __name((err) => {
        const error = new Error("probe error: " + err);
        error.transport = transport.name;
        freezeTransport();
        this.emitReserved("upgradeError", error);
      }, "onerror");
      function onTransportClose() {
        onerror("transport closed");
      }
      __name(onTransportClose, "onTransportClose");
      function onclose() {
        onerror("socket closed");
      }
      __name(onclose, "onclose");
      function onupgrade(to) {
        if (transport && to.name !== transport.name) {
          freezeTransport();
        }
      }
      __name(onupgrade, "onupgrade");
      const cleanup = /* @__PURE__ */ __name(() => {
        transport.removeListener("open", onTransportOpen);
        transport.removeListener("error", onerror);
        transport.removeListener("close", onTransportClose);
        this.off("close", onclose);
        this.off("upgrading", onupgrade);
      }, "cleanup");
      transport.once("open", onTransportOpen);
      transport.once("error", onerror);
      transport.once("close", onTransportClose);
      this.once("close", onclose);
      this.once("upgrading", onupgrade);
      if (this._upgrades.indexOf("webtransport") !== -1 && name !== "webtransport") {
        this.setTimeoutFn(() => {
          if (!failed) {
            transport.open();
          }
        }, 200);
      } else {
        transport.open();
      }
    }
    onHandshake(data) {
      this._upgrades = this._filterUpgrades(data.upgrades);
      super.onHandshake(data);
    }
    /**
     * Filters upgrades, returning only those matching client transports.
     *
     * @param {Array} upgrades - server upgrades
     * @private
     */
    _filterUpgrades(upgrades) {
      const filteredUpgrades = [];
      for (let i = 0; i < upgrades.length; i++) {
        if (~this.transports.indexOf(upgrades[i]))
          filteredUpgrades.push(upgrades[i]);
      }
      return filteredUpgrades;
    }
  };
  __name(_SocketWithUpgrade, "SocketWithUpgrade");
  let SocketWithUpgrade = _SocketWithUpgrade;
  let Socket$1 = (_b = class extends SocketWithUpgrade {
    constructor(uri, opts = {}) {
      const o = typeof uri === "object" ? uri : opts;
      if (!o.transports || o.transports && typeof o.transports[0] === "string") {
        o.transports = (o.transports || ["polling", "websocket", "webtransport"]).map((transportName) => transports[transportName]).filter((t) => !!t);
      }
      super(uri, o);
    }
  }, __name(_b, "Socket"), _b);
  function url(uri, path = "", loc) {
    let obj = uri;
    loc = loc || typeof location !== "undefined" && location;
    if (null == uri)
      uri = loc.protocol + "//" + loc.host;
    if (typeof uri === "string") {
      if ("/" === uri.charAt(0)) {
        if ("/" === uri.charAt(1)) {
          uri = loc.protocol + uri;
        } else {
          uri = loc.host + uri;
        }
      }
      if (!/^(https?|wss?):\/\//.test(uri)) {
        if ("undefined" !== typeof loc) {
          uri = loc.protocol + "//" + uri;
        } else {
          uri = "https://" + uri;
        }
      }
      obj = parse(uri);
    }
    if (!obj.port) {
      if (/^(http|ws)$/.test(obj.protocol)) {
        obj.port = "80";
      } else if (/^(http|ws)s$/.test(obj.protocol)) {
        obj.port = "443";
      }
    }
    obj.path = obj.path || "/";
    const ipv6 = obj.host.indexOf(":") !== -1;
    const host = ipv6 ? "[" + obj.host + "]" : obj.host;
    obj.id = obj.protocol + "://" + host + ":" + obj.port + path;
    obj.href = obj.protocol + "://" + host + (loc && loc.port === obj.port ? "" : ":" + obj.port);
    return obj;
  }
  __name(url, "url");
  const withNativeArrayBuffer = typeof ArrayBuffer === "function";
  const isView = /* @__PURE__ */ __name((obj) => {
    return typeof ArrayBuffer.isView === "function" ? ArrayBuffer.isView(obj) : obj.buffer instanceof ArrayBuffer;
  }, "isView");
  const toString$1 = Object.prototype.toString;
  const withNativeBlob = typeof Blob === "function" || typeof Blob !== "undefined" && toString$1.call(Blob) === "[object BlobConstructor]";
  const withNativeFile = typeof File === "function" || typeof File !== "undefined" && toString$1.call(File) === "[object FileConstructor]";
  function isBinary(obj) {
    return withNativeArrayBuffer && (obj instanceof ArrayBuffer || isView(obj)) || withNativeBlob && obj instanceof Blob || withNativeFile && obj instanceof File;
  }
  __name(isBinary, "isBinary");
  function hasBinary(obj, toJSON) {
    if (!obj || typeof obj !== "object") {
      return false;
    }
    if (Array.isArray(obj)) {
      for (let i = 0, l = obj.length; i < l; i++) {
        if (hasBinary(obj[i])) {
          return true;
        }
      }
      return false;
    }
    if (isBinary(obj)) {
      return true;
    }
    if (obj.toJSON && typeof obj.toJSON === "function" && arguments.length === 1) {
      return hasBinary(obj.toJSON(), true);
    }
    for (const key in obj) {
      if (Object.prototype.hasOwnProperty.call(obj, key) && hasBinary(obj[key])) {
        return true;
      }
    }
    return false;
  }
  __name(hasBinary, "hasBinary");
  function deconstructPacket(packet) {
    const buffers = [];
    const packetData = packet.data;
    const pack = packet;
    pack.data = _deconstructPacket(packetData, buffers);
    pack.attachments = buffers.length;
    return { packet: pack, buffers };
  }
  __name(deconstructPacket, "deconstructPacket");
  function _deconstructPacket(data, buffers) {
    if (!data)
      return data;
    if (isBinary(data)) {
      const placeholder = { _placeholder: true, num: buffers.length };
      buffers.push(data);
      return placeholder;
    } else if (Array.isArray(data)) {
      const newData = new Array(data.length);
      for (let i = 0; i < data.length; i++) {
        newData[i] = _deconstructPacket(data[i], buffers);
      }
      return newData;
    } else if (typeof data === "object" && !(data instanceof Date)) {
      const newData = {};
      for (const key in data) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          newData[key] = _deconstructPacket(data[key], buffers);
        }
      }
      return newData;
    }
    return data;
  }
  __name(_deconstructPacket, "_deconstructPacket");
  function reconstructPacket(packet, buffers) {
    packet.data = _reconstructPacket(packet.data, buffers);
    delete packet.attachments;
    return packet;
  }
  __name(reconstructPacket, "reconstructPacket");
  function _reconstructPacket(data, buffers) {
    if (!data)
      return data;
    if (data && data._placeholder === true) {
      const isIndexValid = typeof data.num === "number" && data.num >= 0 && data.num < buffers.length;
      if (isIndexValid) {
        return buffers[data.num];
      } else {
        throw new Error("illegal attachments");
      }
    } else if (Array.isArray(data)) {
      for (let i = 0; i < data.length; i++) {
        data[i] = _reconstructPacket(data[i], buffers);
      }
    } else if (typeof data === "object") {
      for (const key in data) {
        if (Object.prototype.hasOwnProperty.call(data, key)) {
          data[key] = _reconstructPacket(data[key], buffers);
        }
      }
    }
    return data;
  }
  __name(_reconstructPacket, "_reconstructPacket");
  const RESERVED_EVENTS$1 = [
    "connect",
    "connect_error",
    "disconnect",
    "disconnecting",
    "newListener",
    "removeListener"
    // used by the Node.js EventEmitter
  ];
  const protocol = 5;
  var PacketType;
  (function(PacketType2) {
    PacketType2[PacketType2["CONNECT"] = 0] = "CONNECT";
    PacketType2[PacketType2["DISCONNECT"] = 1] = "DISCONNECT";
    PacketType2[PacketType2["EVENT"] = 2] = "EVENT";
    PacketType2[PacketType2["ACK"] = 3] = "ACK";
    PacketType2[PacketType2["CONNECT_ERROR"] = 4] = "CONNECT_ERROR";
    PacketType2[PacketType2["BINARY_EVENT"] = 5] = "BINARY_EVENT";
    PacketType2[PacketType2["BINARY_ACK"] = 6] = "BINARY_ACK";
  })(PacketType || (PacketType = {}));
  const _Encoder = class _Encoder {
    /**
     * Encoder constructor
     *
     * @param {function} replacer - custom replacer to pass down to JSON.parse
     */
    constructor(replacer) {
      this.replacer = replacer;
    }
    /**
     * Encode a packet as a single string if non-binary, or as a
     * buffer sequence, depending on packet type.
     *
     * @param {Object} obj - packet object
     */
    encode(obj) {
      if (obj.type === PacketType.EVENT || obj.type === PacketType.ACK) {
        if (hasBinary(obj)) {
          return this.encodeAsBinary({
            type: obj.type === PacketType.EVENT ? PacketType.BINARY_EVENT : PacketType.BINARY_ACK,
            nsp: obj.nsp,
            data: obj.data,
            id: obj.id
          });
        }
      }
      return [this.encodeAsString(obj)];
    }
    /**
     * Encode packet as string.
     */
    encodeAsString(obj) {
      let str = "" + obj.type;
      if (obj.type === PacketType.BINARY_EVENT || obj.type === PacketType.BINARY_ACK) {
        str += obj.attachments + "-";
      }
      if (obj.nsp && "/" !== obj.nsp) {
        str += obj.nsp + ",";
      }
      if (null != obj.id) {
        str += obj.id;
      }
      if (null != obj.data) {
        str += JSON.stringify(obj.data, this.replacer);
      }
      return str;
    }
    /**
     * Encode packet as 'buffer sequence' by removing blobs, and
     * deconstructing packet into object with placeholders and
     * a list of buffers.
     */
    encodeAsBinary(obj) {
      const deconstruction = deconstructPacket(obj);
      const pack = this.encodeAsString(deconstruction.packet);
      const buffers = deconstruction.buffers;
      buffers.unshift(pack);
      return buffers;
    }
  };
  __name(_Encoder, "Encoder");
  let Encoder = _Encoder;
  function isObject$1(value2) {
    return Object.prototype.toString.call(value2) === "[object Object]";
  }
  __name(isObject$1, "isObject$1");
  const _Decoder = class _Decoder extends Emitter {
    /**
     * Decoder constructor
     *
     * @param {function} reviver - custom reviver to pass down to JSON.stringify
     */
    constructor(reviver) {
      super();
      this.reviver = reviver;
    }
    /**
     * Decodes an encoded packet string into packet JSON.
     *
     * @param {String} obj - encoded packet
     */
    add(obj) {
      let packet;
      if (typeof obj === "string") {
        if (this.reconstructor) {
          throw new Error("got plaintext data when reconstructing a packet");
        }
        packet = this.decodeString(obj);
        const isBinaryEvent = packet.type === PacketType.BINARY_EVENT;
        if (isBinaryEvent || packet.type === PacketType.BINARY_ACK) {
          packet.type = isBinaryEvent ? PacketType.EVENT : PacketType.ACK;
          this.reconstructor = new BinaryReconstructor(packet);
          if (packet.attachments === 0) {
            super.emitReserved("decoded", packet);
          }
        } else {
          super.emitReserved("decoded", packet);
        }
      } else if (isBinary(obj) || obj.base64) {
        if (!this.reconstructor) {
          throw new Error("got binary data when not reconstructing a packet");
        } else {
          packet = this.reconstructor.takeBinaryData(obj);
          if (packet) {
            this.reconstructor = null;
            super.emitReserved("decoded", packet);
          }
        }
      } else {
        throw new Error("Unknown type: " + obj);
      }
    }
    /**
     * Decode a packet String (JSON data)
     *
     * @param {String} str
     * @return {Object} packet
     */
    decodeString(str) {
      let i = 0;
      const p = {
        type: Number(str.charAt(0))
      };
      if (PacketType[p.type] === void 0) {
        throw new Error("unknown packet type " + p.type);
      }
      if (p.type === PacketType.BINARY_EVENT || p.type === PacketType.BINARY_ACK) {
        const start = i + 1;
        while (str.charAt(++i) !== "-" && i != str.length) {
        }
        const buf = str.substring(start, i);
        if (buf != Number(buf) || str.charAt(i) !== "-") {
          throw new Error("Illegal attachments");
        }
        p.attachments = Number(buf);
      }
      if ("/" === str.charAt(i + 1)) {
        const start = i + 1;
        while (++i) {
          const c = str.charAt(i);
          if ("," === c)
            break;
          if (i === str.length)
            break;
        }
        p.nsp = str.substring(start, i);
      } else {
        p.nsp = "/";
      }
      const next2 = str.charAt(i + 1);
      if ("" !== next2 && Number(next2) == next2) {
        const start = i + 1;
        while (++i) {
          const c = str.charAt(i);
          if (null == c || Number(c) != c) {
            --i;
            break;
          }
          if (i === str.length)
            break;
        }
        p.id = Number(str.substring(start, i + 1));
      }
      if (str.charAt(++i)) {
        const payload = this.tryParse(str.substr(i));
        if (_Decoder.isPayloadValid(p.type, payload)) {
          p.data = payload;
        } else {
          throw new Error("invalid payload");
        }
      }
      return p;
    }
    tryParse(str) {
      try {
        return JSON.parse(str, this.reviver);
      } catch (e) {
        return false;
      }
    }
    static isPayloadValid(type, payload) {
      switch (type) {
        case PacketType.CONNECT:
          return isObject$1(payload);
        case PacketType.DISCONNECT:
          return payload === void 0;
        case PacketType.CONNECT_ERROR:
          return typeof payload === "string" || isObject$1(payload);
        case PacketType.EVENT:
        case PacketType.BINARY_EVENT:
          return Array.isArray(payload) && (typeof payload[0] === "number" || typeof payload[0] === "string" && RESERVED_EVENTS$1.indexOf(payload[0]) === -1);
        case PacketType.ACK:
        case PacketType.BINARY_ACK:
          return Array.isArray(payload);
      }
    }
    /**
     * Deallocates a parser's resources
     */
    destroy() {
      if (this.reconstructor) {
        this.reconstructor.finishedReconstruction();
        this.reconstructor = null;
      }
    }
  };
  __name(_Decoder, "Decoder");
  let Decoder = _Decoder;
  const _BinaryReconstructor = class _BinaryReconstructor {
    constructor(packet) {
      this.packet = packet;
      this.buffers = [];
      this.reconPack = packet;
    }
    /**
     * Method to be called when binary data received from connection
     * after a BINARY_EVENT packet.
     *
     * @param {Buffer | ArrayBuffer} binData - the raw binary data received
     * @return {null | Object} returns null if more binary data is expected or
     *   a reconstructed packet object if all buffers have been received.
     */
    takeBinaryData(binData) {
      this.buffers.push(binData);
      if (this.buffers.length === this.reconPack.attachments) {
        const packet = reconstructPacket(this.reconPack, this.buffers);
        this.finishedReconstruction();
        return packet;
      }
      return null;
    }
    /**
     * Cleans up binary packet reconstruction variables.
     */
    finishedReconstruction() {
      this.reconPack = null;
      this.buffers = [];
    }
  };
  __name(_BinaryReconstructor, "BinaryReconstructor");
  let BinaryReconstructor = _BinaryReconstructor;
  const parser = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    Decoder,
    Encoder,
    get PacketType() {
      return PacketType;
    },
    protocol
  }, Symbol.toStringTag, { value: "Module" }));
  function on(obj, ev, fn) {
    obj.on(ev, fn);
    return /* @__PURE__ */ __name(function subDestroy() {
      obj.off(ev, fn);
    }, "subDestroy");
  }
  __name(on, "on");
  const RESERVED_EVENTS = Object.freeze({
    connect: 1,
    connect_error: 1,
    disconnect: 1,
    disconnecting: 1,
    // EventEmitter reserved events: https://nodejs.org/api/events.html#events_event_newlistener
    newListener: 1,
    removeListener: 1
  });
  const _Socket = class _Socket extends Emitter {
    /**
     * `Socket` constructor.
     */
    constructor(io, nsp, opts) {
      super();
      this.connected = false;
      this.recovered = false;
      this.receiveBuffer = [];
      this.sendBuffer = [];
      this._queue = [];
      this._queueSeq = 0;
      this.ids = 0;
      this.acks = {};
      this.flags = {};
      this.io = io;
      this.nsp = nsp;
      if (opts && opts.auth) {
        this.auth = opts.auth;
      }
      this._opts = Object.assign({}, opts);
      if (this.io._autoConnect)
        this.open();
    }
    /**
     * Whether the socket is currently disconnected
     *
     * @example
     * const socket = io();
     *
     * socket.on("connect", () => {
     *   console.log(socket.disconnected); // false
     * });
     *
     * socket.on("disconnect", () => {
     *   console.log(socket.disconnected); // true
     * });
     */
    get disconnected() {
      return !this.connected;
    }
    /**
     * Subscribe to open, close and packet events
     *
     * @private
     */
    subEvents() {
      if (this.subs)
        return;
      const io = this.io;
      this.subs = [
        on(io, "open", this.onopen.bind(this)),
        on(io, "packet", this.onpacket.bind(this)),
        on(io, "error", this.onerror.bind(this)),
        on(io, "close", this.onclose.bind(this))
      ];
    }
    /**
     * Whether the Socket will try to reconnect when its Manager connects or reconnects.
     *
     * @example
     * const socket = io();
     *
     * console.log(socket.active); // true
     *
     * socket.on("disconnect", (reason) => {
     *   if (reason === "io server disconnect") {
     *     // the disconnection was initiated by the server, you need to manually reconnect
     *     console.log(socket.active); // false
     *   }
     *   // else the socket will automatically try to reconnect
     *   console.log(socket.active); // true
     * });
     */
    get active() {
      return !!this.subs;
    }
    /**
     * "Opens" the socket.
     *
     * @example
     * const socket = io({
     *   autoConnect: false
     * });
     *
     * socket.connect();
     */
    connect() {
      if (this.connected)
        return this;
      this.subEvents();
      if (!this.io["_reconnecting"])
        this.io.open();
      if ("open" === this.io._readyState)
        this.onopen();
      return this;
    }
    /**
     * Alias for {@link connect()}.
     */
    open() {
      return this.connect();
    }
    /**
     * Sends a `message` event.
     *
     * This method mimics the WebSocket.send() method.
     *
     * @see https://developer.mozilla.org/en-US/docs/Web/API/WebSocket/send
     *
     * @example
     * socket.send("hello");
     *
     * // this is equivalent to
     * socket.emit("message", "hello");
     *
     * @return self
     */
    send(...args) {
      args.unshift("message");
      this.emit.apply(this, args);
      return this;
    }
    /**
     * Override `emit`.
     * If the event is in `events`, it's emitted normally.
     *
     * @example
     * socket.emit("hello", "world");
     *
     * // all serializable datastructures are supported (no need to call JSON.stringify)
     * socket.emit("hello", 1, "2", { 3: ["4"], 5: Uint8Array.from([6]) });
     *
     * // with an acknowledgement from the server
     * socket.emit("hello", "world", (val) => {
     *   // ...
     * });
     *
     * @return self
     */
    emit(ev, ...args) {
      var _a2, _b2, _c2;
      if (RESERVED_EVENTS.hasOwnProperty(ev)) {
        throw new Error('"' + ev.toString() + '" is a reserved event name');
      }
      args.unshift(ev);
      if (this._opts.retries && !this.flags.fromQueue && !this.flags.volatile) {
        this._addToQueue(args);
        return this;
      }
      const packet = {
        type: PacketType.EVENT,
        data: args
      };
      packet.options = {};
      packet.options.compress = this.flags.compress !== false;
      if ("function" === typeof args[args.length - 1]) {
        const id = this.ids++;
        const ack = args.pop();
        this._registerAckCallback(id, ack);
        packet.id = id;
      }
      const isTransportWritable = (_b2 = (_a2 = this.io.engine) === null || _a2 === void 0 ? void 0 : _a2.transport) === null || _b2 === void 0 ? void 0 : _b2.writable;
      const isConnected = this.connected && !((_c2 = this.io.engine) === null || _c2 === void 0 ? void 0 : _c2._hasPingExpired());
      const discardPacket = this.flags.volatile && !isTransportWritable;
      if (discardPacket) ;
      else if (isConnected) {
        this.notifyOutgoingListeners(packet);
        this.packet(packet);
      } else {
        this.sendBuffer.push(packet);
      }
      this.flags = {};
      return this;
    }
    /**
     * @private
     */
    _registerAckCallback(id, ack) {
      var _a2;
      const timeout = (_a2 = this.flags.timeout) !== null && _a2 !== void 0 ? _a2 : this._opts.ackTimeout;
      if (timeout === void 0) {
        this.acks[id] = ack;
        return;
      }
      const timer = this.io.setTimeoutFn(() => {
        delete this.acks[id];
        for (let i = 0; i < this.sendBuffer.length; i++) {
          if (this.sendBuffer[i].id === id) {
            this.sendBuffer.splice(i, 1);
          }
        }
        ack.call(this, new Error("operation has timed out"));
      }, timeout);
      const fn = /* @__PURE__ */ __name((...args) => {
        this.io.clearTimeoutFn(timer);
        ack.apply(this, args);
      }, "fn");
      fn.withError = true;
      this.acks[id] = fn;
    }
    /**
     * Emits an event and waits for an acknowledgement
     *
     * @example
     * // without timeout
     * const response = await socket.emitWithAck("hello", "world");
     *
     * // with a specific timeout
     * try {
     *   const response = await socket.timeout(1000).emitWithAck("hello", "world");
     * } catch (err) {
     *   // the server did not acknowledge the event in the given delay
     * }
     *
     * @return a Promise that will be fulfilled when the server acknowledges the event
     */
    emitWithAck(ev, ...args) {
      return new Promise((resolve, reject) => {
        const fn = /* @__PURE__ */ __name((arg1, arg2) => {
          return arg1 ? reject(arg1) : resolve(arg2);
        }, "fn");
        fn.withError = true;
        args.push(fn);
        this.emit(ev, ...args);
      });
    }
    /**
     * Add the packet to the queue.
     * @param args
     * @private
     */
    _addToQueue(args) {
      let ack;
      if (typeof args[args.length - 1] === "function") {
        ack = args.pop();
      }
      const packet = {
        id: this._queueSeq++,
        tryCount: 0,
        pending: false,
        args,
        flags: Object.assign({ fromQueue: true }, this.flags)
      };
      args.push((err, ...responseArgs) => {
        if (packet !== this._queue[0]) {
          return;
        }
        const hasError = err !== null;
        if (hasError) {
          if (packet.tryCount > this._opts.retries) {
            this._queue.shift();
            if (ack) {
              ack(err);
            }
          }
        } else {
          this._queue.shift();
          if (ack) {
            ack(null, ...responseArgs);
          }
        }
        packet.pending = false;
        return this._drainQueue();
      });
      this._queue.push(packet);
      this._drainQueue();
    }
    /**
     * Send the first packet of the queue, and wait for an acknowledgement from the server.
     * @param force - whether to resend a packet that has not been acknowledged yet
     *
     * @private
     */
    _drainQueue(force = false) {
      if (!this.connected || this._queue.length === 0) {
        return;
      }
      const packet = this._queue[0];
      if (packet.pending && !force) {
        return;
      }
      packet.pending = true;
      packet.tryCount++;
      this.flags = packet.flags;
      this.emit.apply(this, packet.args);
    }
    /**
     * Sends a packet.
     *
     * @param packet
     * @private
     */
    packet(packet) {
      packet.nsp = this.nsp;
      this.io._packet(packet);
    }
    /**
     * Called upon engine `open`.
     *
     * @private
     */
    onopen() {
      if (typeof this.auth == "function") {
        this.auth((data) => {
          this._sendConnectPacket(data);
        });
      } else {
        this._sendConnectPacket(this.auth);
      }
    }
    /**
     * Sends a CONNECT packet to initiate the Socket.IO session.
     *
     * @param data
     * @private
     */
    _sendConnectPacket(data) {
      this.packet({
        type: PacketType.CONNECT,
        data: this._pid ? Object.assign({ pid: this._pid, offset: this._lastOffset }, data) : data
      });
    }
    /**
     * Called upon engine or manager `error`.
     *
     * @param err
     * @private
     */
    onerror(err) {
      if (!this.connected) {
        this.emitReserved("connect_error", err);
      }
    }
    /**
     * Called upon engine `close`.
     *
     * @param reason
     * @param description
     * @private
     */
    onclose(reason, description) {
      this.connected = false;
      delete this.id;
      this.emitReserved("disconnect", reason, description);
      this._clearAcks();
    }
    /**
     * Clears the acknowledgement handlers upon disconnection, since the client will never receive an acknowledgement from
     * the server.
     *
     * @private
     */
    _clearAcks() {
      Object.keys(this.acks).forEach((id) => {
        const isBuffered = this.sendBuffer.some((packet) => String(packet.id) === id);
        if (!isBuffered) {
          const ack = this.acks[id];
          delete this.acks[id];
          if (ack.withError) {
            ack.call(this, new Error("socket has been disconnected"));
          }
        }
      });
    }
    /**
     * Called with socket packet.
     *
     * @param packet
     * @private
     */
    onpacket(packet) {
      const sameNamespace = packet.nsp === this.nsp;
      if (!sameNamespace)
        return;
      switch (packet.type) {
        case PacketType.CONNECT:
          if (packet.data && packet.data.sid) {
            this.onconnect(packet.data.sid, packet.data.pid);
          } else {
            this.emitReserved("connect_error", new Error("It seems you are trying to reach a Socket.IO server in v2.x with a v3.x client, but they are not compatible (more information here: https://socket.io/docs/v3/migrating-from-2-x-to-3-0/)"));
          }
          break;
        case PacketType.EVENT:
        case PacketType.BINARY_EVENT:
          this.onevent(packet);
          break;
        case PacketType.ACK:
        case PacketType.BINARY_ACK:
          this.onack(packet);
          break;
        case PacketType.DISCONNECT:
          this.ondisconnect();
          break;
        case PacketType.CONNECT_ERROR:
          this.destroy();
          const err = new Error(packet.data.message);
          err.data = packet.data.data;
          this.emitReserved("connect_error", err);
          break;
      }
    }
    /**
     * Called upon a server event.
     *
     * @param packet
     * @private
     */
    onevent(packet) {
      const args = packet.data || [];
      if (null != packet.id) {
        args.push(this.ack(packet.id));
      }
      if (this.connected) {
        this.emitEvent(args);
      } else {
        this.receiveBuffer.push(Object.freeze(args));
      }
    }
    emitEvent(args) {
      if (this._anyListeners && this._anyListeners.length) {
        const listeners = this._anyListeners.slice();
        for (const listener of listeners) {
          listener.apply(this, args);
        }
      }
      super.emit.apply(this, args);
      if (this._pid && args.length && typeof args[args.length - 1] === "string") {
        this._lastOffset = args[args.length - 1];
      }
    }
    /**
     * Produces an ack callback to emit with an event.
     *
     * @private
     */
    ack(id) {
      const self2 = this;
      let sent = false;
      return function(...args) {
        if (sent)
          return;
        sent = true;
        self2.packet({
          type: PacketType.ACK,
          id,
          data: args
        });
      };
    }
    /**
     * Called upon a server acknowledgement.
     *
     * @param packet
     * @private
     */
    onack(packet) {
      const ack = this.acks[packet.id];
      if (typeof ack !== "function") {
        return;
      }
      delete this.acks[packet.id];
      if (ack.withError) {
        packet.data.unshift(null);
      }
      ack.apply(this, packet.data);
    }
    /**
     * Called upon server connect.
     *
     * @private
     */
    onconnect(id, pid) {
      this.id = id;
      this.recovered = pid && this._pid === pid;
      this._pid = pid;
      this.connected = true;
      this.emitBuffered();
      this.emitReserved("connect");
      this._drainQueue(true);
    }
    /**
     * Emit buffered events (received and emitted).
     *
     * @private
     */
    emitBuffered() {
      this.receiveBuffer.forEach((args) => this.emitEvent(args));
      this.receiveBuffer = [];
      this.sendBuffer.forEach((packet) => {
        this.notifyOutgoingListeners(packet);
        this.packet(packet);
      });
      this.sendBuffer = [];
    }
    /**
     * Called upon server disconnect.
     *
     * @private
     */
    ondisconnect() {
      this.destroy();
      this.onclose("io server disconnect");
    }
    /**
     * Called upon forced client/server side disconnections,
     * this method ensures the manager stops tracking us and
     * that reconnections don't get triggered for this.
     *
     * @private
     */
    destroy() {
      if (this.subs) {
        this.subs.forEach((subDestroy) => subDestroy());
        this.subs = void 0;
      }
      this.io["_destroy"](this);
    }
    /**
     * Disconnects the socket manually. In that case, the socket will not try to reconnect.
     *
     * If this is the last active Socket instance of the {@link Manager}, the low-level connection will be closed.
     *
     * @example
     * const socket = io();
     *
     * socket.on("disconnect", (reason) => {
     *   // console.log(reason); prints "io client disconnect"
     * });
     *
     * socket.disconnect();
     *
     * @return self
     */
    disconnect() {
      if (this.connected) {
        this.packet({ type: PacketType.DISCONNECT });
      }
      this.destroy();
      if (this.connected) {
        this.onclose("io client disconnect");
      }
      return this;
    }
    /**
     * Alias for {@link disconnect()}.
     *
     * @return self
     */
    close() {
      return this.disconnect();
    }
    /**
     * Sets the compress flag.
     *
     * @example
     * socket.compress(false).emit("hello");
     *
     * @param compress - if `true`, compresses the sending data
     * @return self
     */
    compress(compress) {
      this.flags.compress = compress;
      return this;
    }
    /**
     * Sets a modifier for a subsequent event emission that the event message will be dropped when this socket is not
     * ready to send messages.
     *
     * @example
     * socket.volatile.emit("hello"); // the server may or may not receive it
     *
     * @returns self
     */
    get volatile() {
      this.flags.volatile = true;
      return this;
    }
    /**
     * Sets a modifier for a subsequent event emission that the callback will be called with an error when the
     * given number of milliseconds have elapsed without an acknowledgement from the server:
     *
     * @example
     * socket.timeout(5000).emit("my-event", (err) => {
     *   if (err) {
     *     // the server did not acknowledge the event in the given delay
     *   }
     * });
     *
     * @returns self
     */
    timeout(timeout) {
      this.flags.timeout = timeout;
      return this;
    }
    /**
     * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
     * callback.
     *
     * @example
     * socket.onAny((event, ...args) => {
     *   console.log(`got ${event}`);
     * });
     *
     * @param listener
     */
    onAny(listener) {
      this._anyListeners = this._anyListeners || [];
      this._anyListeners.push(listener);
      return this;
    }
    /**
     * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
     * callback. The listener is added to the beginning of the listeners array.
     *
     * @example
     * socket.prependAny((event, ...args) => {
     *   console.log(`got event ${event}`);
     * });
     *
     * @param listener
     */
    prependAny(listener) {
      this._anyListeners = this._anyListeners || [];
      this._anyListeners.unshift(listener);
      return this;
    }
    /**
     * Removes the listener that will be fired when any event is emitted.
     *
     * @example
     * const catchAllListener = (event, ...args) => {
     *   console.log(`got event ${event}`);
     * }
     *
     * socket.onAny(catchAllListener);
     *
     * // remove a specific listener
     * socket.offAny(catchAllListener);
     *
     * // or remove all listeners
     * socket.offAny();
     *
     * @param listener
     */
    offAny(listener) {
      if (!this._anyListeners) {
        return this;
      }
      if (listener) {
        const listeners = this._anyListeners;
        for (let i = 0; i < listeners.length; i++) {
          if (listener === listeners[i]) {
            listeners.splice(i, 1);
            return this;
          }
        }
      } else {
        this._anyListeners = [];
      }
      return this;
    }
    /**
     * Returns an array of listeners that are listening for any event that is specified. This array can be manipulated,
     * e.g. to remove listeners.
     */
    listenersAny() {
      return this._anyListeners || [];
    }
    /**
     * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
     * callback.
     *
     * Note: acknowledgements sent to the server are not included.
     *
     * @example
     * socket.onAnyOutgoing((event, ...args) => {
     *   console.log(`sent event ${event}`);
     * });
     *
     * @param listener
     */
    onAnyOutgoing(listener) {
      this._anyOutgoingListeners = this._anyOutgoingListeners || [];
      this._anyOutgoingListeners.push(listener);
      return this;
    }
    /**
     * Adds a listener that will be fired when any event is emitted. The event name is passed as the first argument to the
     * callback. The listener is added to the beginning of the listeners array.
     *
     * Note: acknowledgements sent to the server are not included.
     *
     * @example
     * socket.prependAnyOutgoing((event, ...args) => {
     *   console.log(`sent event ${event}`);
     * });
     *
     * @param listener
     */
    prependAnyOutgoing(listener) {
      this._anyOutgoingListeners = this._anyOutgoingListeners || [];
      this._anyOutgoingListeners.unshift(listener);
      return this;
    }
    /**
     * Removes the listener that will be fired when any event is emitted.
     *
     * @example
     * const catchAllListener = (event, ...args) => {
     *   console.log(`sent event ${event}`);
     * }
     *
     * socket.onAnyOutgoing(catchAllListener);
     *
     * // remove a specific listener
     * socket.offAnyOutgoing(catchAllListener);
     *
     * // or remove all listeners
     * socket.offAnyOutgoing();
     *
     * @param [listener] - the catch-all listener (optional)
     */
    offAnyOutgoing(listener) {
      if (!this._anyOutgoingListeners) {
        return this;
      }
      if (listener) {
        const listeners = this._anyOutgoingListeners;
        for (let i = 0; i < listeners.length; i++) {
          if (listener === listeners[i]) {
            listeners.splice(i, 1);
            return this;
          }
        }
      } else {
        this._anyOutgoingListeners = [];
      }
      return this;
    }
    /**
     * Returns an array of listeners that are listening for any event that is specified. This array can be manipulated,
     * e.g. to remove listeners.
     */
    listenersAnyOutgoing() {
      return this._anyOutgoingListeners || [];
    }
    /**
     * Notify the listeners for each packet sent
     *
     * @param packet
     *
     * @private
     */
    notifyOutgoingListeners(packet) {
      if (this._anyOutgoingListeners && this._anyOutgoingListeners.length) {
        const listeners = this._anyOutgoingListeners.slice();
        for (const listener of listeners) {
          listener.apply(this, packet.data);
        }
      }
    }
  };
  __name(_Socket, "Socket");
  let Socket = _Socket;
  function Backoff(opts) {
    opts = opts || {};
    this.ms = opts.min || 100;
    this.max = opts.max || 1e4;
    this.factor = opts.factor || 2;
    this.jitter = opts.jitter > 0 && opts.jitter <= 1 ? opts.jitter : 0;
    this.attempts = 0;
  }
  __name(Backoff, "Backoff");
  Backoff.prototype.duration = function() {
    var ms = this.ms * Math.pow(this.factor, this.attempts++);
    if (this.jitter) {
      var rand = Math.random();
      var deviation = Math.floor(rand * this.jitter * ms);
      ms = (Math.floor(rand * 10) & 1) == 0 ? ms - deviation : ms + deviation;
    }
    return Math.min(ms, this.max) | 0;
  };
  Backoff.prototype.reset = function() {
    this.attempts = 0;
  };
  Backoff.prototype.setMin = function(min) {
    this.ms = min;
  };
  Backoff.prototype.setMax = function(max) {
    this.max = max;
  };
  Backoff.prototype.setJitter = function(jitter) {
    this.jitter = jitter;
  };
  const _Manager = class _Manager extends Emitter {
    constructor(uri, opts) {
      var _a2;
      super();
      this.nsps = {};
      this.subs = [];
      if (uri && "object" === typeof uri) {
        opts = uri;
        uri = void 0;
      }
      opts = opts || {};
      opts.path = opts.path || "/socket.io";
      this.opts = opts;
      installTimerFunctions(this, opts);
      this.reconnection(opts.reconnection !== false);
      this.reconnectionAttempts(opts.reconnectionAttempts || Infinity);
      this.reconnectionDelay(opts.reconnectionDelay || 1e3);
      this.reconnectionDelayMax(opts.reconnectionDelayMax || 5e3);
      this.randomizationFactor((_a2 = opts.randomizationFactor) !== null && _a2 !== void 0 ? _a2 : 0.5);
      this.backoff = new Backoff({
        min: this.reconnectionDelay(),
        max: this.reconnectionDelayMax(),
        jitter: this.randomizationFactor()
      });
      this.timeout(null == opts.timeout ? 2e4 : opts.timeout);
      this._readyState = "closed";
      this.uri = uri;
      const _parser = opts.parser || parser;
      this.encoder = new _parser.Encoder();
      this.decoder = new _parser.Decoder();
      this._autoConnect = opts.autoConnect !== false;
      if (this._autoConnect)
        this.open();
    }
    reconnection(v) {
      if (!arguments.length)
        return this._reconnection;
      this._reconnection = !!v;
      if (!v) {
        this.skipReconnect = true;
      }
      return this;
    }
    reconnectionAttempts(v) {
      if (v === void 0)
        return this._reconnectionAttempts;
      this._reconnectionAttempts = v;
      return this;
    }
    reconnectionDelay(v) {
      var _a2;
      if (v === void 0)
        return this._reconnectionDelay;
      this._reconnectionDelay = v;
      (_a2 = this.backoff) === null || _a2 === void 0 ? void 0 : _a2.setMin(v);
      return this;
    }
    randomizationFactor(v) {
      var _a2;
      if (v === void 0)
        return this._randomizationFactor;
      this._randomizationFactor = v;
      (_a2 = this.backoff) === null || _a2 === void 0 ? void 0 : _a2.setJitter(v);
      return this;
    }
    reconnectionDelayMax(v) {
      var _a2;
      if (v === void 0)
        return this._reconnectionDelayMax;
      this._reconnectionDelayMax = v;
      (_a2 = this.backoff) === null || _a2 === void 0 ? void 0 : _a2.setMax(v);
      return this;
    }
    timeout(v) {
      if (!arguments.length)
        return this._timeout;
      this._timeout = v;
      return this;
    }
    /**
     * Starts trying to reconnect if reconnection is enabled and we have not
     * started reconnecting yet
     *
     * @private
     */
    maybeReconnectOnOpen() {
      if (!this._reconnecting && this._reconnection && this.backoff.attempts === 0) {
        this.reconnect();
      }
    }
    /**
     * Sets the current transport `socket`.
     *
     * @param {Function} fn - optional, callback
     * @return self
     * @public
     */
    open(fn) {
      if (~this._readyState.indexOf("open"))
        return this;
      this.engine = new Socket$1(this.uri, this.opts);
      const socket = this.engine;
      const self2 = this;
      this._readyState = "opening";
      this.skipReconnect = false;
      const openSubDestroy = on(socket, "open", function() {
        self2.onopen();
        fn && fn();
      });
      const onError = /* @__PURE__ */ __name((err) => {
        this.cleanup();
        this._readyState = "closed";
        this.emitReserved("error", err);
        if (fn) {
          fn(err);
        } else {
          this.maybeReconnectOnOpen();
        }
      }, "onError");
      const errorSub = on(socket, "error", onError);
      if (false !== this._timeout) {
        const timeout = this._timeout;
        const timer = this.setTimeoutFn(() => {
          openSubDestroy();
          onError(new Error("timeout"));
          socket.close();
        }, timeout);
        if (this.opts.autoUnref) {
          timer.unref();
        }
        this.subs.push(() => {
          this.clearTimeoutFn(timer);
        });
      }
      this.subs.push(openSubDestroy);
      this.subs.push(errorSub);
      return this;
    }
    /**
     * Alias for open()
     *
     * @return self
     * @public
     */
    connect(fn) {
      return this.open(fn);
    }
    /**
     * Called upon transport open.
     *
     * @private
     */
    onopen() {
      this.cleanup();
      this._readyState = "open";
      this.emitReserved("open");
      const socket = this.engine;
      this.subs.push(
        on(socket, "ping", this.onping.bind(this)),
        on(socket, "data", this.ondata.bind(this)),
        on(socket, "error", this.onerror.bind(this)),
        on(socket, "close", this.onclose.bind(this)),
        // @ts-ignore
        on(this.decoder, "decoded", this.ondecoded.bind(this))
      );
    }
    /**
     * Called upon a ping.
     *
     * @private
     */
    onping() {
      this.emitReserved("ping");
    }
    /**
     * Called with data.
     *
     * @private
     */
    ondata(data) {
      try {
        this.decoder.add(data);
      } catch (e) {
        this.onclose("parse error", e);
      }
    }
    /**
     * Called when parser fully decodes a packet.
     *
     * @private
     */
    ondecoded(packet) {
      nextTick(() => {
        this.emitReserved("packet", packet);
      }, this.setTimeoutFn);
    }
    /**
     * Called upon socket error.
     *
     * @private
     */
    onerror(err) {
      this.emitReserved("error", err);
    }
    /**
     * Creates a new socket for the given `nsp`.
     *
     * @return {Socket}
     * @public
     */
    socket(nsp, opts) {
      let socket = this.nsps[nsp];
      if (!socket) {
        socket = new Socket(this, nsp, opts);
        this.nsps[nsp] = socket;
      } else if (this._autoConnect && !socket.active) {
        socket.connect();
      }
      return socket;
    }
    /**
     * Called upon a socket close.
     *
     * @param socket
     * @private
     */
    _destroy(socket) {
      const nsps = Object.keys(this.nsps);
      for (const nsp of nsps) {
        const socket2 = this.nsps[nsp];
        if (socket2.active) {
          return;
        }
      }
      this._close();
    }
    /**
     * Writes a packet.
     *
     * @param packet
     * @private
     */
    _packet(packet) {
      const encodedPackets = this.encoder.encode(packet);
      for (let i = 0; i < encodedPackets.length; i++) {
        this.engine.write(encodedPackets[i], packet.options);
      }
    }
    /**
     * Clean up transport subscriptions and packet buffer.
     *
     * @private
     */
    cleanup() {
      this.subs.forEach((subDestroy) => subDestroy());
      this.subs.length = 0;
      this.decoder.destroy();
    }
    /**
     * Close the current socket.
     *
     * @private
     */
    _close() {
      this.skipReconnect = true;
      this._reconnecting = false;
      this.onclose("forced close");
    }
    /**
     * Alias for close()
     *
     * @private
     */
    disconnect() {
      return this._close();
    }
    /**
     * Called when:
     *
     * - the low-level engine is closed
     * - the parser encountered a badly formatted packet
     * - all sockets are disconnected
     *
     * @private
     */
    onclose(reason, description) {
      var _a2;
      this.cleanup();
      (_a2 = this.engine) === null || _a2 === void 0 ? void 0 : _a2.close();
      this.backoff.reset();
      this._readyState = "closed";
      this.emitReserved("close", reason, description);
      if (this._reconnection && !this.skipReconnect) {
        this.reconnect();
      }
    }
    /**
     * Attempt a reconnection.
     *
     * @private
     */
    reconnect() {
      if (this._reconnecting || this.skipReconnect)
        return this;
      const self2 = this;
      if (this.backoff.attempts >= this._reconnectionAttempts) {
        this.backoff.reset();
        this.emitReserved("reconnect_failed");
        this._reconnecting = false;
      } else {
        const delay = this.backoff.duration();
        this._reconnecting = true;
        const timer = this.setTimeoutFn(() => {
          if (self2.skipReconnect)
            return;
          this.emitReserved("reconnect_attempt", self2.backoff.attempts);
          if (self2.skipReconnect)
            return;
          self2.open((err) => {
            if (err) {
              self2._reconnecting = false;
              self2.reconnect();
              this.emitReserved("reconnect_error", err);
            } else {
              self2.onreconnect();
            }
          });
        }, delay);
        if (this.opts.autoUnref) {
          timer.unref();
        }
        this.subs.push(() => {
          this.clearTimeoutFn(timer);
        });
      }
    }
    /**
     * Called upon successful reconnect.
     *
     * @private
     */
    onreconnect() {
      const attempt = this.backoff.attempts;
      this._reconnecting = false;
      this.backoff.reset();
      this.emitReserved("reconnect", attempt);
    }
  };
  __name(_Manager, "Manager");
  let Manager = _Manager;
  const cache = {};
  function lookup(uri, opts) {
    if (typeof uri === "object") {
      opts = uri;
      uri = void 0;
    }
    opts = opts || {};
    const parsed = url(uri, opts.path || "/socket.io");
    const source = parsed.source;
    const id = parsed.id;
    const path = parsed.path;
    const sameNamespace = cache[id] && path in cache[id]["nsps"];
    const newConnection = opts.forceNew || opts["force new connection"] || false === opts.multiplex || sameNamespace;
    let io;
    if (newConnection) {
      io = new Manager(source, opts);
    } else {
      if (!cache[id]) {
        cache[id] = new Manager(source, opts);
      }
      io = cache[id];
    }
    if (parsed.query && !opts.query) {
      opts.query = parsed.queryKey;
    }
    return io.socket(parsed.path, opts);
  }
  __name(lookup, "lookup");
  Object.assign(lookup, {
    Manager,
    Socket,
    io: lookup,
    connect: lookup
  });
  var __spreadArray = function(to, from2, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from2.length, ar; i < l; i++) {
      if (ar || !(i in from2)) {
        if (!ar) ar = Array.prototype.slice.call(from2, 0, i);
        ar[i] = from2[i];
      }
    }
    return to.concat(ar || Array.prototype.slice.call(from2));
  };
  var BrowserInfo = (
    /** @class */
    /* @__PURE__ */ function() {
      function BrowserInfo2(name, version2, os) {
        this.name = name;
        this.version = version2;
        this.os = os;
        this.type = "browser";
      }
      __name(BrowserInfo2, "BrowserInfo");
      return BrowserInfo2;
    }()
  );
  var NodeInfo = (
    /** @class */
    /* @__PURE__ */ function() {
      function NodeInfo2(version2) {
        this.version = version2;
        this.type = "node";
        this.name = "node";
        this.os = process.platform;
      }
      __name(NodeInfo2, "NodeInfo");
      return NodeInfo2;
    }()
  );
  var SearchBotDeviceInfo = (
    /** @class */
    /* @__PURE__ */ function() {
      function SearchBotDeviceInfo2(name, version2, os, bot) {
        this.name = name;
        this.version = version2;
        this.os = os;
        this.bot = bot;
        this.type = "bot-device";
      }
      __name(SearchBotDeviceInfo2, "SearchBotDeviceInfo");
      return SearchBotDeviceInfo2;
    }()
  );
  var BotInfo = (
    /** @class */
    /* @__PURE__ */ function() {
      function BotInfo2() {
        this.type = "bot";
        this.bot = true;
        this.name = "bot";
        this.version = null;
        this.os = null;
      }
      __name(BotInfo2, "BotInfo");
      return BotInfo2;
    }()
  );
  var ReactNativeInfo = (
    /** @class */
    /* @__PURE__ */ function() {
      function ReactNativeInfo2() {
        this.type = "react-native";
        this.name = "react-native";
        this.version = null;
        this.os = null;
      }
      __name(ReactNativeInfo2, "ReactNativeInfo");
      return ReactNativeInfo2;
    }()
  );
  var SEARCHBOX_UA_REGEX = /alexa|bot|crawl(er|ing)|facebookexternalhit|feedburner|google web preview|nagios|postrank|pingdom|slurp|spider|yahoo!|yandex/;
  var SEARCHBOT_OS_REGEX = /(nuhk|curl|Googlebot|Yammybot|Openbot|Slurp|MSNBot|Ask\ Jeeves\/Teoma|ia_archiver)/;
  var REQUIRED_VERSION_PARTS = 3;
  var userAgentRules = [
    ["aol", /AOLShield\/([0-9\._]+)/],
    ["edge", /Edge\/([0-9\._]+)/],
    ["edge-ios", /EdgiOS\/([0-9\._]+)/],
    ["yandexbrowser", /YaBrowser\/([0-9\._]+)/],
    ["kakaotalk", /KAKAOTALK\s([0-9\.]+)/],
    ["samsung", /SamsungBrowser\/([0-9\.]+)/],
    ["silk", /\bSilk\/([0-9._-]+)\b/],
    ["miui", /MiuiBrowser\/([0-9\.]+)$/],
    ["beaker", /BeakerBrowser\/([0-9\.]+)/],
    ["edge-chromium", /EdgA?\/([0-9\.]+)/],
    [
      "chromium-webview",
      /(?!Chrom.*OPR)wv\).*Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/
    ],
    ["chrome", /(?!Chrom.*OPR)Chrom(?:e|ium)\/([0-9\.]+)(:?\s|$)/],
    ["phantomjs", /PhantomJS\/([0-9\.]+)(:?\s|$)/],
    ["crios", /CriOS\/([0-9\.]+)(:?\s|$)/],
    ["firefox", /Firefox\/([0-9\.]+)(?:\s|$)/],
    ["fxios", /FxiOS\/([0-9\.]+)/],
    ["opera-mini", /Opera Mini.*Version\/([0-9\.]+)/],
    ["opera", /Opera\/([0-9\.]+)(?:\s|$)/],
    ["opera", /OPR\/([0-9\.]+)(:?\s|$)/],
    ["pie", /^Microsoft Pocket Internet Explorer\/(\d+\.\d+)$/],
    ["pie", /^Mozilla\/\d\.\d+\s\(compatible;\s(?:MSP?IE|MSInternet Explorer) (\d+\.\d+);.*Windows CE.*\)$/],
    ["netfront", /^Mozilla\/\d\.\d+.*NetFront\/(\d.\d)/],
    ["ie", /Trident\/7\.0.*rv\:([0-9\.]+).*\).*Gecko$/],
    ["ie", /MSIE\s([0-9\.]+);.*Trident\/[4-7].0/],
    ["ie", /MSIE\s(7\.0)/],
    ["bb10", /BB10;\sTouch.*Version\/([0-9\.]+)/],
    ["android", /Android\s([0-9\.]+)/],
    ["ios", /Version\/([0-9\._]+).*Mobile.*Safari.*/],
    ["safari", /Version\/([0-9\._]+).*Safari/],
    ["facebook", /FB[AS]V\/([0-9\.]+)/],
    ["instagram", /Instagram\s([0-9\.]+)/],
    ["ios-webview", /AppleWebKit\/([0-9\.]+).*Mobile/],
    ["ios-webview", /AppleWebKit\/([0-9\.]+).*Gecko\)$/],
    ["curl", /^curl\/([0-9\.]+)$/],
    ["searchbot", SEARCHBOX_UA_REGEX]
  ];
  var operatingSystemRules = [
    ["iOS", /iP(hone|od|ad)/],
    ["Android OS", /Android/],
    ["BlackBerry OS", /BlackBerry|BB10/],
    ["Windows Mobile", /IEMobile/],
    ["Amazon OS", /Kindle/],
    ["Windows 3.11", /Win16/],
    ["Windows 95", /(Windows 95)|(Win95)|(Windows_95)/],
    ["Windows 98", /(Windows 98)|(Win98)/],
    ["Windows 2000", /(Windows NT 5.0)|(Windows 2000)/],
    ["Windows XP", /(Windows NT 5.1)|(Windows XP)/],
    ["Windows Server 2003", /(Windows NT 5.2)/],
    ["Windows Vista", /(Windows NT 6.0)/],
    ["Windows 7", /(Windows NT 6.1)/],
    ["Windows 8", /(Windows NT 6.2)/],
    ["Windows 8.1", /(Windows NT 6.3)/],
    ["Windows 10", /(Windows NT 10.0)/],
    ["Windows ME", /Windows ME/],
    ["Windows CE", /Windows CE|WinCE|Microsoft Pocket Internet Explorer/],
    ["Open BSD", /OpenBSD/],
    ["Sun OS", /SunOS/],
    ["Chrome OS", /CrOS/],
    ["Linux", /(Linux)|(X11)/],
    ["Mac OS", /(Mac_PowerPC)|(Macintosh)/],
    ["QNX", /QNX/],
    ["BeOS", /BeOS/],
    ["OS/2", /OS\/2/]
  ];
  function detect(userAgent) {
    if (typeof document === "undefined" && typeof navigator !== "undefined" && navigator.product === "ReactNative") {
      return new ReactNativeInfo();
    }
    if (typeof navigator !== "undefined") {
      return parseUserAgent(navigator.userAgent);
    }
    return getNodeVersion();
  }
  __name(detect, "detect");
  function matchUserAgent(ua) {
    return ua !== "" && userAgentRules.reduce(function(matched, _a2) {
      var browser = _a2[0], regex = _a2[1];
      if (matched) {
        return matched;
      }
      var uaMatch = regex.exec(ua);
      return !!uaMatch && [browser, uaMatch];
    }, false);
  }
  __name(matchUserAgent, "matchUserAgent");
  function parseUserAgent(ua) {
    var matchedRule = matchUserAgent(ua);
    if (!matchedRule) {
      return null;
    }
    var name = matchedRule[0], match = matchedRule[1];
    if (name === "searchbot") {
      return new BotInfo();
    }
    var versionParts = match[1] && match[1].split(".").join("_").split("_").slice(0, 3);
    if (versionParts) {
      if (versionParts.length < REQUIRED_VERSION_PARTS) {
        versionParts = __spreadArray(__spreadArray([], versionParts, true), createVersionParts(REQUIRED_VERSION_PARTS - versionParts.length), true);
      }
    } else {
      versionParts = [];
    }
    var version2 = versionParts.join(".");
    var os = detectOS(ua);
    var searchBotMatch = SEARCHBOT_OS_REGEX.exec(ua);
    if (searchBotMatch && searchBotMatch[1]) {
      return new SearchBotDeviceInfo(name, version2, os, searchBotMatch[1]);
    }
    return new BrowserInfo(name, version2, os);
  }
  __name(parseUserAgent, "parseUserAgent");
  function detectOS(ua) {
    for (var ii = 0, count = operatingSystemRules.length; ii < count; ii++) {
      var _a2 = operatingSystemRules[ii], os = _a2[0], regex = _a2[1];
      var match = regex.exec(ua);
      if (match) {
        return os;
      }
    }
    return null;
  }
  __name(detectOS, "detectOS");
  function getNodeVersion() {
    var isNode = typeof process !== "undefined" && process.version;
    return isNode ? new NodeInfo(process.version.slice(1)) : null;
  }
  __name(getNodeVersion, "getNodeVersion");
  function createVersionParts(count) {
    var output = [];
    for (var ii = 0; ii < count; ii++) {
      output.push("0");
    }
    return output;
  }
  __name(createVersionParts, "createVersionParts");
  function bind(fn, thisArg) {
    return /* @__PURE__ */ __name(function wrap() {
      return fn.apply(thisArg, arguments);
    }, "wrap");
  }
  __name(bind, "bind");
  const { toString } = Object.prototype;
  const { getPrototypeOf } = Object;
  const kindOf = /* @__PURE__ */ ((cache2) => (thing) => {
    const str = toString.call(thing);
    return cache2[str] || (cache2[str] = str.slice(8, -1).toLowerCase());
  })(/* @__PURE__ */ Object.create(null));
  const kindOfTest = /* @__PURE__ */ __name((type) => {
    type = type.toLowerCase();
    return (thing) => kindOf(thing) === type;
  }, "kindOfTest");
  const typeOfTest = /* @__PURE__ */ __name((type) => (thing) => typeof thing === type, "typeOfTest");
  const { isArray } = Array;
  const isUndefined = typeOfTest("undefined");
  function isBuffer(val) {
    return val !== null && !isUndefined(val) && val.constructor !== null && !isUndefined(val.constructor) && isFunction(val.constructor.isBuffer) && val.constructor.isBuffer(val);
  }
  __name(isBuffer, "isBuffer");
  const isArrayBuffer = kindOfTest("ArrayBuffer");
  function isArrayBufferView(val) {
    let result;
    if (typeof ArrayBuffer !== "undefined" && ArrayBuffer.isView) {
      result = ArrayBuffer.isView(val);
    } else {
      result = val && val.buffer && isArrayBuffer(val.buffer);
    }
    return result;
  }
  __name(isArrayBufferView, "isArrayBufferView");
  const isString = typeOfTest("string");
  const isFunction = typeOfTest("function");
  const isNumber = typeOfTest("number");
  const isObject = /* @__PURE__ */ __name((thing) => thing !== null && typeof thing === "object", "isObject");
  const isBoolean = /* @__PURE__ */ __name((thing) => thing === true || thing === false, "isBoolean");
  const isPlainObject = /* @__PURE__ */ __name((val) => {
    if (kindOf(val) !== "object") {
      return false;
    }
    const prototype2 = getPrototypeOf(val);
    return (prototype2 === null || prototype2 === Object.prototype || Object.getPrototypeOf(prototype2) === null) && !(Symbol.toStringTag in val) && !(Symbol.iterator in val);
  }, "isPlainObject");
  const isDate = kindOfTest("Date");
  const isFile = kindOfTest("File");
  const isBlob = kindOfTest("Blob");
  const isFileList = kindOfTest("FileList");
  const isStream = /* @__PURE__ */ __name((val) => isObject(val) && isFunction(val.pipe), "isStream");
  const isFormData = /* @__PURE__ */ __name((thing) => {
    let kind;
    return thing && (typeof FormData === "function" && thing instanceof FormData || isFunction(thing.append) && ((kind = kindOf(thing)) === "formdata" || // detect form-data instance
    kind === "object" && isFunction(thing.toString) && thing.toString() === "[object FormData]"));
  }, "isFormData");
  const isURLSearchParams = kindOfTest("URLSearchParams");
  const [isReadableStream, isRequest, isResponse, isHeaders] = ["ReadableStream", "Request", "Response", "Headers"].map(kindOfTest);
  const trim = /* @__PURE__ */ __name((str) => str.trim ? str.trim() : str.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ""), "trim");
  function forEach(obj, fn, { allOwnKeys = false } = {}) {
    if (obj === null || typeof obj === "undefined") {
      return;
    }
    let i;
    let l;
    if (typeof obj !== "object") {
      obj = [obj];
    }
    if (isArray(obj)) {
      for (i = 0, l = obj.length; i < l; i++) {
        fn.call(null, obj[i], i, obj);
      }
    } else {
      const keys = allOwnKeys ? Object.getOwnPropertyNames(obj) : Object.keys(obj);
      const len = keys.length;
      let key;
      for (i = 0; i < len; i++) {
        key = keys[i];
        fn.call(null, obj[key], key, obj);
      }
    }
  }
  __name(forEach, "forEach");
  function findKey(obj, key) {
    key = key.toLowerCase();
    const keys = Object.keys(obj);
    let i = keys.length;
    let _key;
    while (i-- > 0) {
      _key = keys[i];
      if (key === _key.toLowerCase()) {
        return _key;
      }
    }
    return null;
  }
  __name(findKey, "findKey");
  const _global = (() => {
    if (typeof globalThis !== "undefined") return globalThis;
    return typeof self !== "undefined" ? self : typeof window !== "undefined" ? window : global;
  })();
  const isContextDefined = /* @__PURE__ */ __name((context) => !isUndefined(context) && context !== _global, "isContextDefined");
  function merge() {
    const { caseless } = isContextDefined(this) && this || {};
    const result = {};
    const assignValue = /* @__PURE__ */ __name((val, key) => {
      const targetKey = caseless && findKey(result, key) || key;
      if (isPlainObject(result[targetKey]) && isPlainObject(val)) {
        result[targetKey] = merge(result[targetKey], val);
      } else if (isPlainObject(val)) {
        result[targetKey] = merge({}, val);
      } else if (isArray(val)) {
        result[targetKey] = val.slice();
      } else {
        result[targetKey] = val;
      }
    }, "assignValue");
    for (let i = 0, l = arguments.length; i < l; i++) {
      arguments[i] && forEach(arguments[i], assignValue);
    }
    return result;
  }
  __name(merge, "merge");
  const extend = /* @__PURE__ */ __name((a, b, thisArg, { allOwnKeys } = {}) => {
    forEach(b, (val, key) => {
      if (thisArg && isFunction(val)) {
        a[key] = bind(val, thisArg);
      } else {
        a[key] = val;
      }
    }, { allOwnKeys });
    return a;
  }, "extend");
  const stripBOM = /* @__PURE__ */ __name((content) => {
    if (content.charCodeAt(0) === 65279) {
      content = content.slice(1);
    }
    return content;
  }, "stripBOM");
  const inherits = /* @__PURE__ */ __name((constructor, superConstructor, props, descriptors2) => {
    constructor.prototype = Object.create(superConstructor.prototype, descriptors2);
    constructor.prototype.constructor = constructor;
    Object.defineProperty(constructor, "super", {
      value: superConstructor.prototype
    });
    props && Object.assign(constructor.prototype, props);
  }, "inherits");
  const toFlatObject = /* @__PURE__ */ __name((sourceObj, destObj, filter, propFilter) => {
    let props;
    let i;
    let prop;
    const merged = {};
    destObj = destObj || {};
    if (sourceObj == null) return destObj;
    do {
      props = Object.getOwnPropertyNames(sourceObj);
      i = props.length;
      while (i-- > 0) {
        prop = props[i];
        if ((!propFilter || propFilter(prop, sourceObj, destObj)) && !merged[prop]) {
          destObj[prop] = sourceObj[prop];
          merged[prop] = true;
        }
      }
      sourceObj = filter !== false && getPrototypeOf(sourceObj);
    } while (sourceObj && (!filter || filter(sourceObj, destObj)) && sourceObj !== Object.prototype);
    return destObj;
  }, "toFlatObject");
  const endsWith = /* @__PURE__ */ __name((str, searchString, position) => {
    str = String(str);
    if (position === void 0 || position > str.length) {
      position = str.length;
    }
    position -= searchString.length;
    const lastIndex = str.indexOf(searchString, position);
    return lastIndex !== -1 && lastIndex === position;
  }, "endsWith");
  const toArray = /* @__PURE__ */ __name((thing) => {
    if (!thing) return null;
    if (isArray(thing)) return thing;
    let i = thing.length;
    if (!isNumber(i)) return null;
    const arr = new Array(i);
    while (i-- > 0) {
      arr[i] = thing[i];
    }
    return arr;
  }, "toArray");
  const isTypedArray = /* @__PURE__ */ ((TypedArray) => {
    return (thing) => {
      return TypedArray && thing instanceof TypedArray;
    };
  })(typeof Uint8Array !== "undefined" && getPrototypeOf(Uint8Array));
  const forEachEntry = /* @__PURE__ */ __name((obj, fn) => {
    const generator = obj && obj[Symbol.iterator];
    const iterator2 = generator.call(obj);
    let result;
    while ((result = iterator2.next()) && !result.done) {
      const pair = result.value;
      fn.call(obj, pair[0], pair[1]);
    }
  }, "forEachEntry");
  const matchAll = /* @__PURE__ */ __name((regExp, str) => {
    let matches;
    const arr = [];
    while ((matches = regExp.exec(str)) !== null) {
      arr.push(matches);
    }
    return arr;
  }, "matchAll");
  const isHTMLForm = kindOfTest("HTMLFormElement");
  const toCamelCase = /* @__PURE__ */ __name((str) => {
    return str.toLowerCase().replace(
      /[-_\s]([a-z\d])(\w*)/g,
      /* @__PURE__ */ __name(function replacer(m, p1, p2) {
        return p1.toUpperCase() + p2;
      }, "replacer")
    );
  }, "toCamelCase");
  const hasOwnProperty = (({ hasOwnProperty: hasOwnProperty2 }) => (obj, prop) => hasOwnProperty2.call(obj, prop))(Object.prototype);
  const isRegExp = kindOfTest("RegExp");
  const reduceDescriptors = /* @__PURE__ */ __name((obj, reducer) => {
    const descriptors2 = Object.getOwnPropertyDescriptors(obj);
    const reducedDescriptors = {};
    forEach(descriptors2, (descriptor, name) => {
      let ret;
      if ((ret = reducer(descriptor, name, obj)) !== false) {
        reducedDescriptors[name] = ret || descriptor;
      }
    });
    Object.defineProperties(obj, reducedDescriptors);
  }, "reduceDescriptors");
  const freezeMethods = /* @__PURE__ */ __name((obj) => {
    reduceDescriptors(obj, (descriptor, name) => {
      if (isFunction(obj) && ["arguments", "caller", "callee"].indexOf(name) !== -1) {
        return false;
      }
      const value2 = obj[name];
      if (!isFunction(value2)) return;
      descriptor.enumerable = false;
      if ("writable" in descriptor) {
        descriptor.writable = false;
        return;
      }
      if (!descriptor.set) {
        descriptor.set = () => {
          throw Error("Can not rewrite read-only method '" + name + "'");
        };
      }
    });
  }, "freezeMethods");
  const toObjectSet = /* @__PURE__ */ __name((arrayOrString, delimiter) => {
    const obj = {};
    const define2 = /* @__PURE__ */ __name((arr) => {
      arr.forEach((value2) => {
        obj[value2] = true;
      });
    }, "define");
    isArray(arrayOrString) ? define2(arrayOrString) : define2(String(arrayOrString).split(delimiter));
    return obj;
  }, "toObjectSet");
  const noop = /* @__PURE__ */ __name(() => {
  }, "noop");
  const toFiniteNumber = /* @__PURE__ */ __name((value2, defaultValue) => {
    return value2 != null && Number.isFinite(value2 = +value2) ? value2 : defaultValue;
  }, "toFiniteNumber");
  function isSpecCompliantForm(thing) {
    return !!(thing && isFunction(thing.append) && thing[Symbol.toStringTag] === "FormData" && thing[Symbol.iterator]);
  }
  __name(isSpecCompliantForm, "isSpecCompliantForm");
  const toJSONObject = /* @__PURE__ */ __name((obj) => {
    const stack = new Array(10);
    const visit = /* @__PURE__ */ __name((source, i) => {
      if (isObject(source)) {
        if (stack.indexOf(source) >= 0) {
          return;
        }
        if (!("toJSON" in source)) {
          stack[i] = source;
          const target = isArray(source) ? [] : {};
          forEach(source, (value2, key) => {
            const reducedValue = visit(value2, i + 1);
            !isUndefined(reducedValue) && (target[key] = reducedValue);
          });
          stack[i] = void 0;
          return target;
        }
      }
      return source;
    }, "visit");
    return visit(obj, 0);
  }, "toJSONObject");
  const isAsyncFn = kindOfTest("AsyncFunction");
  const isThenable = /* @__PURE__ */ __name((thing) => thing && (isObject(thing) || isFunction(thing)) && isFunction(thing.then) && isFunction(thing.catch), "isThenable");
  const _setImmediate = ((setImmediateSupported, postMessageSupported) => {
    if (setImmediateSupported) {
      return setImmediate;
    }
    return postMessageSupported ? ((token, callbacks) => {
      _global.addEventListener("message", ({ source, data }) => {
        if (source === _global && data === token) {
          callbacks.length && callbacks.shift()();
        }
      }, false);
      return (cb) => {
        callbacks.push(cb);
        _global.postMessage(token, "*");
      };
    })(`axios@${Math.random()}`, []) : (cb) => setTimeout(cb);
  })(
    typeof setImmediate === "function",
    isFunction(_global.postMessage)
  );
  const asap = typeof queueMicrotask !== "undefined" ? queueMicrotask.bind(_global) : typeof process !== "undefined" && process.nextTick || _setImmediate;
  const utils$1 = {
    isArray,
    isArrayBuffer,
    isBuffer,
    isFormData,
    isArrayBufferView,
    isString,
    isNumber,
    isBoolean,
    isObject,
    isPlainObject,
    isReadableStream,
    isRequest,
    isResponse,
    isHeaders,
    isUndefined,
    isDate,
    isFile,
    isBlob,
    isRegExp,
    isFunction,
    isStream,
    isURLSearchParams,
    isTypedArray,
    isFileList,
    forEach,
    merge,
    extend,
    trim,
    stripBOM,
    inherits,
    toFlatObject,
    kindOf,
    kindOfTest,
    endsWith,
    toArray,
    forEachEntry,
    matchAll,
    isHTMLForm,
    hasOwnProperty,
    hasOwnProp: hasOwnProperty,
    // an alias to avoid ESLint no-prototype-builtins detection
    reduceDescriptors,
    freezeMethods,
    toObjectSet,
    toCamelCase,
    noop,
    toFiniteNumber,
    findKey,
    global: _global,
    isContextDefined,
    isSpecCompliantForm,
    toJSONObject,
    isAsyncFn,
    isThenable,
    setImmediate: _setImmediate,
    asap
  };
  function AxiosError$1(message, code, config2, request, response) {
    Error.call(this);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, this.constructor);
    } else {
      this.stack = new Error().stack;
    }
    this.message = message;
    this.name = "AxiosError";
    code && (this.code = code);
    config2 && (this.config = config2);
    request && (this.request = request);
    if (response) {
      this.response = response;
      this.status = response.status ? response.status : null;
    }
  }
  __name(AxiosError$1, "AxiosError$1");
  utils$1.inherits(AxiosError$1, Error, {
    toJSON: /* @__PURE__ */ __name(function toJSON() {
      return {
        // Standard
        message: this.message,
        name: this.name,
        // Microsoft
        description: this.description,
        number: this.number,
        // Mozilla
        fileName: this.fileName,
        lineNumber: this.lineNumber,
        columnNumber: this.columnNumber,
        stack: this.stack,
        // Axios
        config: utils$1.toJSONObject(this.config),
        code: this.code,
        status: this.status
      };
    }, "toJSON")
  });
  const prototype$1 = AxiosError$1.prototype;
  const descriptors = {};
  [
    "ERR_BAD_OPTION_VALUE",
    "ERR_BAD_OPTION",
    "ECONNABORTED",
    "ETIMEDOUT",
    "ERR_NETWORK",
    "ERR_FR_TOO_MANY_REDIRECTS",
    "ERR_DEPRECATED",
    "ERR_BAD_RESPONSE",
    "ERR_BAD_REQUEST",
    "ERR_CANCELED",
    "ERR_NOT_SUPPORT",
    "ERR_INVALID_URL"
    // eslint-disable-next-line func-names
  ].forEach((code) => {
    descriptors[code] = { value: code };
  });
  Object.defineProperties(AxiosError$1, descriptors);
  Object.defineProperty(prototype$1, "isAxiosError", { value: true });
  AxiosError$1.from = (error, code, config2, request, response, customProps) => {
    const axiosError = Object.create(prototype$1);
    utils$1.toFlatObject(error, axiosError, /* @__PURE__ */ __name(function filter(obj) {
      return obj !== Error.prototype;
    }, "filter"), (prop) => {
      return prop !== "isAxiosError";
    });
    AxiosError$1.call(axiosError, error.message, code, config2, request, response);
    axiosError.cause = error;
    axiosError.name = error.name;
    customProps && Object.assign(axiosError, customProps);
    return axiosError;
  };
  const httpAdapter = null;
  function isVisitable(thing) {
    return utils$1.isPlainObject(thing) || utils$1.isArray(thing);
  }
  __name(isVisitable, "isVisitable");
  function removeBrackets(key) {
    return utils$1.endsWith(key, "[]") ? key.slice(0, -2) : key;
  }
  __name(removeBrackets, "removeBrackets");
  function renderKey(path, key, dots) {
    if (!path) return key;
    return path.concat(key).map(/* @__PURE__ */ __name(function each(token, i) {
      token = removeBrackets(token);
      return !dots && i ? "[" + token + "]" : token;
    }, "each")).join(dots ? "." : "");
  }
  __name(renderKey, "renderKey");
  function isFlatArray(arr) {
    return utils$1.isArray(arr) && !arr.some(isVisitable);
  }
  __name(isFlatArray, "isFlatArray");
  const predicates = utils$1.toFlatObject(utils$1, {}, null, /* @__PURE__ */ __name(function filter(prop) {
    return /^is[A-Z]/.test(prop);
  }, "filter"));
  function toFormData$1(obj, formData, options) {
    if (!utils$1.isObject(obj)) {
      throw new TypeError("target must be an object");
    }
    formData = formData || new FormData();
    options = utils$1.toFlatObject(options, {
      metaTokens: true,
      dots: false,
      indexes: false
    }, false, /* @__PURE__ */ __name(function defined(option, source) {
      return !utils$1.isUndefined(source[option]);
    }, "defined"));
    const metaTokens = options.metaTokens;
    const visitor = options.visitor || defaultVisitor;
    const dots = options.dots;
    const indexes = options.indexes;
    const _Blob = options.Blob || typeof Blob !== "undefined" && Blob;
    const useBlob = _Blob && utils$1.isSpecCompliantForm(formData);
    if (!utils$1.isFunction(visitor)) {
      throw new TypeError("visitor must be a function");
    }
    function convertValue(value2) {
      if (value2 === null) return "";
      if (utils$1.isDate(value2)) {
        return value2.toISOString();
      }
      if (!useBlob && utils$1.isBlob(value2)) {
        throw new AxiosError$1("Blob is not supported. Use a Buffer instead.");
      }
      if (utils$1.isArrayBuffer(value2) || utils$1.isTypedArray(value2)) {
        return useBlob && typeof Blob === "function" ? new Blob([value2]) : Buffer.from(value2);
      }
      return value2;
    }
    __name(convertValue, "convertValue");
    function defaultVisitor(value2, key, path) {
      let arr = value2;
      if (value2 && !path && typeof value2 === "object") {
        if (utils$1.endsWith(key, "{}")) {
          key = metaTokens ? key : key.slice(0, -2);
          value2 = JSON.stringify(value2);
        } else if (utils$1.isArray(value2) && isFlatArray(value2) || (utils$1.isFileList(value2) || utils$1.endsWith(key, "[]")) && (arr = utils$1.toArray(value2))) {
          key = removeBrackets(key);
          arr.forEach(/* @__PURE__ */ __name(function each(el, index) {
            !(utils$1.isUndefined(el) || el === null) && formData.append(
              // eslint-disable-next-line no-nested-ternary
              indexes === true ? renderKey([key], index, dots) : indexes === null ? key : key + "[]",
              convertValue(el)
            );
          }, "each"));
          return false;
        }
      }
      if (isVisitable(value2)) {
        return true;
      }
      formData.append(renderKey(path, key, dots), convertValue(value2));
      return false;
    }
    __name(defaultVisitor, "defaultVisitor");
    const stack = [];
    const exposedHelpers = Object.assign(predicates, {
      defaultVisitor,
      convertValue,
      isVisitable
    });
    function build(value2, path) {
      if (utils$1.isUndefined(value2)) return;
      if (stack.indexOf(value2) !== -1) {
        throw Error("Circular reference detected in " + path.join("."));
      }
      stack.push(value2);
      utils$1.forEach(value2, /* @__PURE__ */ __name(function each(el, key) {
        const result = !(utils$1.isUndefined(el) || el === null) && visitor.call(
          formData,
          el,
          utils$1.isString(key) ? key.trim() : key,
          path,
          exposedHelpers
        );
        if (result === true) {
          build(el, path ? path.concat(key) : [key]);
        }
      }, "each"));
      stack.pop();
    }
    __name(build, "build");
    if (!utils$1.isObject(obj)) {
      throw new TypeError("data must be an object");
    }
    build(obj);
    return formData;
  }
  __name(toFormData$1, "toFormData$1");
  function encode$1(str) {
    const charMap = {
      "!": "%21",
      "'": "%27",
      "(": "%28",
      ")": "%29",
      "~": "%7E",
      "%20": "+",
      "%00": "\0"
    };
    return encodeURIComponent(str).replace(/[!'()~]|%20|%00/g, /* @__PURE__ */ __name(function replacer(match) {
      return charMap[match];
    }, "replacer"));
  }
  __name(encode$1, "encode$1");
  function AxiosURLSearchParams(params, options) {
    this._pairs = [];
    params && toFormData$1(params, this, options);
  }
  __name(AxiosURLSearchParams, "AxiosURLSearchParams");
  const prototype = AxiosURLSearchParams.prototype;
  prototype.append = /* @__PURE__ */ __name(function append(name, value2) {
    this._pairs.push([name, value2]);
  }, "append");
  prototype.toString = /* @__PURE__ */ __name(function toString2(encoder) {
    const _encode = encoder ? function(value2) {
      return encoder.call(this, value2, encode$1);
    } : encode$1;
    return this._pairs.map(/* @__PURE__ */ __name(function each(pair) {
      return _encode(pair[0]) + "=" + _encode(pair[1]);
    }, "each"), "").join("&");
  }, "toString");
  function encode(val) {
    return encodeURIComponent(val).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]");
  }
  __name(encode, "encode");
  function buildURL(url2, params, options) {
    if (!params) {
      return url2;
    }
    const _encode = options && options.encode || encode;
    if (utils$1.isFunction(options)) {
      options = {
        serialize: options
      };
    }
    const serializeFn = options && options.serialize;
    let serializedParams;
    if (serializeFn) {
      serializedParams = serializeFn(params, options);
    } else {
      serializedParams = utils$1.isURLSearchParams(params) ? params.toString() : new AxiosURLSearchParams(params, options).toString(_encode);
    }
    if (serializedParams) {
      const hashmarkIndex = url2.indexOf("#");
      if (hashmarkIndex !== -1) {
        url2 = url2.slice(0, hashmarkIndex);
      }
      url2 += (url2.indexOf("?") === -1 ? "?" : "&") + serializedParams;
    }
    return url2;
  }
  __name(buildURL, "buildURL");
  const _InterceptorManager = class _InterceptorManager {
    constructor() {
      this.handlers = [];
    }
    /**
     * Add a new interceptor to the stack
     *
     * @param {Function} fulfilled The function to handle `then` for a `Promise`
     * @param {Function} rejected The function to handle `reject` for a `Promise`
     *
     * @return {Number} An ID used to remove interceptor later
     */
    use(fulfilled, rejected, options) {
      this.handlers.push({
        fulfilled,
        rejected,
        synchronous: options ? options.synchronous : false,
        runWhen: options ? options.runWhen : null
      });
      return this.handlers.length - 1;
    }
    /**
     * Remove an interceptor from the stack
     *
     * @param {Number} id The ID that was returned by `use`
     *
     * @returns {Boolean} `true` if the interceptor was removed, `false` otherwise
     */
    eject(id) {
      if (this.handlers[id]) {
        this.handlers[id] = null;
      }
    }
    /**
     * Clear all interceptors from the stack
     *
     * @returns {void}
     */
    clear() {
      if (this.handlers) {
        this.handlers = [];
      }
    }
    /**
     * Iterate over all the registered interceptors
     *
     * This method is particularly useful for skipping over any
     * interceptors that may have become `null` calling `eject`.
     *
     * @param {Function} fn The function to call for each interceptor
     *
     * @returns {void}
     */
    forEach(fn) {
      utils$1.forEach(this.handlers, /* @__PURE__ */ __name(function forEachHandler(h) {
        if (h !== null) {
          fn(h);
        }
      }, "forEachHandler"));
    }
  };
  __name(_InterceptorManager, "InterceptorManager");
  let InterceptorManager = _InterceptorManager;
  const transitionalDefaults = {
    silentJSONParsing: true,
    forcedJSONParsing: true,
    clarifyTimeoutError: false
  };
  const URLSearchParams$1 = typeof URLSearchParams !== "undefined" ? URLSearchParams : AxiosURLSearchParams;
  const FormData$1 = typeof FormData !== "undefined" ? FormData : null;
  const Blob$1 = typeof Blob !== "undefined" ? Blob : null;
  const platform$1 = {
    isBrowser: true,
    classes: {
      URLSearchParams: URLSearchParams$1,
      FormData: FormData$1,
      Blob: Blob$1
    },
    protocols: ["http", "https", "file", "blob", "url", "data"]
  };
  const hasBrowserEnv = typeof window !== "undefined" && typeof document !== "undefined";
  const _navigator = typeof navigator === "object" && navigator || void 0;
  const hasStandardBrowserEnv = hasBrowserEnv && (!_navigator || ["ReactNative", "NativeScript", "NS"].indexOf(_navigator.product) < 0);
  const hasStandardBrowserWebWorkerEnv = (() => {
    return typeof WorkerGlobalScope !== "undefined" && // eslint-disable-next-line no-undef
    self instanceof WorkerGlobalScope && typeof self.importScripts === "function";
  })();
  const origin = hasBrowserEnv && window.location.href || "http://localhost";
  const utils = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
    __proto__: null,
    hasBrowserEnv,
    hasStandardBrowserEnv,
    hasStandardBrowserWebWorkerEnv,
    navigator: _navigator,
    origin
  }, Symbol.toStringTag, { value: "Module" }));
  const platform = {
    ...utils,
    ...platform$1
  };
  function toURLEncodedForm(data, options) {
    return toFormData$1(data, new platform.classes.URLSearchParams(), Object.assign({
      visitor: /* @__PURE__ */ __name(function(value2, key, path, helpers) {
        if (platform.isNode && utils$1.isBuffer(value2)) {
          this.append(key, value2.toString("base64"));
          return false;
        }
        return helpers.defaultVisitor.apply(this, arguments);
      }, "visitor")
    }, options));
  }
  __name(toURLEncodedForm, "toURLEncodedForm");
  function parsePropPath(name) {
    return utils$1.matchAll(/\w+|\[(\w*)]/g, name).map((match) => {
      return match[0] === "[]" ? "" : match[1] || match[0];
    });
  }
  __name(parsePropPath, "parsePropPath");
  function arrayToObject(arr) {
    const obj = {};
    const keys = Object.keys(arr);
    let i;
    const len = keys.length;
    let key;
    for (i = 0; i < len; i++) {
      key = keys[i];
      obj[key] = arr[key];
    }
    return obj;
  }
  __name(arrayToObject, "arrayToObject");
  function formDataToJSON(formData) {
    function buildPath(path, value2, target, index) {
      let name = path[index++];
      if (name === "__proto__") return true;
      const isNumericKey = Number.isFinite(+name);
      const isLast = index >= path.length;
      name = !name && utils$1.isArray(target) ? target.length : name;
      if (isLast) {
        if (utils$1.hasOwnProp(target, name)) {
          target[name] = [target[name], value2];
        } else {
          target[name] = value2;
        }
        return !isNumericKey;
      }
      if (!target[name] || !utils$1.isObject(target[name])) {
        target[name] = [];
      }
      const result = buildPath(path, value2, target[name], index);
      if (result && utils$1.isArray(target[name])) {
        target[name] = arrayToObject(target[name]);
      }
      return !isNumericKey;
    }
    __name(buildPath, "buildPath");
    if (utils$1.isFormData(formData) && utils$1.isFunction(formData.entries)) {
      const obj = {};
      utils$1.forEachEntry(formData, (name, value2) => {
        buildPath(parsePropPath(name), value2, obj, 0);
      });
      return obj;
    }
    return null;
  }
  __name(formDataToJSON, "formDataToJSON");
  function stringifySafely(rawValue, parser2, encoder) {
    if (utils$1.isString(rawValue)) {
      try {
        (parser2 || JSON.parse)(rawValue);
        return utils$1.trim(rawValue);
      } catch (e) {
        if (e.name !== "SyntaxError") {
          throw e;
        }
      }
    }
    return (encoder || JSON.stringify)(rawValue);
  }
  __name(stringifySafely, "stringifySafely");
  const defaults = {
    transitional: transitionalDefaults,
    adapter: ["xhr", "http", "fetch"],
    transformRequest: [/* @__PURE__ */ __name(function transformRequest(data, headers) {
      const contentType = headers.getContentType() || "";
      const hasJSONContentType = contentType.indexOf("application/json") > -1;
      const isObjectPayload = utils$1.isObject(data);
      if (isObjectPayload && utils$1.isHTMLForm(data)) {
        data = new FormData(data);
      }
      const isFormData2 = utils$1.isFormData(data);
      if (isFormData2) {
        return hasJSONContentType ? JSON.stringify(formDataToJSON(data)) : data;
      }
      if (utils$1.isArrayBuffer(data) || utils$1.isBuffer(data) || utils$1.isStream(data) || utils$1.isFile(data) || utils$1.isBlob(data) || utils$1.isReadableStream(data)) {
        return data;
      }
      if (utils$1.isArrayBufferView(data)) {
        return data.buffer;
      }
      if (utils$1.isURLSearchParams(data)) {
        headers.setContentType("application/x-www-form-urlencoded;charset=utf-8", false);
        return data.toString();
      }
      let isFileList2;
      if (isObjectPayload) {
        if (contentType.indexOf("application/x-www-form-urlencoded") > -1) {
          return toURLEncodedForm(data, this.formSerializer).toString();
        }
        if ((isFileList2 = utils$1.isFileList(data)) || contentType.indexOf("multipart/form-data") > -1) {
          const _FormData = this.env && this.env.FormData;
          return toFormData$1(
            isFileList2 ? { "files[]": data } : data,
            _FormData && new _FormData(),
            this.formSerializer
          );
        }
      }
      if (isObjectPayload || hasJSONContentType) {
        headers.setContentType("application/json", false);
        return stringifySafely(data);
      }
      return data;
    }, "transformRequest")],
    transformResponse: [/* @__PURE__ */ __name(function transformResponse(data) {
      const transitional = this.transitional || defaults.transitional;
      const forcedJSONParsing = transitional && transitional.forcedJSONParsing;
      const JSONRequested = this.responseType === "json";
      if (utils$1.isResponse(data) || utils$1.isReadableStream(data)) {
        return data;
      }
      if (data && utils$1.isString(data) && (forcedJSONParsing && !this.responseType || JSONRequested)) {
        const silentJSONParsing = transitional && transitional.silentJSONParsing;
        const strictJSONParsing = !silentJSONParsing && JSONRequested;
        try {
          return JSON.parse(data);
        } catch (e) {
          if (strictJSONParsing) {
            if (e.name === "SyntaxError") {
              throw AxiosError$1.from(e, AxiosError$1.ERR_BAD_RESPONSE, this, null, this.response);
            }
            throw e;
          }
        }
      }
      return data;
    }, "transformResponse")],
    /**
     * A timeout in milliseconds to abort a request. If set to 0 (default) a
     * timeout is not created.
     */
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
      FormData: platform.classes.FormData,
      Blob: platform.classes.Blob
    },
    validateStatus: /* @__PURE__ */ __name(function validateStatus(status) {
      return status >= 200 && status < 300;
    }, "validateStatus"),
    headers: {
      common: {
        "Accept": "application/json, text/plain, */*",
        "Content-Type": void 0
      }
    }
  };
  utils$1.forEach(["delete", "get", "head", "post", "put", "patch"], (method) => {
    defaults.headers[method] = {};
  });
  const ignoreDuplicateOf = utils$1.toObjectSet([
    "age",
    "authorization",
    "content-length",
    "content-type",
    "etag",
    "expires",
    "from",
    "host",
    "if-modified-since",
    "if-unmodified-since",
    "last-modified",
    "location",
    "max-forwards",
    "proxy-authorization",
    "referer",
    "retry-after",
    "user-agent"
  ]);
  const parseHeaders = /* @__PURE__ */ __name((rawHeaders) => {
    const parsed = {};
    let key;
    let val;
    let i;
    rawHeaders && rawHeaders.split("\n").forEach(/* @__PURE__ */ __name(function parser2(line) {
      i = line.indexOf(":");
      key = line.substring(0, i).trim().toLowerCase();
      val = line.substring(i + 1).trim();
      if (!key || parsed[key] && ignoreDuplicateOf[key]) {
        return;
      }
      if (key === "set-cookie") {
        if (parsed[key]) {
          parsed[key].push(val);
        } else {
          parsed[key] = [val];
        }
      } else {
        parsed[key] = parsed[key] ? parsed[key] + ", " + val : val;
      }
    }, "parser"));
    return parsed;
  }, "parseHeaders");
  const $internals = Symbol("internals");
  function normalizeHeader(header) {
    return header && String(header).trim().toLowerCase();
  }
  __name(normalizeHeader, "normalizeHeader");
  function normalizeValue(value2) {
    if (value2 === false || value2 == null) {
      return value2;
    }
    return utils$1.isArray(value2) ? value2.map(normalizeValue) : String(value2);
  }
  __name(normalizeValue, "normalizeValue");
  function parseTokens(str) {
    const tokens = /* @__PURE__ */ Object.create(null);
    const tokensRE = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
    let match;
    while (match = tokensRE.exec(str)) {
      tokens[match[1]] = match[2];
    }
    return tokens;
  }
  __name(parseTokens, "parseTokens");
  const isValidHeaderName = /* @__PURE__ */ __name((str) => /^[-_a-zA-Z0-9^`|~,!#$%&'*+.]+$/.test(str.trim()), "isValidHeaderName");
  function matchHeaderValue(context, value2, header, filter, isHeaderNameFilter) {
    if (utils$1.isFunction(filter)) {
      return filter.call(this, value2, header);
    }
    if (isHeaderNameFilter) {
      value2 = header;
    }
    if (!utils$1.isString(value2)) return;
    if (utils$1.isString(filter)) {
      return value2.indexOf(filter) !== -1;
    }
    if (utils$1.isRegExp(filter)) {
      return filter.test(value2);
    }
  }
  __name(matchHeaderValue, "matchHeaderValue");
  function formatHeader(header) {
    return header.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, (w, char, str) => {
      return char.toUpperCase() + str;
    });
  }
  __name(formatHeader, "formatHeader");
  function buildAccessors(obj, header) {
    const accessorName = utils$1.toCamelCase(" " + header);
    ["get", "set", "has"].forEach((methodName) => {
      Object.defineProperty(obj, methodName + accessorName, {
        value: /* @__PURE__ */ __name(function(arg1, arg2, arg3) {
          return this[methodName].call(this, header, arg1, arg2, arg3);
        }, "value"),
        configurable: true
      });
    });
  }
  __name(buildAccessors, "buildAccessors");
  let AxiosHeaders$1 = (_c = class {
    constructor(headers) {
      headers && this.set(headers);
    }
    set(header, valueOrRewrite, rewrite) {
      const self2 = this;
      function setHeader(_value, _header, _rewrite) {
        const lHeader = normalizeHeader(_header);
        if (!lHeader) {
          throw new Error("header name must be a non-empty string");
        }
        const key = utils$1.findKey(self2, lHeader);
        if (!key || self2[key] === void 0 || _rewrite === true || _rewrite === void 0 && self2[key] !== false) {
          self2[key || _header] = normalizeValue(_value);
        }
      }
      __name(setHeader, "setHeader");
      const setHeaders = /* @__PURE__ */ __name((headers, _rewrite) => utils$1.forEach(headers, (_value, _header) => setHeader(_value, _header, _rewrite)), "setHeaders");
      if (utils$1.isPlainObject(header) || header instanceof this.constructor) {
        setHeaders(header, valueOrRewrite);
      } else if (utils$1.isString(header) && (header = header.trim()) && !isValidHeaderName(header)) {
        setHeaders(parseHeaders(header), valueOrRewrite);
      } else if (utils$1.isHeaders(header)) {
        for (const [key, value2] of header.entries()) {
          setHeader(value2, key, rewrite);
        }
      } else {
        header != null && setHeader(valueOrRewrite, header, rewrite);
      }
      return this;
    }
    get(header, parser2) {
      header = normalizeHeader(header);
      if (header) {
        const key = utils$1.findKey(this, header);
        if (key) {
          const value2 = this[key];
          if (!parser2) {
            return value2;
          }
          if (parser2 === true) {
            return parseTokens(value2);
          }
          if (utils$1.isFunction(parser2)) {
            return parser2.call(this, value2, key);
          }
          if (utils$1.isRegExp(parser2)) {
            return parser2.exec(value2);
          }
          throw new TypeError("parser must be boolean|regexp|function");
        }
      }
    }
    has(header, matcher) {
      header = normalizeHeader(header);
      if (header) {
        const key = utils$1.findKey(this, header);
        return !!(key && this[key] !== void 0 && (!matcher || matchHeaderValue(this, this[key], key, matcher)));
      }
      return false;
    }
    delete(header, matcher) {
      const self2 = this;
      let deleted = false;
      function deleteHeader(_header) {
        _header = normalizeHeader(_header);
        if (_header) {
          const key = utils$1.findKey(self2, _header);
          if (key && (!matcher || matchHeaderValue(self2, self2[key], key, matcher))) {
            delete self2[key];
            deleted = true;
          }
        }
      }
      __name(deleteHeader, "deleteHeader");
      if (utils$1.isArray(header)) {
        header.forEach(deleteHeader);
      } else {
        deleteHeader(header);
      }
      return deleted;
    }
    clear(matcher) {
      const keys = Object.keys(this);
      let i = keys.length;
      let deleted = false;
      while (i--) {
        const key = keys[i];
        if (!matcher || matchHeaderValue(this, this[key], key, matcher, true)) {
          delete this[key];
          deleted = true;
        }
      }
      return deleted;
    }
    normalize(format) {
      const self2 = this;
      const headers = {};
      utils$1.forEach(this, (value2, header) => {
        const key = utils$1.findKey(headers, header);
        if (key) {
          self2[key] = normalizeValue(value2);
          delete self2[header];
          return;
        }
        const normalized = format ? formatHeader(header) : String(header).trim();
        if (normalized !== header) {
          delete self2[header];
        }
        self2[normalized] = normalizeValue(value2);
        headers[normalized] = true;
      });
      return this;
    }
    concat(...targets) {
      return this.constructor.concat(this, ...targets);
    }
    toJSON(asStrings) {
      const obj = /* @__PURE__ */ Object.create(null);
      utils$1.forEach(this, (value2, header) => {
        value2 != null && value2 !== false && (obj[header] = asStrings && utils$1.isArray(value2) ? value2.join(", ") : value2);
      });
      return obj;
    }
    [Symbol.iterator]() {
      return Object.entries(this.toJSON())[Symbol.iterator]();
    }
    toString() {
      return Object.entries(this.toJSON()).map(([header, value2]) => header + ": " + value2).join("\n");
    }
    get [Symbol.toStringTag]() {
      return "AxiosHeaders";
    }
    static from(thing) {
      return thing instanceof this ? thing : new this(thing);
    }
    static concat(first, ...targets) {
      const computed = new this(first);
      targets.forEach((target) => computed.set(target));
      return computed;
    }
    static accessor(header) {
      const internals = this[$internals] = this[$internals] = {
        accessors: {}
      };
      const accessors = internals.accessors;
      const prototype2 = this.prototype;
      function defineAccessor(_header) {
        const lHeader = normalizeHeader(_header);
        if (!accessors[lHeader]) {
          buildAccessors(prototype2, _header);
          accessors[lHeader] = true;
        }
      }
      __name(defineAccessor, "defineAccessor");
      utils$1.isArray(header) ? header.forEach(defineAccessor) : defineAccessor(header);
      return this;
    }
  }, __name(_c, "AxiosHeaders"), _c);
  AxiosHeaders$1.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent", "Authorization"]);
  utils$1.reduceDescriptors(AxiosHeaders$1.prototype, ({ value: value2 }, key) => {
    let mapped = key[0].toUpperCase() + key.slice(1);
    return {
      get: /* @__PURE__ */ __name(() => value2, "get"),
      set(headerValue) {
        this[mapped] = headerValue;
      }
    };
  });
  utils$1.freezeMethods(AxiosHeaders$1);
  function transformData(fns, response) {
    const config2 = this || defaults;
    const context = response || config2;
    const headers = AxiosHeaders$1.from(context.headers);
    let data = context.data;
    utils$1.forEach(fns, /* @__PURE__ */ __name(function transform(fn) {
      data = fn.call(config2, data, headers.normalize(), response ? response.status : void 0);
    }, "transform"));
    headers.normalize();
    return data;
  }
  __name(transformData, "transformData");
  function isCancel$1(value2) {
    return !!(value2 && value2.__CANCEL__);
  }
  __name(isCancel$1, "isCancel$1");
  function CanceledError$1(message, config2, request) {
    AxiosError$1.call(this, message == null ? "canceled" : message, AxiosError$1.ERR_CANCELED, config2, request);
    this.name = "CanceledError";
  }
  __name(CanceledError$1, "CanceledError$1");
  utils$1.inherits(CanceledError$1, AxiosError$1, {
    __CANCEL__: true
  });
  function settle(resolve, reject, response) {
    const validateStatus = response.config.validateStatus;
    if (!response.status || !validateStatus || validateStatus(response.status)) {
      resolve(response);
    } else {
      reject(new AxiosError$1(
        "Request failed with status code " + response.status,
        [AxiosError$1.ERR_BAD_REQUEST, AxiosError$1.ERR_BAD_RESPONSE][Math.floor(response.status / 100) - 4],
        response.config,
        response.request,
        response
      ));
    }
  }
  __name(settle, "settle");
  function parseProtocol(url2) {
    const match = /^([-+\w]{1,25})(:?\/\/|:)/.exec(url2);
    return match && match[1] || "";
  }
  __name(parseProtocol, "parseProtocol");
  function speedometer(samplesCount, min) {
    samplesCount = samplesCount || 10;
    const bytes = new Array(samplesCount);
    const timestamps = new Array(samplesCount);
    let head = 0;
    let tail = 0;
    let firstSampleTS;
    min = min !== void 0 ? min : 1e3;
    return /* @__PURE__ */ __name(function push(chunkLength) {
      const now = Date.now();
      const startedAt = timestamps[tail];
      if (!firstSampleTS) {
        firstSampleTS = now;
      }
      bytes[head] = chunkLength;
      timestamps[head] = now;
      let i = tail;
      let bytesCount = 0;
      while (i !== head) {
        bytesCount += bytes[i++];
        i = i % samplesCount;
      }
      head = (head + 1) % samplesCount;
      if (head === tail) {
        tail = (tail + 1) % samplesCount;
      }
      if (now - firstSampleTS < min) {
        return;
      }
      const passed = startedAt && now - startedAt;
      return passed ? Math.round(bytesCount * 1e3 / passed) : void 0;
    }, "push");
  }
  __name(speedometer, "speedometer");
  function throttle(fn, freq) {
    let timestamp = 0;
    let threshold = 1e3 / freq;
    let lastArgs;
    let timer;
    const invoke = /* @__PURE__ */ __name((args, now = Date.now()) => {
      timestamp = now;
      lastArgs = null;
      if (timer) {
        clearTimeout(timer);
        timer = null;
      }
      fn.apply(null, args);
    }, "invoke");
    const throttled = /* @__PURE__ */ __name((...args) => {
      const now = Date.now();
      const passed = now - timestamp;
      if (passed >= threshold) {
        invoke(args, now);
      } else {
        lastArgs = args;
        if (!timer) {
          timer = setTimeout(() => {
            timer = null;
            invoke(lastArgs);
          }, threshold - passed);
        }
      }
    }, "throttled");
    const flush = /* @__PURE__ */ __name(() => lastArgs && invoke(lastArgs), "flush");
    return [throttled, flush];
  }
  __name(throttle, "throttle");
  const progressEventReducer = /* @__PURE__ */ __name((listener, isDownloadStream, freq = 3) => {
    let bytesNotified = 0;
    const _speedometer = speedometer(50, 250);
    return throttle((e) => {
      const loaded = e.loaded;
      const total = e.lengthComputable ? e.total : void 0;
      const progressBytes = loaded - bytesNotified;
      const rate = _speedometer(progressBytes);
      const inRange = loaded <= total;
      bytesNotified = loaded;
      const data = {
        loaded,
        total,
        progress: total ? loaded / total : void 0,
        bytes: progressBytes,
        rate: rate ? rate : void 0,
        estimated: rate && total && inRange ? (total - loaded) / rate : void 0,
        event: e,
        lengthComputable: total != null,
        [isDownloadStream ? "download" : "upload"]: true
      };
      listener(data);
    }, freq);
  }, "progressEventReducer");
  const progressEventDecorator = /* @__PURE__ */ __name((total, throttled) => {
    const lengthComputable = total != null;
    return [(loaded) => throttled[0]({
      lengthComputable,
      total,
      loaded
    }), throttled[1]];
  }, "progressEventDecorator");
  const asyncDecorator = /* @__PURE__ */ __name((fn) => (...args) => utils$1.asap(() => fn(...args)), "asyncDecorator");
  const isURLSameOrigin = platform.hasStandardBrowserEnv ? /* @__PURE__ */ ((origin2, isMSIE) => (url2) => {
    url2 = new URL(url2, platform.origin);
    return origin2.protocol === url2.protocol && origin2.host === url2.host && (isMSIE || origin2.port === url2.port);
  })(
    new URL(platform.origin),
    platform.navigator && /(msie|trident)/i.test(platform.navigator.userAgent)
  ) : () => true;
  const cookies = platform.hasStandardBrowserEnv ? (
    // Standard browser envs support document.cookie
    {
      write(name, value2, expires, path, domain, secure) {
        const cookie = [name + "=" + encodeURIComponent(value2)];
        utils$1.isNumber(expires) && cookie.push("expires=" + new Date(expires).toGMTString());
        utils$1.isString(path) && cookie.push("path=" + path);
        utils$1.isString(domain) && cookie.push("domain=" + domain);
        secure === true && cookie.push("secure");
        document.cookie = cookie.join("; ");
      },
      read(name) {
        const match = document.cookie.match(new RegExp("(^|;\\s*)(" + name + ")=([^;]*)"));
        return match ? decodeURIComponent(match[3]) : null;
      },
      remove(name) {
        this.write(name, "", Date.now() - 864e5);
      }
    }
  ) : (
    // Non-standard browser env (web workers, react-native) lack needed support.
    {
      write() {
      },
      read() {
        return null;
      },
      remove() {
      }
    }
  );
  function isAbsoluteURL(url2) {
    return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(url2);
  }
  __name(isAbsoluteURL, "isAbsoluteURL");
  function combineURLs(baseURL, relativeURL) {
    return relativeURL ? baseURL.replace(/\/?\/$/, "") + "/" + relativeURL.replace(/^\/+/, "") : baseURL;
  }
  __name(combineURLs, "combineURLs");
  function buildFullPath(baseURL, requestedURL, allowAbsoluteUrls) {
    let isRelativeUrl = !isAbsoluteURL(requestedURL);
    if (baseURL && (isRelativeUrl || allowAbsoluteUrls == false)) {
      return combineURLs(baseURL, requestedURL);
    }
    return requestedURL;
  }
  __name(buildFullPath, "buildFullPath");
  const headersToObject = /* @__PURE__ */ __name((thing) => thing instanceof AxiosHeaders$1 ? { ...thing } : thing, "headersToObject");
  function mergeConfig$1(config1, config2) {
    config2 = config2 || {};
    const config3 = {};
    function getMergedValue(target, source, prop, caseless) {
      if (utils$1.isPlainObject(target) && utils$1.isPlainObject(source)) {
        return utils$1.merge.call({ caseless }, target, source);
      } else if (utils$1.isPlainObject(source)) {
        return utils$1.merge({}, source);
      } else if (utils$1.isArray(source)) {
        return source.slice();
      }
      return source;
    }
    __name(getMergedValue, "getMergedValue");
    function mergeDeepProperties(a, b, prop, caseless) {
      if (!utils$1.isUndefined(b)) {
        return getMergedValue(a, b, prop, caseless);
      } else if (!utils$1.isUndefined(a)) {
        return getMergedValue(void 0, a, prop, caseless);
      }
    }
    __name(mergeDeepProperties, "mergeDeepProperties");
    function valueFromConfig2(a, b) {
      if (!utils$1.isUndefined(b)) {
        return getMergedValue(void 0, b);
      }
    }
    __name(valueFromConfig2, "valueFromConfig2");
    function defaultToConfig2(a, b) {
      if (!utils$1.isUndefined(b)) {
        return getMergedValue(void 0, b);
      } else if (!utils$1.isUndefined(a)) {
        return getMergedValue(void 0, a);
      }
    }
    __name(defaultToConfig2, "defaultToConfig2");
    function mergeDirectKeys(a, b, prop) {
      if (prop in config2) {
        return getMergedValue(a, b);
      } else if (prop in config1) {
        return getMergedValue(void 0, a);
      }
    }
    __name(mergeDirectKeys, "mergeDirectKeys");
    const mergeMap = {
      url: valueFromConfig2,
      method: valueFromConfig2,
      data: valueFromConfig2,
      baseURL: defaultToConfig2,
      transformRequest: defaultToConfig2,
      transformResponse: defaultToConfig2,
      paramsSerializer: defaultToConfig2,
      timeout: defaultToConfig2,
      timeoutMessage: defaultToConfig2,
      withCredentials: defaultToConfig2,
      withXSRFToken: defaultToConfig2,
      adapter: defaultToConfig2,
      responseType: defaultToConfig2,
      xsrfCookieName: defaultToConfig2,
      xsrfHeaderName: defaultToConfig2,
      onUploadProgress: defaultToConfig2,
      onDownloadProgress: defaultToConfig2,
      decompress: defaultToConfig2,
      maxContentLength: defaultToConfig2,
      maxBodyLength: defaultToConfig2,
      beforeRedirect: defaultToConfig2,
      transport: defaultToConfig2,
      httpAgent: defaultToConfig2,
      httpsAgent: defaultToConfig2,
      cancelToken: defaultToConfig2,
      socketPath: defaultToConfig2,
      responseEncoding: defaultToConfig2,
      validateStatus: mergeDirectKeys,
      headers: /* @__PURE__ */ __name((a, b, prop) => mergeDeepProperties(headersToObject(a), headersToObject(b), prop, true), "headers")
    };
    utils$1.forEach(Object.keys(Object.assign({}, config1, config2)), /* @__PURE__ */ __name(function computeConfigValue(prop) {
      const merge2 = mergeMap[prop] || mergeDeepProperties;
      const configValue = merge2(config1[prop], config2[prop], prop);
      utils$1.isUndefined(configValue) && merge2 !== mergeDirectKeys || (config3[prop] = configValue);
    }, "computeConfigValue"));
    return config3;
  }
  __name(mergeConfig$1, "mergeConfig$1");
  const resolveConfig = /* @__PURE__ */ __name((config2) => {
    const newConfig = mergeConfig$1({}, config2);
    let { data, withXSRFToken, xsrfHeaderName, xsrfCookieName, headers, auth } = newConfig;
    newConfig.headers = headers = AxiosHeaders$1.from(headers);
    newConfig.url = buildURL(buildFullPath(newConfig.baseURL, newConfig.url, newConfig.allowAbsoluteUrls), config2.params, config2.paramsSerializer);
    if (auth) {
      headers.set(
        "Authorization",
        "Basic " + btoa((auth.username || "") + ":" + (auth.password ? unescape(encodeURIComponent(auth.password)) : ""))
      );
    }
    let contentType;
    if (utils$1.isFormData(data)) {
      if (platform.hasStandardBrowserEnv || platform.hasStandardBrowserWebWorkerEnv) {
        headers.setContentType(void 0);
      } else if ((contentType = headers.getContentType()) !== false) {
        const [type, ...tokens] = contentType ? contentType.split(";").map((token) => token.trim()).filter(Boolean) : [];
        headers.setContentType([type || "multipart/form-data", ...tokens].join("; "));
      }
    }
    if (platform.hasStandardBrowserEnv) {
      withXSRFToken && utils$1.isFunction(withXSRFToken) && (withXSRFToken = withXSRFToken(newConfig));
      if (withXSRFToken || withXSRFToken !== false && isURLSameOrigin(newConfig.url)) {
        const xsrfValue = xsrfHeaderName && xsrfCookieName && cookies.read(xsrfCookieName);
        if (xsrfValue) {
          headers.set(xsrfHeaderName, xsrfValue);
        }
      }
    }
    return newConfig;
  }, "resolveConfig");
  const isXHRAdapterSupported = typeof XMLHttpRequest !== "undefined";
  const xhrAdapter = isXHRAdapterSupported && function(config2) {
    return new Promise(/* @__PURE__ */ __name(function dispatchXhrRequest(resolve, reject) {
      const _config = resolveConfig(config2);
      let requestData = _config.data;
      const requestHeaders = AxiosHeaders$1.from(_config.headers).normalize();
      let { responseType, onUploadProgress, onDownloadProgress } = _config;
      let onCanceled;
      let uploadThrottled, downloadThrottled;
      let flushUpload, flushDownload;
      function done() {
        flushUpload && flushUpload();
        flushDownload && flushDownload();
        _config.cancelToken && _config.cancelToken.unsubscribe(onCanceled);
        _config.signal && _config.signal.removeEventListener("abort", onCanceled);
      }
      __name(done, "done");
      let request = new XMLHttpRequest();
      request.open(_config.method.toUpperCase(), _config.url, true);
      request.timeout = _config.timeout;
      function onloadend() {
        if (!request) {
          return;
        }
        const responseHeaders = AxiosHeaders$1.from(
          "getAllResponseHeaders" in request && request.getAllResponseHeaders()
        );
        const responseData = !responseType || responseType === "text" || responseType === "json" ? request.responseText : request.response;
        const response = {
          data: responseData,
          status: request.status,
          statusText: request.statusText,
          headers: responseHeaders,
          config: config2,
          request
        };
        settle(/* @__PURE__ */ __name(function _resolve(value2) {
          resolve(value2);
          done();
        }, "_resolve"), /* @__PURE__ */ __name(function _reject(err) {
          reject(err);
          done();
        }, "_reject"), response);
        request = null;
      }
      __name(onloadend, "onloadend");
      if ("onloadend" in request) {
        request.onloadend = onloadend;
      } else {
        request.onreadystatechange = /* @__PURE__ */ __name(function handleLoad() {
          if (!request || request.readyState !== 4) {
            return;
          }
          if (request.status === 0 && !(request.responseURL && request.responseURL.indexOf("file:") === 0)) {
            return;
          }
          setTimeout(onloadend);
        }, "handleLoad");
      }
      request.onabort = /* @__PURE__ */ __name(function handleAbort() {
        if (!request) {
          return;
        }
        reject(new AxiosError$1("Request aborted", AxiosError$1.ECONNABORTED, config2, request));
        request = null;
      }, "handleAbort");
      request.onerror = /* @__PURE__ */ __name(function handleError() {
        reject(new AxiosError$1("Network Error", AxiosError$1.ERR_NETWORK, config2, request));
        request = null;
      }, "handleError");
      request.ontimeout = /* @__PURE__ */ __name(function handleTimeout() {
        let timeoutErrorMessage = _config.timeout ? "timeout of " + _config.timeout + "ms exceeded" : "timeout exceeded";
        const transitional = _config.transitional || transitionalDefaults;
        if (_config.timeoutErrorMessage) {
          timeoutErrorMessage = _config.timeoutErrorMessage;
        }
        reject(new AxiosError$1(
          timeoutErrorMessage,
          transitional.clarifyTimeoutError ? AxiosError$1.ETIMEDOUT : AxiosError$1.ECONNABORTED,
          config2,
          request
        ));
        request = null;
      }, "handleTimeout");
      requestData === void 0 && requestHeaders.setContentType(null);
      if ("setRequestHeader" in request) {
        utils$1.forEach(requestHeaders.toJSON(), /* @__PURE__ */ __name(function setRequestHeader(val, key) {
          request.setRequestHeader(key, val);
        }, "setRequestHeader"));
      }
      if (!utils$1.isUndefined(_config.withCredentials)) {
        request.withCredentials = !!_config.withCredentials;
      }
      if (responseType && responseType !== "json") {
        request.responseType = _config.responseType;
      }
      if (onDownloadProgress) {
        [downloadThrottled, flushDownload] = progressEventReducer(onDownloadProgress, true);
        request.addEventListener("progress", downloadThrottled);
      }
      if (onUploadProgress && request.upload) {
        [uploadThrottled, flushUpload] = progressEventReducer(onUploadProgress);
        request.upload.addEventListener("progress", uploadThrottled);
        request.upload.addEventListener("loadend", flushUpload);
      }
      if (_config.cancelToken || _config.signal) {
        onCanceled = /* @__PURE__ */ __name((cancel) => {
          if (!request) {
            return;
          }
          reject(!cancel || cancel.type ? new CanceledError$1(null, config2, request) : cancel);
          request.abort();
          request = null;
        }, "onCanceled");
        _config.cancelToken && _config.cancelToken.subscribe(onCanceled);
        if (_config.signal) {
          _config.signal.aborted ? onCanceled() : _config.signal.addEventListener("abort", onCanceled);
        }
      }
      const protocol2 = parseProtocol(_config.url);
      if (protocol2 && platform.protocols.indexOf(protocol2) === -1) {
        reject(new AxiosError$1("Unsupported protocol " + protocol2 + ":", AxiosError$1.ERR_BAD_REQUEST, config2));
        return;
      }
      request.send(requestData || null);
    }, "dispatchXhrRequest"));
  };
  const composeSignals = /* @__PURE__ */ __name((signals, timeout) => {
    const { length } = signals = signals ? signals.filter(Boolean) : [];
    if (timeout || length) {
      let controller = new AbortController();
      let aborted;
      const onabort = /* @__PURE__ */ __name(function(reason) {
        if (!aborted) {
          aborted = true;
          unsubscribe();
          const err = reason instanceof Error ? reason : this.reason;
          controller.abort(err instanceof AxiosError$1 ? err : new CanceledError$1(err instanceof Error ? err.message : err));
        }
      }, "onabort");
      let timer = timeout && setTimeout(() => {
        timer = null;
        onabort(new AxiosError$1(`timeout ${timeout} of ms exceeded`, AxiosError$1.ETIMEDOUT));
      }, timeout);
      const unsubscribe = /* @__PURE__ */ __name(() => {
        if (signals) {
          timer && clearTimeout(timer);
          timer = null;
          signals.forEach((signal2) => {
            signal2.unsubscribe ? signal2.unsubscribe(onabort) : signal2.removeEventListener("abort", onabort);
          });
          signals = null;
        }
      }, "unsubscribe");
      signals.forEach((signal2) => signal2.addEventListener("abort", onabort));
      const { signal } = controller;
      signal.unsubscribe = () => utils$1.asap(unsubscribe);
      return signal;
    }
  }, "composeSignals");
  const streamChunk = /* @__PURE__ */ __name(function* (chunk, chunkSize) {
    let len = chunk.byteLength;
    if (len < chunkSize) {
      yield chunk;
      return;
    }
    let pos = 0;
    let end;
    while (pos < len) {
      end = pos + chunkSize;
      yield chunk.slice(pos, end);
      pos = end;
    }
  }, "streamChunk");
  const readBytes = /* @__PURE__ */ __name(async function* (iterable, chunkSize) {
    for await (const chunk of readStream(iterable)) {
      yield* streamChunk(chunk, chunkSize);
    }
  }, "readBytes");
  const readStream = /* @__PURE__ */ __name(async function* (stream) {
    if (stream[Symbol.asyncIterator]) {
      yield* stream;
      return;
    }
    const reader = stream.getReader();
    try {
      for (; ; ) {
        const { done, value: value2 } = await reader.read();
        if (done) {
          break;
        }
        yield value2;
      }
    } finally {
      await reader.cancel();
    }
  }, "readStream");
  const trackStream = /* @__PURE__ */ __name((stream, chunkSize, onProgress, onFinish) => {
    const iterator2 = readBytes(stream, chunkSize);
    let bytes = 0;
    let done;
    let _onFinish = /* @__PURE__ */ __name((e) => {
      if (!done) {
        done = true;
        onFinish && onFinish(e);
      }
    }, "_onFinish");
    return new ReadableStream({
      async pull(controller) {
        try {
          const { done: done2, value: value2 } = await iterator2.next();
          if (done2) {
            _onFinish();
            controller.close();
            return;
          }
          let len = value2.byteLength;
          if (onProgress) {
            let loadedBytes = bytes += len;
            onProgress(loadedBytes);
          }
          controller.enqueue(new Uint8Array(value2));
        } catch (err) {
          _onFinish(err);
          throw err;
        }
      },
      cancel(reason) {
        _onFinish(reason);
        return iterator2.return();
      }
    }, {
      highWaterMark: 2
    });
  }, "trackStream");
  const isFetchSupported = typeof fetch === "function" && typeof Request === "function" && typeof Response === "function";
  const isReadableStreamSupported = isFetchSupported && typeof ReadableStream === "function";
  const encodeText = isFetchSupported && (typeof TextEncoder === "function" ? /* @__PURE__ */ ((encoder) => (str) => encoder.encode(str))(new TextEncoder()) : async (str) => new Uint8Array(await new Response(str).arrayBuffer()));
  const test = /* @__PURE__ */ __name((fn, ...args) => {
    try {
      return !!fn(...args);
    } catch (e) {
      return false;
    }
  }, "test");
  const supportsRequestStream = isReadableStreamSupported && test(() => {
    let duplexAccessed = false;
    const hasContentType = new Request(platform.origin, {
      body: new ReadableStream(),
      method: "POST",
      get duplex() {
        duplexAccessed = true;
        return "half";
      }
    }).headers.has("Content-Type");
    return duplexAccessed && !hasContentType;
  });
  const DEFAULT_CHUNK_SIZE = 64 * 1024;
  const supportsResponseStream = isReadableStreamSupported && test(() => utils$1.isReadableStream(new Response("").body));
  const resolvers = {
    stream: supportsResponseStream && ((res) => res.body)
  };
  isFetchSupported && ((res) => {
    ["text", "arrayBuffer", "blob", "formData", "stream"].forEach((type) => {
      !resolvers[type] && (resolvers[type] = utils$1.isFunction(res[type]) ? (res2) => res2[type]() : (_, config2) => {
        throw new AxiosError$1(`Response type '${type}' is not supported`, AxiosError$1.ERR_NOT_SUPPORT, config2);
      });
    });
  })(new Response());
  const getBodyLength = /* @__PURE__ */ __name(async (body) => {
    if (body == null) {
      return 0;
    }
    if (utils$1.isBlob(body)) {
      return body.size;
    }
    if (utils$1.isSpecCompliantForm(body)) {
      const _request = new Request(platform.origin, {
        method: "POST",
        body
      });
      return (await _request.arrayBuffer()).byteLength;
    }
    if (utils$1.isArrayBufferView(body) || utils$1.isArrayBuffer(body)) {
      return body.byteLength;
    }
    if (utils$1.isURLSearchParams(body)) {
      body = body + "";
    }
    if (utils$1.isString(body)) {
      return (await encodeText(body)).byteLength;
    }
  }, "getBodyLength");
  const resolveBodyLength = /* @__PURE__ */ __name(async (headers, body) => {
    const length = utils$1.toFiniteNumber(headers.getContentLength());
    return length == null ? getBodyLength(body) : length;
  }, "resolveBodyLength");
  const fetchAdapter = isFetchSupported && (async (config2) => {
    let {
      url: url2,
      method,
      data,
      signal,
      cancelToken,
      timeout,
      onDownloadProgress,
      onUploadProgress,
      responseType,
      headers,
      withCredentials = "same-origin",
      fetchOptions
    } = resolveConfig(config2);
    responseType = responseType ? (responseType + "").toLowerCase() : "text";
    let composedSignal = composeSignals([signal, cancelToken && cancelToken.toAbortSignal()], timeout);
    let request;
    const unsubscribe = composedSignal && composedSignal.unsubscribe && (() => {
      composedSignal.unsubscribe();
    });
    let requestContentLength;
    try {
      if (onUploadProgress && supportsRequestStream && method !== "get" && method !== "head" && (requestContentLength = await resolveBodyLength(headers, data)) !== 0) {
        let _request = new Request(url2, {
          method: "POST",
          body: data,
          duplex: "half"
        });
        let contentTypeHeader;
        if (utils$1.isFormData(data) && (contentTypeHeader = _request.headers.get("content-type"))) {
          headers.setContentType(contentTypeHeader);
        }
        if (_request.body) {
          const [onProgress, flush] = progressEventDecorator(
            requestContentLength,
            progressEventReducer(asyncDecorator(onUploadProgress))
          );
          data = trackStream(_request.body, DEFAULT_CHUNK_SIZE, onProgress, flush);
        }
      }
      if (!utils$1.isString(withCredentials)) {
        withCredentials = withCredentials ? "include" : "omit";
      }
      const isCredentialsSupported = "credentials" in Request.prototype;
      request = new Request(url2, {
        ...fetchOptions,
        signal: composedSignal,
        method: method.toUpperCase(),
        headers: headers.normalize().toJSON(),
        body: data,
        duplex: "half",
        credentials: isCredentialsSupported ? withCredentials : void 0
      });
      let response = await fetch(request);
      const isStreamResponse = supportsResponseStream && (responseType === "stream" || responseType === "response");
      if (supportsResponseStream && (onDownloadProgress || isStreamResponse && unsubscribe)) {
        const options = {};
        ["status", "statusText", "headers"].forEach((prop) => {
          options[prop] = response[prop];
        });
        const responseContentLength = utils$1.toFiniteNumber(response.headers.get("content-length"));
        const [onProgress, flush] = onDownloadProgress && progressEventDecorator(
          responseContentLength,
          progressEventReducer(asyncDecorator(onDownloadProgress), true)
        ) || [];
        response = new Response(
          trackStream(response.body, DEFAULT_CHUNK_SIZE, onProgress, () => {
            flush && flush();
            unsubscribe && unsubscribe();
          }),
          options
        );
      }
      responseType = responseType || "text";
      let responseData = await resolvers[utils$1.findKey(resolvers, responseType) || "text"](response, config2);
      !isStreamResponse && unsubscribe && unsubscribe();
      return await new Promise((resolve, reject) => {
        settle(resolve, reject, {
          data: responseData,
          headers: AxiosHeaders$1.from(response.headers),
          status: response.status,
          statusText: response.statusText,
          config: config2,
          request
        });
      });
    } catch (err) {
      unsubscribe && unsubscribe();
      if (err && err.name === "TypeError" && /fetch/i.test(err.message)) {
        throw Object.assign(
          new AxiosError$1("Network Error", AxiosError$1.ERR_NETWORK, config2, request),
          {
            cause: err.cause || err
          }
        );
      }
      throw AxiosError$1.from(err, err && err.code, config2, request);
    }
  });
  const knownAdapters = {
    http: httpAdapter,
    xhr: xhrAdapter,
    fetch: fetchAdapter
  };
  utils$1.forEach(knownAdapters, (fn, value2) => {
    if (fn) {
      try {
        Object.defineProperty(fn, "name", { value: value2 });
      } catch (e) {
      }
      Object.defineProperty(fn, "adapterName", { value: value2 });
    }
  });
  const renderReason = /* @__PURE__ */ __name((reason) => `- ${reason}`, "renderReason");
  const isResolvedHandle = /* @__PURE__ */ __name((adapter) => utils$1.isFunction(adapter) || adapter === null || adapter === false, "isResolvedHandle");
  const adapters = {
    getAdapter: /* @__PURE__ */ __name((adapters2) => {
      adapters2 = utils$1.isArray(adapters2) ? adapters2 : [adapters2];
      const { length } = adapters2;
      let nameOrAdapter;
      let adapter;
      const rejectedReasons = {};
      for (let i = 0; i < length; i++) {
        nameOrAdapter = adapters2[i];
        let id;
        adapter = nameOrAdapter;
        if (!isResolvedHandle(nameOrAdapter)) {
          adapter = knownAdapters[(id = String(nameOrAdapter)).toLowerCase()];
          if (adapter === void 0) {
            throw new AxiosError$1(`Unknown adapter '${id}'`);
          }
        }
        if (adapter) {
          break;
        }
        rejectedReasons[id || "#" + i] = adapter;
      }
      if (!adapter) {
        const reasons = Object.entries(rejectedReasons).map(
          ([id, state]) => `adapter ${id} ` + (state === false ? "is not supported by the environment" : "is not available in the build")
        );
        let s = length ? reasons.length > 1 ? "since :\n" + reasons.map(renderReason).join("\n") : " " + renderReason(reasons[0]) : "as no adapter specified";
        throw new AxiosError$1(
          `There is no suitable adapter to dispatch the request ` + s,
          "ERR_NOT_SUPPORT"
        );
      }
      return adapter;
    }, "getAdapter"),
    adapters: knownAdapters
  };
  function throwIfCancellationRequested(config2) {
    if (config2.cancelToken) {
      config2.cancelToken.throwIfRequested();
    }
    if (config2.signal && config2.signal.aborted) {
      throw new CanceledError$1(null, config2);
    }
  }
  __name(throwIfCancellationRequested, "throwIfCancellationRequested");
  function dispatchRequest(config2) {
    throwIfCancellationRequested(config2);
    config2.headers = AxiosHeaders$1.from(config2.headers);
    config2.data = transformData.call(
      config2,
      config2.transformRequest
    );
    if (["post", "put", "patch"].indexOf(config2.method) !== -1) {
      config2.headers.setContentType("application/x-www-form-urlencoded", false);
    }
    const adapter = adapters.getAdapter(config2.adapter || defaults.adapter);
    return adapter(config2).then(/* @__PURE__ */ __name(function onAdapterResolution(response) {
      throwIfCancellationRequested(config2);
      response.data = transformData.call(
        config2,
        config2.transformResponse,
        response
      );
      response.headers = AxiosHeaders$1.from(response.headers);
      return response;
    }, "onAdapterResolution"), /* @__PURE__ */ __name(function onAdapterRejection(reason) {
      if (!isCancel$1(reason)) {
        throwIfCancellationRequested(config2);
        if (reason && reason.response) {
          reason.response.data = transformData.call(
            config2,
            config2.transformResponse,
            reason.response
          );
          reason.response.headers = AxiosHeaders$1.from(reason.response.headers);
        }
      }
      return Promise.reject(reason);
    }, "onAdapterRejection"));
  }
  __name(dispatchRequest, "dispatchRequest");
  const VERSION$1 = "1.8.4";
  const validators$1 = {};
  ["object", "boolean", "number", "function", "string", "symbol"].forEach((type, i) => {
    validators$1[type] = /* @__PURE__ */ __name(function validator2(thing) {
      return typeof thing === type || "a" + (i < 1 ? "n " : " ") + type;
    }, "validator");
  });
  const deprecatedWarnings = {};
  validators$1.transitional = /* @__PURE__ */ __name(function transitional(validator2, version2, message) {
    function formatMessage(opt, desc) {
      return "[Axios v" + VERSION$1 + "] Transitional option '" + opt + "'" + desc + (message ? ". " + message : "");
    }
    __name(formatMessage, "formatMessage");
    return (value2, opt, opts) => {
      if (validator2 === false) {
        throw new AxiosError$1(
          formatMessage(opt, " has been removed" + (version2 ? " in " + version2 : "")),
          AxiosError$1.ERR_DEPRECATED
        );
      }
      if (version2 && !deprecatedWarnings[opt]) {
        deprecatedWarnings[opt] = true;
        console.warn(
          formatMessage(
            opt,
            " has been deprecated since v" + version2 + " and will be removed in the near future"
          )
        );
      }
      return validator2 ? validator2(value2, opt, opts) : true;
    };
  }, "transitional");
  validators$1.spelling = /* @__PURE__ */ __name(function spelling(correctSpelling) {
    return (value2, opt) => {
      console.warn(`${opt} is likely a misspelling of ${correctSpelling}`);
      return true;
    };
  }, "spelling");
  function assertOptions(options, schema, allowUnknown) {
    if (typeof options !== "object") {
      throw new AxiosError$1("options must be an object", AxiosError$1.ERR_BAD_OPTION_VALUE);
    }
    const keys = Object.keys(options);
    let i = keys.length;
    while (i-- > 0) {
      const opt = keys[i];
      const validator2 = schema[opt];
      if (validator2) {
        const value2 = options[opt];
        const result = value2 === void 0 || validator2(value2, opt, options);
        if (result !== true) {
          throw new AxiosError$1("option " + opt + " must be " + result, AxiosError$1.ERR_BAD_OPTION_VALUE);
        }
        continue;
      }
      if (allowUnknown !== true) {
        throw new AxiosError$1("Unknown option " + opt, AxiosError$1.ERR_BAD_OPTION);
      }
    }
  }
  __name(assertOptions, "assertOptions");
  const validator = {
    assertOptions,
    validators: validators$1
  };
  const validators = validator.validators;
  let Axios$1 = (_d = class {
    constructor(instanceConfig) {
      this.defaults = instanceConfig;
      this.interceptors = {
        request: new InterceptorManager(),
        response: new InterceptorManager()
      };
    }
    /**
     * Dispatch a request
     *
     * @param {String|Object} configOrUrl The config specific for this request (merged with this.defaults)
     * @param {?Object} config
     *
     * @returns {Promise} The Promise to be fulfilled
     */
    async request(configOrUrl, config2) {
      try {
        return await this._request(configOrUrl, config2);
      } catch (err) {
        if (err instanceof Error) {
          let dummy = {};
          Error.captureStackTrace ? Error.captureStackTrace(dummy) : dummy = new Error();
          const stack = dummy.stack ? dummy.stack.replace(/^.+\n/, "") : "";
          try {
            if (!err.stack) {
              err.stack = stack;
            } else if (stack && !String(err.stack).endsWith(stack.replace(/^.+\n.+\n/, ""))) {
              err.stack += "\n" + stack;
            }
          } catch (e) {
          }
        }
        throw err;
      }
    }
    _request(configOrUrl, config2) {
      if (typeof configOrUrl === "string") {
        config2 = config2 || {};
        config2.url = configOrUrl;
      } else {
        config2 = configOrUrl || {};
      }
      config2 = mergeConfig$1(this.defaults, config2);
      const { transitional, paramsSerializer, headers } = config2;
      if (transitional !== void 0) {
        validator.assertOptions(transitional, {
          silentJSONParsing: validators.transitional(validators.boolean),
          forcedJSONParsing: validators.transitional(validators.boolean),
          clarifyTimeoutError: validators.transitional(validators.boolean)
        }, false);
      }
      if (paramsSerializer != null) {
        if (utils$1.isFunction(paramsSerializer)) {
          config2.paramsSerializer = {
            serialize: paramsSerializer
          };
        } else {
          validator.assertOptions(paramsSerializer, {
            encode: validators.function,
            serialize: validators.function
          }, true);
        }
      }
      if (config2.allowAbsoluteUrls !== void 0) ;
      else if (this.defaults.allowAbsoluteUrls !== void 0) {
        config2.allowAbsoluteUrls = this.defaults.allowAbsoluteUrls;
      } else {
        config2.allowAbsoluteUrls = true;
      }
      validator.assertOptions(config2, {
        baseUrl: validators.spelling("baseURL"),
        withXsrfToken: validators.spelling("withXSRFToken")
      }, true);
      config2.method = (config2.method || this.defaults.method || "get").toLowerCase();
      let contextHeaders = headers && utils$1.merge(
        headers.common,
        headers[config2.method]
      );
      headers && utils$1.forEach(
        ["delete", "get", "head", "post", "put", "patch", "common"],
        (method) => {
          delete headers[method];
        }
      );
      config2.headers = AxiosHeaders$1.concat(contextHeaders, headers);
      const requestInterceptorChain = [];
      let synchronousRequestInterceptors = true;
      this.interceptors.request.forEach(/* @__PURE__ */ __name(function unshiftRequestInterceptors(interceptor) {
        if (typeof interceptor.runWhen === "function" && interceptor.runWhen(config2) === false) {
          return;
        }
        synchronousRequestInterceptors = synchronousRequestInterceptors && interceptor.synchronous;
        requestInterceptorChain.unshift(interceptor.fulfilled, interceptor.rejected);
      }, "unshiftRequestInterceptors"));
      const responseInterceptorChain = [];
      this.interceptors.response.forEach(/* @__PURE__ */ __name(function pushResponseInterceptors(interceptor) {
        responseInterceptorChain.push(interceptor.fulfilled, interceptor.rejected);
      }, "pushResponseInterceptors"));
      let promise;
      let i = 0;
      let len;
      if (!synchronousRequestInterceptors) {
        const chain = [dispatchRequest.bind(this), void 0];
        chain.unshift.apply(chain, requestInterceptorChain);
        chain.push.apply(chain, responseInterceptorChain);
        len = chain.length;
        promise = Promise.resolve(config2);
        while (i < len) {
          promise = promise.then(chain[i++], chain[i++]);
        }
        return promise;
      }
      len = requestInterceptorChain.length;
      let newConfig = config2;
      i = 0;
      while (i < len) {
        const onFulfilled = requestInterceptorChain[i++];
        const onRejected = requestInterceptorChain[i++];
        try {
          newConfig = onFulfilled(newConfig);
        } catch (error) {
          onRejected.call(this, error);
          break;
        }
      }
      try {
        promise = dispatchRequest.call(this, newConfig);
      } catch (error) {
        return Promise.reject(error);
      }
      i = 0;
      len = responseInterceptorChain.length;
      while (i < len) {
        promise = promise.then(responseInterceptorChain[i++], responseInterceptorChain[i++]);
      }
      return promise;
    }
    getUri(config2) {
      config2 = mergeConfig$1(this.defaults, config2);
      const fullPath = buildFullPath(config2.baseURL, config2.url, config2.allowAbsoluteUrls);
      return buildURL(fullPath, config2.params, config2.paramsSerializer);
    }
  }, __name(_d, "Axios"), _d);
  utils$1.forEach(["delete", "get", "head", "options"], /* @__PURE__ */ __name(function forEachMethodNoData(method) {
    Axios$1.prototype[method] = function(url2, config2) {
      return this.request(mergeConfig$1(config2 || {}, {
        method,
        url: url2,
        data: (config2 || {}).data
      }));
    };
  }, "forEachMethodNoData"));
  utils$1.forEach(["post", "put", "patch"], /* @__PURE__ */ __name(function forEachMethodWithData(method) {
    function generateHTTPMethod(isForm) {
      return /* @__PURE__ */ __name(function httpMethod(url2, data, config2) {
        return this.request(mergeConfig$1(config2 || {}, {
          method,
          headers: isForm ? {
            "Content-Type": "multipart/form-data"
          } : {},
          url: url2,
          data
        }));
      }, "httpMethod");
    }
    __name(generateHTTPMethod, "generateHTTPMethod");
    Axios$1.prototype[method] = generateHTTPMethod();
    Axios$1.prototype[method + "Form"] = generateHTTPMethod(true);
  }, "forEachMethodWithData"));
  let CancelToken$1 = (_e = class {
    constructor(executor) {
      if (typeof executor !== "function") {
        throw new TypeError("executor must be a function.");
      }
      let resolvePromise;
      this.promise = new Promise(/* @__PURE__ */ __name(function promiseExecutor(resolve) {
        resolvePromise = resolve;
      }, "promiseExecutor"));
      const token = this;
      this.promise.then((cancel) => {
        if (!token._listeners) return;
        let i = token._listeners.length;
        while (i-- > 0) {
          token._listeners[i](cancel);
        }
        token._listeners = null;
      });
      this.promise.then = (onfulfilled) => {
        let _resolve;
        const promise = new Promise((resolve) => {
          token.subscribe(resolve);
          _resolve = resolve;
        }).then(onfulfilled);
        promise.cancel = /* @__PURE__ */ __name(function reject() {
          token.unsubscribe(_resolve);
        }, "reject");
        return promise;
      };
      executor(/* @__PURE__ */ __name(function cancel(message, config2, request) {
        if (token.reason) {
          return;
        }
        token.reason = new CanceledError$1(message, config2, request);
        resolvePromise(token.reason);
      }, "cancel"));
    }
    /**
     * Throws a `CanceledError` if cancellation has been requested.
     */
    throwIfRequested() {
      if (this.reason) {
        throw this.reason;
      }
    }
    /**
     * Subscribe to the cancel signal
     */
    subscribe(listener) {
      if (this.reason) {
        listener(this.reason);
        return;
      }
      if (this._listeners) {
        this._listeners.push(listener);
      } else {
        this._listeners = [listener];
      }
    }
    /**
     * Unsubscribe from the cancel signal
     */
    unsubscribe(listener) {
      if (!this._listeners) {
        return;
      }
      const index = this._listeners.indexOf(listener);
      if (index !== -1) {
        this._listeners.splice(index, 1);
      }
    }
    toAbortSignal() {
      const controller = new AbortController();
      const abort = /* @__PURE__ */ __name((err) => {
        controller.abort(err);
      }, "abort");
      this.subscribe(abort);
      controller.signal.unsubscribe = () => this.unsubscribe(abort);
      return controller.signal;
    }
    /**
     * Returns an object that contains a new `CancelToken` and a function that, when called,
     * cancels the `CancelToken`.
     */
    static source() {
      let cancel;
      const token = new _e(/* @__PURE__ */ __name(function executor(c) {
        cancel = c;
      }, "executor"));
      return {
        token,
        cancel
      };
    }
  }, __name(_e, "CancelToken"), _e);
  function spread$1(callback) {
    return /* @__PURE__ */ __name(function wrap(arr) {
      return callback.apply(null, arr);
    }, "wrap");
  }
  __name(spread$1, "spread$1");
  function isAxiosError$1(payload) {
    return utils$1.isObject(payload) && payload.isAxiosError === true;
  }
  __name(isAxiosError$1, "isAxiosError$1");
  const HttpStatusCode$1 = {
    Continue: 100,
    SwitchingProtocols: 101,
    Processing: 102,
    EarlyHints: 103,
    Ok: 200,
    Created: 201,
    Accepted: 202,
    NonAuthoritativeInformation: 203,
    NoContent: 204,
    ResetContent: 205,
    PartialContent: 206,
    MultiStatus: 207,
    AlreadyReported: 208,
    ImUsed: 226,
    MultipleChoices: 300,
    MovedPermanently: 301,
    Found: 302,
    SeeOther: 303,
    NotModified: 304,
    UseProxy: 305,
    Unused: 306,
    TemporaryRedirect: 307,
    PermanentRedirect: 308,
    BadRequest: 400,
    Unauthorized: 401,
    PaymentRequired: 402,
    Forbidden: 403,
    NotFound: 404,
    MethodNotAllowed: 405,
    NotAcceptable: 406,
    ProxyAuthenticationRequired: 407,
    RequestTimeout: 408,
    Conflict: 409,
    Gone: 410,
    LengthRequired: 411,
    PreconditionFailed: 412,
    PayloadTooLarge: 413,
    UriTooLong: 414,
    UnsupportedMediaType: 415,
    RangeNotSatisfiable: 416,
    ExpectationFailed: 417,
    ImATeapot: 418,
    MisdirectedRequest: 421,
    UnprocessableEntity: 422,
    Locked: 423,
    FailedDependency: 424,
    TooEarly: 425,
    UpgradeRequired: 426,
    PreconditionRequired: 428,
    TooManyRequests: 429,
    RequestHeaderFieldsTooLarge: 431,
    UnavailableForLegalReasons: 451,
    InternalServerError: 500,
    NotImplemented: 501,
    BadGateway: 502,
    ServiceUnavailable: 503,
    GatewayTimeout: 504,
    HttpVersionNotSupported: 505,
    VariantAlsoNegotiates: 506,
    InsufficientStorage: 507,
    LoopDetected: 508,
    NotExtended: 510,
    NetworkAuthenticationRequired: 511
  };
  Object.entries(HttpStatusCode$1).forEach(([key, value2]) => {
    HttpStatusCode$1[value2] = key;
  });
  function createInstance(defaultConfig) {
    const context = new Axios$1(defaultConfig);
    const instance = bind(Axios$1.prototype.request, context);
    utils$1.extend(instance, Axios$1.prototype, context, { allOwnKeys: true });
    utils$1.extend(instance, context, null, { allOwnKeys: true });
    instance.create = /* @__PURE__ */ __name(function create(instanceConfig) {
      return createInstance(mergeConfig$1(defaultConfig, instanceConfig));
    }, "create");
    return instance;
  }
  __name(createInstance, "createInstance");
  const axios = createInstance(defaults);
  axios.Axios = Axios$1;
  axios.CanceledError = CanceledError$1;
  axios.CancelToken = CancelToken$1;
  axios.isCancel = isCancel$1;
  axios.VERSION = VERSION$1;
  axios.toFormData = toFormData$1;
  axios.AxiosError = AxiosError$1;
  axios.Cancel = axios.CanceledError;
  axios.all = /* @__PURE__ */ __name(function all2(promises) {
    return Promise.all(promises);
  }, "all");
  axios.spread = spread$1;
  axios.isAxiosError = isAxiosError$1;
  axios.mergeConfig = mergeConfig$1;
  axios.AxiosHeaders = AxiosHeaders$1;
  axios.formToJSON = (thing) => formDataToJSON(utils$1.isHTMLForm(thing) ? new FormData(thing) : thing);
  axios.getAdapter = adapters.getAdapter;
  axios.HttpStatusCode = HttpStatusCode$1;
  axios.default = axios;
  const {
    Axios,
    AxiosError,
    CanceledError,
    isCancel,
    CancelToken,
    VERSION,
    all,
    Cancel,
    isAxiosError,
    spread,
    toFormData,
    AxiosHeaders,
    HttpStatusCode,
    formToJSON,
    getAdapter,
    mergeConfig
  } = axios;
  var version = "4.6.1";
  function wait(durationMs, resolveWith) {
    return new Promise(function(resolve) {
      return setTimeout(resolve, durationMs, resolveWith);
    });
  }
  __name(wait, "wait");
  function releaseEventLoop() {
    return new Promise(function(resolve) {
      var channel = new MessageChannel();
      channel.port1.onmessage = function() {
        return resolve();
      };
      channel.port2.postMessage(null);
    });
  }
  __name(releaseEventLoop, "releaseEventLoop");
  function requestIdleCallbackIfAvailable(fallbackTimeout, deadlineTimeout) {
    if (deadlineTimeout === void 0) {
      deadlineTimeout = Infinity;
    }
    var requestIdleCallback = window.requestIdleCallback;
    if (requestIdleCallback) {
      return new Promise(function(resolve) {
        return requestIdleCallback.call(window, function() {
          return resolve();
        }, { timeout: deadlineTimeout });
      });
    } else {
      return wait(Math.min(fallbackTimeout, deadlineTimeout));
    }
  }
  __name(requestIdleCallbackIfAvailable, "requestIdleCallbackIfAvailable");
  function isPromise(value2) {
    return !!value2 && typeof value2.then === "function";
  }
  __name(isPromise, "isPromise");
  function awaitIfAsync(action, callback) {
    try {
      var returnedValue = action();
      if (isPromise(returnedValue)) {
        returnedValue.then(function(result) {
          return callback(true, result);
        }, function(error) {
          return callback(false, error);
        });
      } else {
        callback(true, returnedValue);
      }
    } catch (error) {
      callback(false, error);
    }
  }
  __name(awaitIfAsync, "awaitIfAsync");
  function mapWithBreaks(items, callback, loopReleaseInterval) {
    if (loopReleaseInterval === void 0) {
      loopReleaseInterval = 16;
    }
    return __awaiter(this, void 0, void 0, function() {
      var results, lastLoopReleaseTime, i, now;
      return __generator(this, function(_a2) {
        switch (_a2.label) {
          case 0:
            results = Array(items.length);
            lastLoopReleaseTime = Date.now();
            i = 0;
            _a2.label = 1;
          case 1:
            if (!(i < items.length)) return [3, 4];
            results[i] = callback(items[i], i);
            now = Date.now();
            if (!(now >= lastLoopReleaseTime + loopReleaseInterval)) return [3, 3];
            lastLoopReleaseTime = now;
            return [4, releaseEventLoop()];
          case 2:
            _a2.sent();
            _a2.label = 3;
          case 3:
            ++i;
            return [3, 1];
          case 4:
            return [2, results];
        }
      });
    });
  }
  __name(mapWithBreaks, "mapWithBreaks");
  function suppressUnhandledRejectionWarning(promise) {
    promise.then(void 0, function() {
      return void 0;
    });
    return promise;
  }
  __name(suppressUnhandledRejectionWarning, "suppressUnhandledRejectionWarning");
  function includes(haystack, needle) {
    for (var i = 0, l = haystack.length; i < l; ++i) {
      if (haystack[i] === needle) {
        return true;
      }
    }
    return false;
  }
  __name(includes, "includes");
  function excludes(haystack, needle) {
    return !includes(haystack, needle);
  }
  __name(excludes, "excludes");
  function toInt(value2) {
    return parseInt(value2);
  }
  __name(toInt, "toInt");
  function toFloat(value2) {
    return parseFloat(value2);
  }
  __name(toFloat, "toFloat");
  function replaceNaN(value2, replacement) {
    return typeof value2 === "number" && isNaN(value2) ? replacement : value2;
  }
  __name(replaceNaN, "replaceNaN");
  function countTruthy(values) {
    return values.reduce(function(sum, value2) {
      return sum + (value2 ? 1 : 0);
    }, 0);
  }
  __name(countTruthy, "countTruthy");
  function round(value2, base) {
    if (base === void 0) {
      base = 1;
    }
    if (Math.abs(base) >= 1) {
      return Math.round(value2 / base) * base;
    } else {
      var counterBase = 1 / base;
      return Math.round(value2 * counterBase) / counterBase;
    }
  }
  __name(round, "round");
  function parseSimpleCssSelector(selector) {
    var _a2, _b2;
    var errorMessage = "Unexpected syntax '".concat(selector, "'");
    var tagMatch = /^\s*([a-z-]*)(.*)$/i.exec(selector);
    var tag = tagMatch[1] || void 0;
    var attributes = {};
    var partsRegex = /([.:#][\w-]+|\[.+?\])/gi;
    var addAttribute = /* @__PURE__ */ __name(function(name, value2) {
      attributes[name] = attributes[name] || [];
      attributes[name].push(value2);
    }, "addAttribute");
    for (; ; ) {
      var match = partsRegex.exec(tagMatch[2]);
      if (!match) {
        break;
      }
      var part = match[0];
      switch (part[0]) {
        case ".":
          addAttribute("class", part.slice(1));
          break;
        case "#":
          addAttribute("id", part.slice(1));
          break;
        case "[": {
          var attributeMatch = /^\[([\w-]+)([~|^$*]?=("(.*?)"|([\w-]+)))?(\s+[is])?\]$/.exec(part);
          if (attributeMatch) {
            addAttribute(attributeMatch[1], (_b2 = (_a2 = attributeMatch[4]) !== null && _a2 !== void 0 ? _a2 : attributeMatch[5]) !== null && _b2 !== void 0 ? _b2 : "");
          } else {
            throw new Error(errorMessage);
          }
          break;
        }
        default:
          throw new Error(errorMessage);
      }
    }
    return [tag, attributes];
  }
  __name(parseSimpleCssSelector, "parseSimpleCssSelector");
  function getUTF8Bytes(input) {
    var result = new Uint8Array(input.length);
    for (var i = 0; i < input.length; i++) {
      var charCode = input.charCodeAt(i);
      if (charCode > 127) {
        return new TextEncoder().encode(input);
      }
      result[i] = charCode;
    }
    return result;
  }
  __name(getUTF8Bytes, "getUTF8Bytes");
  function x64Add(m, n) {
    var m0 = m[0] >>> 16, m1 = m[0] & 65535, m2 = m[1] >>> 16, m3 = m[1] & 65535;
    var n0 = n[0] >>> 16, n1 = n[0] & 65535, n2 = n[1] >>> 16, n3 = n[1] & 65535;
    var o0 = 0, o1 = 0, o2 = 0, o3 = 0;
    o3 += m3 + n3;
    o2 += o3 >>> 16;
    o3 &= 65535;
    o2 += m2 + n2;
    o1 += o2 >>> 16;
    o2 &= 65535;
    o1 += m1 + n1;
    o0 += o1 >>> 16;
    o1 &= 65535;
    o0 += m0 + n0;
    o0 &= 65535;
    m[0] = o0 << 16 | o1;
    m[1] = o2 << 16 | o3;
  }
  __name(x64Add, "x64Add");
  function x64Multiply(m, n) {
    var m0 = m[0] >>> 16, m1 = m[0] & 65535, m2 = m[1] >>> 16, m3 = m[1] & 65535;
    var n0 = n[0] >>> 16, n1 = n[0] & 65535, n2 = n[1] >>> 16, n3 = n[1] & 65535;
    var o0 = 0, o1 = 0, o2 = 0, o3 = 0;
    o3 += m3 * n3;
    o2 += o3 >>> 16;
    o3 &= 65535;
    o2 += m2 * n3;
    o1 += o2 >>> 16;
    o2 &= 65535;
    o2 += m3 * n2;
    o1 += o2 >>> 16;
    o2 &= 65535;
    o1 += m1 * n3;
    o0 += o1 >>> 16;
    o1 &= 65535;
    o1 += m2 * n2;
    o0 += o1 >>> 16;
    o1 &= 65535;
    o1 += m3 * n1;
    o0 += o1 >>> 16;
    o1 &= 65535;
    o0 += m0 * n3 + m1 * n2 + m2 * n1 + m3 * n0;
    o0 &= 65535;
    m[0] = o0 << 16 | o1;
    m[1] = o2 << 16 | o3;
  }
  __name(x64Multiply, "x64Multiply");
  function x64Rotl(m, bits) {
    var m0 = m[0];
    bits %= 64;
    if (bits === 32) {
      m[0] = m[1];
      m[1] = m0;
    } else if (bits < 32) {
      m[0] = m0 << bits | m[1] >>> 32 - bits;
      m[1] = m[1] << bits | m0 >>> 32 - bits;
    } else {
      bits -= 32;
      m[0] = m[1] << bits | m0 >>> 32 - bits;
      m[1] = m0 << bits | m[1] >>> 32 - bits;
    }
  }
  __name(x64Rotl, "x64Rotl");
  function x64LeftShift(m, bits) {
    bits %= 64;
    if (bits === 0) {
      return;
    } else if (bits < 32) {
      m[0] = m[1] >>> 32 - bits;
      m[1] = m[1] << bits;
    } else {
      m[0] = m[1] << bits - 32;
      m[1] = 0;
    }
  }
  __name(x64LeftShift, "x64LeftShift");
  function x64Xor(m, n) {
    m[0] ^= n[0];
    m[1] ^= n[1];
  }
  __name(x64Xor, "x64Xor");
  var F1 = [4283543511, 3981806797];
  var F2 = [3301882366, 444984403];
  function x64Fmix(h) {
    var shifted = [0, h[0] >>> 1];
    x64Xor(h, shifted);
    x64Multiply(h, F1);
    shifted[1] = h[0] >>> 1;
    x64Xor(h, shifted);
    x64Multiply(h, F2);
    shifted[1] = h[0] >>> 1;
    x64Xor(h, shifted);
  }
  __name(x64Fmix, "x64Fmix");
  var C1 = [2277735313, 289559509];
  var C2 = [1291169091, 658871167];
  var M$1 = [0, 5];
  var N1 = [0, 1390208809];
  var N2 = [0, 944331445];
  function x64hash128(input, seed) {
    var key = getUTF8Bytes(input);
    seed = seed || 0;
    var length = [0, key.length];
    var remainder = length[1] % 16;
    var bytes = length[1] - remainder;
    var h1 = [0, seed];
    var h2 = [0, seed];
    var k1 = [0, 0];
    var k2 = [0, 0];
    var i;
    for (i = 0; i < bytes; i = i + 16) {
      k1[0] = key[i + 4] | key[i + 5] << 8 | key[i + 6] << 16 | key[i + 7] << 24;
      k1[1] = key[i] | key[i + 1] << 8 | key[i + 2] << 16 | key[i + 3] << 24;
      k2[0] = key[i + 12] | key[i + 13] << 8 | key[i + 14] << 16 | key[i + 15] << 24;
      k2[1] = key[i + 8] | key[i + 9] << 8 | key[i + 10] << 16 | key[i + 11] << 24;
      x64Multiply(k1, C1);
      x64Rotl(k1, 31);
      x64Multiply(k1, C2);
      x64Xor(h1, k1);
      x64Rotl(h1, 27);
      x64Add(h1, h2);
      x64Multiply(h1, M$1);
      x64Add(h1, N1);
      x64Multiply(k2, C2);
      x64Rotl(k2, 33);
      x64Multiply(k2, C1);
      x64Xor(h2, k2);
      x64Rotl(h2, 31);
      x64Add(h2, h1);
      x64Multiply(h2, M$1);
      x64Add(h2, N2);
    }
    k1[0] = 0;
    k1[1] = 0;
    k2[0] = 0;
    k2[1] = 0;
    var val = [0, 0];
    switch (remainder) {
      case 15:
        val[1] = key[i + 14];
        x64LeftShift(val, 48);
        x64Xor(k2, val);
      // fallthrough
      case 14:
        val[1] = key[i + 13];
        x64LeftShift(val, 40);
        x64Xor(k2, val);
      // fallthrough
      case 13:
        val[1] = key[i + 12];
        x64LeftShift(val, 32);
        x64Xor(k2, val);
      // fallthrough
      case 12:
        val[1] = key[i + 11];
        x64LeftShift(val, 24);
        x64Xor(k2, val);
      // fallthrough
      case 11:
        val[1] = key[i + 10];
        x64LeftShift(val, 16);
        x64Xor(k2, val);
      // fallthrough
      case 10:
        val[1] = key[i + 9];
        x64LeftShift(val, 8);
        x64Xor(k2, val);
      // fallthrough
      case 9:
        val[1] = key[i + 8];
        x64Xor(k2, val);
        x64Multiply(k2, C2);
        x64Rotl(k2, 33);
        x64Multiply(k2, C1);
        x64Xor(h2, k2);
      // fallthrough
      case 8:
        val[1] = key[i + 7];
        x64LeftShift(val, 56);
        x64Xor(k1, val);
      // fallthrough
      case 7:
        val[1] = key[i + 6];
        x64LeftShift(val, 48);
        x64Xor(k1, val);
      // fallthrough
      case 6:
        val[1] = key[i + 5];
        x64LeftShift(val, 40);
        x64Xor(k1, val);
      // fallthrough
      case 5:
        val[1] = key[i + 4];
        x64LeftShift(val, 32);
        x64Xor(k1, val);
      // fallthrough
      case 4:
        val[1] = key[i + 3];
        x64LeftShift(val, 24);
        x64Xor(k1, val);
      // fallthrough
      case 3:
        val[1] = key[i + 2];
        x64LeftShift(val, 16);
        x64Xor(k1, val);
      // fallthrough
      case 2:
        val[1] = key[i + 1];
        x64LeftShift(val, 8);
        x64Xor(k1, val);
      // fallthrough
      case 1:
        val[1] = key[i];
        x64Xor(k1, val);
        x64Multiply(k1, C1);
        x64Rotl(k1, 31);
        x64Multiply(k1, C2);
        x64Xor(h1, k1);
    }
    x64Xor(h1, length);
    x64Xor(h2, length);
    x64Add(h1, h2);
    x64Add(h2, h1);
    x64Fmix(h1);
    x64Fmix(h2);
    x64Add(h1, h2);
    x64Add(h2, h1);
    return ("00000000" + (h1[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (h1[1] >>> 0).toString(16)).slice(-8) + ("00000000" + (h2[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (h2[1] >>> 0).toString(16)).slice(-8);
  }
  __name(x64hash128, "x64hash128");
  function errorToObject(error) {
    var _a2;
    return __assign({ name: error.name, message: error.message, stack: (_a2 = error.stack) === null || _a2 === void 0 ? void 0 : _a2.split("\n") }, error);
  }
  __name(errorToObject, "errorToObject");
  function isFunctionNative(func) {
    return /^function\s.*?\{\s*\[native code]\s*}$/.test(String(func));
  }
  __name(isFunctionNative, "isFunctionNative");
  function isFinalResultLoaded(loadResult) {
    return typeof loadResult !== "function";
  }
  __name(isFinalResultLoaded, "isFinalResultLoaded");
  function loadSource(source, sourceOptions) {
    var sourceLoadPromise = suppressUnhandledRejectionWarning(new Promise(function(resolveLoad) {
      var loadStartTime = Date.now();
      awaitIfAsync(source.bind(null, sourceOptions), function() {
        var loadArgs = [];
        for (var _i = 0; _i < arguments.length; _i++) {
          loadArgs[_i] = arguments[_i];
        }
        var loadDuration = Date.now() - loadStartTime;
        if (!loadArgs[0]) {
          return resolveLoad(function() {
            return { error: loadArgs[1], duration: loadDuration };
          });
        }
        var loadResult = loadArgs[1];
        if (isFinalResultLoaded(loadResult)) {
          return resolveLoad(function() {
            return { value: loadResult, duration: loadDuration };
          });
        }
        resolveLoad(function() {
          return new Promise(function(resolveGet) {
            var getStartTime = Date.now();
            awaitIfAsync(loadResult, function() {
              var getArgs = [];
              for (var _i2 = 0; _i2 < arguments.length; _i2++) {
                getArgs[_i2] = arguments[_i2];
              }
              var duration = loadDuration + Date.now() - getStartTime;
              if (!getArgs[0]) {
                return resolveGet({ error: getArgs[1], duration });
              }
              resolveGet({ value: getArgs[1], duration });
            });
          });
        });
      });
    }));
    return /* @__PURE__ */ __name(function getComponent() {
      return sourceLoadPromise.then(function(finalizeSource) {
        return finalizeSource();
      });
    }, "getComponent");
  }
  __name(loadSource, "loadSource");
  function loadSources(sources2, sourceOptions, excludeSources, loopReleaseInterval) {
    var includedSources = Object.keys(sources2).filter(function(sourceKey) {
      return excludes(excludeSources, sourceKey);
    });
    var sourceGettersPromise = suppressUnhandledRejectionWarning(mapWithBreaks(includedSources, function(sourceKey) {
      return loadSource(sources2[sourceKey], sourceOptions);
    }, loopReleaseInterval));
    return /* @__PURE__ */ __name(function getComponents() {
      return __awaiter(this, void 0, void 0, function() {
        var sourceGetters, componentPromises, componentArray, components, index;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, sourceGettersPromise];
            case 1:
              sourceGetters = _a2.sent();
              return [4, mapWithBreaks(sourceGetters, function(sourceGetter) {
                return suppressUnhandledRejectionWarning(sourceGetter());
              }, loopReleaseInterval)];
            case 2:
              componentPromises = _a2.sent();
              return [
                4,
                Promise.all(componentPromises)
                // Keeping the component keys order the same as the source keys order
              ];
            case 3:
              componentArray = _a2.sent();
              components = {};
              for (index = 0; index < includedSources.length; ++index) {
                components[includedSources[index]] = componentArray[index];
              }
              return [2, components];
          }
        });
      });
    }, "getComponents");
  }
  __name(loadSources, "loadSources");
  function isTrident() {
    var w = window;
    var n = navigator;
    return countTruthy([
      "MSCSSMatrix" in w,
      "msSetImmediate" in w,
      "msIndexedDB" in w,
      "msMaxTouchPoints" in n,
      "msPointerEnabled" in n
    ]) >= 4;
  }
  __name(isTrident, "isTrident");
  function isEdgeHTML() {
    var w = window;
    var n = navigator;
    return countTruthy(["msWriteProfilerMark" in w, "MSStream" in w, "msLaunchUri" in n, "msSaveBlob" in n]) >= 3 && !isTrident();
  }
  __name(isEdgeHTML, "isEdgeHTML");
  function isChromium() {
    var w = window;
    var n = navigator;
    return countTruthy([
      "webkitPersistentStorage" in n,
      "webkitTemporaryStorage" in n,
      (n.vendor || "").indexOf("Google") === 0,
      "webkitResolveLocalFileSystemURL" in w,
      "BatteryManager" in w,
      "webkitMediaStream" in w,
      "webkitSpeechGrammar" in w
    ]) >= 5;
  }
  __name(isChromium, "isChromium");
  function isWebKit() {
    var w = window;
    var n = navigator;
    return countTruthy([
      "ApplePayError" in w,
      "CSSPrimitiveValue" in w,
      "Counter" in w,
      n.vendor.indexOf("Apple") === 0,
      "RGBColor" in w,
      "WebKitMediaKeys" in w
    ]) >= 4;
  }
  __name(isWebKit, "isWebKit");
  function isDesktopWebKit() {
    var w = window;
    var HTMLElement = w.HTMLElement, Document = w.Document;
    return countTruthy([
      "safari" in w,
      !("ongestureend" in w),
      !("TouchEvent" in w),
      !("orientation" in w),
      HTMLElement && !("autocapitalize" in HTMLElement.prototype),
      Document && "pointerLockElement" in Document.prototype
    ]) >= 4;
  }
  __name(isDesktopWebKit, "isDesktopWebKit");
  function isSafariWebKit() {
    var w = window;
    return (
      // Filters-out Chrome, Yandex, DuckDuckGo (macOS and iOS), Edge
      isFunctionNative(w.print) && // Doesn't work in Safari < 15.4
      String(w.browser) === "[object WebPageNamespace]"
    );
  }
  __name(isSafariWebKit, "isSafariWebKit");
  function isGecko() {
    var _a2, _b2;
    var w = window;
    return countTruthy([
      "buildID" in navigator,
      "MozAppearance" in ((_b2 = (_a2 = document.documentElement) === null || _a2 === void 0 ? void 0 : _a2.style) !== null && _b2 !== void 0 ? _b2 : {}),
      "onmozfullscreenchange" in w,
      "mozInnerScreenX" in w,
      "CSSMozDocumentRule" in w,
      "CanvasCaptureMediaStream" in w
    ]) >= 4;
  }
  __name(isGecko, "isGecko");
  function isChromium86OrNewer() {
    var w = window;
    return countTruthy([
      !("MediaSettingsRange" in w),
      "RTCEncodedAudioFrame" in w,
      "" + w.Intl === "[object Intl]",
      "" + w.Reflect === "[object Reflect]"
    ]) >= 3;
  }
  __name(isChromium86OrNewer, "isChromium86OrNewer");
  function isChromium122OrNewer() {
    var w = window;
    var URLPattern = w.URLPattern;
    return countTruthy([
      "union" in Set.prototype,
      "Iterator" in w,
      URLPattern && "hasRegExpGroups" in URLPattern.prototype,
      "RGB8" in WebGLRenderingContext.prototype
    ]) >= 3;
  }
  __name(isChromium122OrNewer, "isChromium122OrNewer");
  function isWebKit606OrNewer() {
    var w = window;
    return countTruthy([
      "DOMRectList" in w,
      "RTCPeerConnectionIceEvent" in w,
      "SVGGeometryElement" in w,
      "ontransitioncancel" in w
    ]) >= 3;
  }
  __name(isWebKit606OrNewer, "isWebKit606OrNewer");
  function isWebKit616OrNewer() {
    var w = window;
    var n = navigator;
    var CSS = w.CSS, HTMLButtonElement = w.HTMLButtonElement;
    return countTruthy([
      !("getStorageUpdates" in n),
      HTMLButtonElement && "popover" in HTMLButtonElement.prototype,
      "CSSCounterStyleRule" in w,
      CSS.supports("font-size-adjust: ex-height 0.5"),
      CSS.supports("text-transform: full-width")
    ]) >= 4;
  }
  __name(isWebKit616OrNewer, "isWebKit616OrNewer");
  function isIPad() {
    if (navigator.platform === "iPad") {
      return true;
    }
    var s = screen;
    var screenRatio = s.width / s.height;
    return countTruthy([
      // Since iOS 13. Doesn't work in Chrome on iPadOS <15, but works in desktop mode.
      "MediaSource" in window,
      // Since iOS 12. Doesn't work in Chrome on iPadOS.
      !!Element.prototype.webkitRequestFullscreen,
      // iPhone 4S that runs iOS 9 matches this, but it is not supported
      // Doesn't work in incognito mode of Safari ≥17 with split screen because of tracking prevention
      screenRatio > 0.65 && screenRatio < 1.53
    ]) >= 2;
  }
  __name(isIPad, "isIPad");
  function getFullscreenElement() {
    var d = document;
    return d.fullscreenElement || d.msFullscreenElement || d.mozFullScreenElement || d.webkitFullscreenElement || null;
  }
  __name(getFullscreenElement, "getFullscreenElement");
  function exitFullscreen() {
    var d = document;
    return (d.exitFullscreen || d.msExitFullscreen || d.mozCancelFullScreen || d.webkitExitFullscreen).call(d);
  }
  __name(exitFullscreen, "exitFullscreen");
  function isAndroid() {
    var isItChromium = isChromium();
    var isItGecko = isGecko();
    var w = window;
    var n = navigator;
    var c = "connection";
    if (isItChromium) {
      return countTruthy([
        !("SharedWorker" in w),
        // `typechange` is deprecated, but it's still present on Android (tested on Chrome Mobile 117)
        // Removal proposal https://bugs.chromium.org/p/chromium/issues/detail?id=699892
        // Note: this expression returns true on ChromeOS, so additional detectors are required to avoid false-positives
        n[c] && "ontypechange" in n[c],
        !("sinkId" in new Audio())
      ]) >= 2;
    } else if (isItGecko) {
      return countTruthy(["onorientationchange" in w, "orientation" in w, /android/i.test(n.appVersion)]) >= 2;
    } else {
      return false;
    }
  }
  __name(isAndroid, "isAndroid");
  function isSamsungInternet() {
    var n = navigator;
    var w = window;
    var audioPrototype = Audio.prototype;
    var visualViewport = w.visualViewport;
    return countTruthy([
      "srLatency" in audioPrototype,
      "srChannelCount" in audioPrototype,
      "devicePosture" in n,
      visualViewport && "segments" in visualViewport,
      "getTextInformation" in Image.prototype
      // Not available in Samsung Internet 21
    ]) >= 3;
  }
  __name(isSamsungInternet, "isSamsungInternet");
  function getAudioFingerprint() {
    if (doesBrowserPerformAntifingerprinting$1()) {
      return -4;
    }
    return getUnstableAudioFingerprint();
  }
  __name(getAudioFingerprint, "getAudioFingerprint");
  function getUnstableAudioFingerprint() {
    var w = window;
    var AudioContext2 = w.OfflineAudioContext || w.webkitOfflineAudioContext;
    if (!AudioContext2) {
      return -2;
    }
    if (doesBrowserSuspendAudioContext()) {
      return -1;
    }
    var hashFromIndex = 4500;
    var hashToIndex = 5e3;
    var context = new AudioContext2(1, hashToIndex, 44100);
    var oscillator = context.createOscillator();
    oscillator.type = "triangle";
    oscillator.frequency.value = 1e4;
    var compressor = context.createDynamicsCompressor();
    compressor.threshold.value = -50;
    compressor.knee.value = 40;
    compressor.ratio.value = 12;
    compressor.attack.value = 0;
    compressor.release.value = 0.25;
    oscillator.connect(compressor);
    compressor.connect(context.destination);
    oscillator.start(0);
    var _a2 = startRenderingAudio(context), renderPromise = _a2[0], finishRendering = _a2[1];
    var fingerprintPromise = suppressUnhandledRejectionWarning(renderPromise.then(function(buffer) {
      return getHash(buffer.getChannelData(0).subarray(hashFromIndex));
    }, function(error) {
      if (error.name === "timeout" || error.name === "suspended") {
        return -3;
      }
      throw error;
    }));
    return function() {
      finishRendering();
      return fingerprintPromise;
    };
  }
  __name(getUnstableAudioFingerprint, "getUnstableAudioFingerprint");
  function doesBrowserSuspendAudioContext() {
    return isWebKit() && !isDesktopWebKit() && !isWebKit606OrNewer();
  }
  __name(doesBrowserSuspendAudioContext, "doesBrowserSuspendAudioContext");
  function doesBrowserPerformAntifingerprinting$1() {
    return (
      // Safari ≥17
      isWebKit() && isWebKit616OrNewer() && isSafariWebKit() || // Samsung Internet ≥26
      isChromium() && isSamsungInternet() && isChromium122OrNewer()
    );
  }
  __name(doesBrowserPerformAntifingerprinting$1, "doesBrowserPerformAntifingerprinting$1");
  function startRenderingAudio(context) {
    var renderTryMaxCount = 3;
    var renderRetryDelay = 500;
    var runningMaxAwaitTime = 500;
    var runningSufficientTime = 5e3;
    var finalize = /* @__PURE__ */ __name(function() {
      return void 0;
    }, "finalize");
    var resultPromise = new Promise(function(resolve, reject) {
      var isFinalized = false;
      var renderTryCount = 0;
      var startedRunningAt = 0;
      context.oncomplete = function(event) {
        return resolve(event.renderedBuffer);
      };
      var startRunningTimeout = /* @__PURE__ */ __name(function() {
        setTimeout(function() {
          return reject(makeInnerError(
            "timeout"
            /* InnerErrorName.Timeout */
          ));
        }, Math.min(runningMaxAwaitTime, startedRunningAt + runningSufficientTime - Date.now()));
      }, "startRunningTimeout");
      var tryRender = /* @__PURE__ */ __name(function() {
        try {
          var renderingPromise = context.startRendering();
          if (isPromise(renderingPromise)) {
            suppressUnhandledRejectionWarning(renderingPromise);
          }
          switch (context.state) {
            case "running":
              startedRunningAt = Date.now();
              if (isFinalized) {
                startRunningTimeout();
              }
              break;
            // Sometimes the audio context doesn't start after calling `startRendering` (in addition to the cases where
            // audio context doesn't start at all). A known case is starting an audio context when the browser tab is in
            // background on iPhone. Retries usually help in this case.
            case "suspended":
              if (!document.hidden) {
                renderTryCount++;
              }
              if (isFinalized && renderTryCount >= renderTryMaxCount) {
                reject(makeInnerError(
                  "suspended"
                  /* InnerErrorName.Suspended */
                ));
              } else {
                setTimeout(tryRender, renderRetryDelay);
              }
              break;
          }
        } catch (error) {
          reject(error);
        }
      }, "tryRender");
      tryRender();
      finalize = /* @__PURE__ */ __name(function() {
        if (!isFinalized) {
          isFinalized = true;
          if (startedRunningAt > 0) {
            startRunningTimeout();
          }
        }
      }, "finalize");
    });
    return [resultPromise, finalize];
  }
  __name(startRenderingAudio, "startRenderingAudio");
  function getHash(signal) {
    var hash = 0;
    for (var i = 0; i < signal.length; ++i) {
      hash += Math.abs(signal[i]);
    }
    return hash;
  }
  __name(getHash, "getHash");
  function makeInnerError(name) {
    var error = new Error(name);
    error.name = name;
    return error;
  }
  __name(makeInnerError, "makeInnerError");
  function withIframe(action, initialHtml, domPollInterval) {
    var _a2, _b2, _c2;
    if (domPollInterval === void 0) {
      domPollInterval = 50;
    }
    return __awaiter(this, void 0, void 0, function() {
      var d, iframe;
      return __generator(this, function(_d2) {
        switch (_d2.label) {
          case 0:
            d = document;
            _d2.label = 1;
          case 1:
            if (!!d.body) return [3, 3];
            return [4, wait(domPollInterval)];
          case 2:
            _d2.sent();
            return [3, 1];
          case 3:
            iframe = d.createElement("iframe");
            _d2.label = 4;
          case 4:
            _d2.trys.push([4, , 10, 11]);
            return [4, new Promise(function(_resolve, _reject) {
              var isComplete = false;
              var resolve = /* @__PURE__ */ __name(function() {
                isComplete = true;
                _resolve();
              }, "resolve");
              var reject = /* @__PURE__ */ __name(function(error) {
                isComplete = true;
                _reject(error);
              }, "reject");
              iframe.onload = resolve;
              iframe.onerror = reject;
              var style = iframe.style;
              style.setProperty("display", "block", "important");
              style.position = "absolute";
              style.top = "0";
              style.left = "0";
              style.visibility = "hidden";
              if (initialHtml && "srcdoc" in iframe) {
                iframe.srcdoc = initialHtml;
              } else {
                iframe.src = "about:blank";
              }
              d.body.appendChild(iframe);
              var checkReadyState = /* @__PURE__ */ __name(function() {
                var _a3, _b3;
                if (isComplete) {
                  return;
                }
                if (((_b3 = (_a3 = iframe.contentWindow) === null || _a3 === void 0 ? void 0 : _a3.document) === null || _b3 === void 0 ? void 0 : _b3.readyState) === "complete") {
                  resolve();
                } else {
                  setTimeout(checkReadyState, 10);
                }
              }, "checkReadyState");
              checkReadyState();
            })];
          case 5:
            _d2.sent();
            _d2.label = 6;
          case 6:
            if (!!((_b2 = (_a2 = iframe.contentWindow) === null || _a2 === void 0 ? void 0 : _a2.document) === null || _b2 === void 0 ? void 0 : _b2.body)) return [3, 8];
            return [4, wait(domPollInterval)];
          case 7:
            _d2.sent();
            return [3, 6];
          case 8:
            return [4, action(iframe, iframe.contentWindow)];
          case 9:
            return [2, _d2.sent()];
          case 10:
            (_c2 = iframe.parentNode) === null || _c2 === void 0 ? void 0 : _c2.removeChild(iframe);
            return [
              7
              /*endfinally*/
            ];
          case 11:
            return [
              2
              /*return*/
            ];
        }
      });
    });
  }
  __name(withIframe, "withIframe");
  function selectorToElement(selector) {
    var _a2 = parseSimpleCssSelector(selector), tag = _a2[0], attributes = _a2[1];
    var element = document.createElement(tag !== null && tag !== void 0 ? tag : "div");
    for (var _i = 0, _b2 = Object.keys(attributes); _i < _b2.length; _i++) {
      var name_1 = _b2[_i];
      var value2 = attributes[name_1].join(" ");
      if (name_1 === "style") {
        addStyleString(element.style, value2);
      } else {
        element.setAttribute(name_1, value2);
      }
    }
    return element;
  }
  __name(selectorToElement, "selectorToElement");
  function addStyleString(style, source) {
    for (var _i = 0, _a2 = source.split(";"); _i < _a2.length; _i++) {
      var property = _a2[_i];
      var match = /^\s*([\w-]+)\s*:\s*(.+?)(\s*!([\w-]+))?\s*$/.exec(property);
      if (match) {
        var name_2 = match[1], value2 = match[2], priority = match[4];
        style.setProperty(name_2, value2, priority || "");
      }
    }
  }
  __name(addStyleString, "addStyleString");
  function isAnyParentCrossOrigin() {
    var currentWindow = window;
    for (; ; ) {
      var parentWindow = currentWindow.parent;
      if (!parentWindow || parentWindow === currentWindow) {
        return false;
      }
      try {
        if (parentWindow.location.origin !== currentWindow.location.origin) {
          return true;
        }
      } catch (error) {
        if (error instanceof Error && error.name === "SecurityError") {
          return true;
        }
        throw error;
      }
      currentWindow = parentWindow;
    }
  }
  __name(isAnyParentCrossOrigin, "isAnyParentCrossOrigin");
  var testString = "mmMwWLliI0O&1";
  var textSize = "48px";
  var baseFonts = ["monospace", "sans-serif", "serif"];
  var fontList = [
    // This is android-specific font from "Roboto" family
    "sans-serif-thin",
    "ARNO PRO",
    "Agency FB",
    "Arabic Typesetting",
    "Arial Unicode MS",
    "AvantGarde Bk BT",
    "BankGothic Md BT",
    "Batang",
    "Bitstream Vera Sans Mono",
    "Calibri",
    "Century",
    "Century Gothic",
    "Clarendon",
    "EUROSTILE",
    "Franklin Gothic",
    "Futura Bk BT",
    "Futura Md BT",
    "GOTHAM",
    "Gill Sans",
    "HELV",
    "Haettenschweiler",
    "Helvetica Neue",
    "Humanst521 BT",
    "Leelawadee",
    "Letter Gothic",
    "Levenim MT",
    "Lucida Bright",
    "Lucida Sans",
    "Menlo",
    "MS Mincho",
    "MS Outlook",
    "MS Reference Specialty",
    "MS UI Gothic",
    "MT Extra",
    "MYRIAD PRO",
    "Marlett",
    "Meiryo UI",
    "Microsoft Uighur",
    "Minion Pro",
    "Monotype Corsiva",
    "PMingLiU",
    "Pristina",
    "SCRIPTINA",
    "Segoe UI Light",
    "Serifa",
    "SimHei",
    "Small Fonts",
    "Staccato222 BT",
    "TRAJAN PRO",
    "Univers CE 55 Medium",
    "Vrinda",
    "ZWAdobeF"
  ];
  function getFonts() {
    var _this = this;
    return withIframe(function(_, _a2) {
      var document2 = _a2.document;
      return __awaiter(_this, void 0, void 0, function() {
        var holder, spansContainer, defaultWidth, defaultHeight, createSpan, createSpanWithFonts, initializeBaseFontsSpans, initializeFontsSpans, isFontAvailable, baseFontsSpans, fontsSpans, index;
        return __generator(this, function(_b2) {
          holder = document2.body;
          holder.style.fontSize = textSize;
          spansContainer = document2.createElement("div");
          spansContainer.style.setProperty("visibility", "hidden", "important");
          defaultWidth = {};
          defaultHeight = {};
          createSpan = /* @__PURE__ */ __name(function(fontFamily) {
            var span = document2.createElement("span");
            var style = span.style;
            style.position = "absolute";
            style.top = "0";
            style.left = "0";
            style.fontFamily = fontFamily;
            span.textContent = testString;
            spansContainer.appendChild(span);
            return span;
          }, "createSpan");
          createSpanWithFonts = /* @__PURE__ */ __name(function(fontToDetect, baseFont) {
            return createSpan("'".concat(fontToDetect, "',").concat(baseFont));
          }, "createSpanWithFonts");
          initializeBaseFontsSpans = /* @__PURE__ */ __name(function() {
            return baseFonts.map(createSpan);
          }, "initializeBaseFontsSpans");
          initializeFontsSpans = /* @__PURE__ */ __name(function() {
            var spans = {};
            var _loop_1 = /* @__PURE__ */ __name(function(font2) {
              spans[font2] = baseFonts.map(function(baseFont) {
                return createSpanWithFonts(font2, baseFont);
              });
            }, "_loop_1");
            for (var _i = 0, fontList_1 = fontList; _i < fontList_1.length; _i++) {
              var font = fontList_1[_i];
              _loop_1(font);
            }
            return spans;
          }, "initializeFontsSpans");
          isFontAvailable = /* @__PURE__ */ __name(function(fontSpans) {
            return baseFonts.some(function(baseFont, baseFontIndex) {
              return fontSpans[baseFontIndex].offsetWidth !== defaultWidth[baseFont] || fontSpans[baseFontIndex].offsetHeight !== defaultHeight[baseFont];
            });
          }, "isFontAvailable");
          baseFontsSpans = initializeBaseFontsSpans();
          fontsSpans = initializeFontsSpans();
          holder.appendChild(spansContainer);
          for (index = 0; index < baseFonts.length; index++) {
            defaultWidth[baseFonts[index]] = baseFontsSpans[index].offsetWidth;
            defaultHeight[baseFonts[index]] = baseFontsSpans[index].offsetHeight;
          }
          return [2, fontList.filter(function(font) {
            return isFontAvailable(fontsSpans[font]);
          })];
        });
      });
    });
  }
  __name(getFonts, "getFonts");
  function getPlugins() {
    var rawPlugins = navigator.plugins;
    if (!rawPlugins) {
      return void 0;
    }
    var plugins = [];
    for (var i = 0; i < rawPlugins.length; ++i) {
      var plugin = rawPlugins[i];
      if (!plugin) {
        continue;
      }
      var mimeTypes = [];
      for (var j = 0; j < plugin.length; ++j) {
        var mimeType = plugin[j];
        mimeTypes.push({
          type: mimeType.type,
          suffixes: mimeType.suffixes
        });
      }
      plugins.push({
        name: plugin.name,
        description: plugin.description,
        mimeTypes
      });
    }
    return plugins;
  }
  __name(getPlugins, "getPlugins");
  function getCanvasFingerprint() {
    return getUnstableCanvasFingerprint(doesBrowserPerformAntifingerprinting());
  }
  __name(getCanvasFingerprint, "getCanvasFingerprint");
  function getUnstableCanvasFingerprint(skipImages) {
    var _a2;
    var winding = false;
    var geometry;
    var text;
    var _b2 = makeCanvasContext(), canvas = _b2[0], context = _b2[1];
    if (!isSupported(canvas, context)) {
      geometry = text = "unsupported";
    } else {
      winding = doesSupportWinding(context);
      if (skipImages) {
        geometry = text = "skipped";
      } else {
        _a2 = renderImages(canvas, context), geometry = _a2[0], text = _a2[1];
      }
    }
    return { winding, geometry, text };
  }
  __name(getUnstableCanvasFingerprint, "getUnstableCanvasFingerprint");
  function makeCanvasContext() {
    var canvas = document.createElement("canvas");
    canvas.width = 1;
    canvas.height = 1;
    return [canvas, canvas.getContext("2d")];
  }
  __name(makeCanvasContext, "makeCanvasContext");
  function isSupported(canvas, context) {
    return !!(context && canvas.toDataURL);
  }
  __name(isSupported, "isSupported");
  function doesSupportWinding(context) {
    context.rect(0, 0, 10, 10);
    context.rect(2, 2, 6, 6);
    return !context.isPointInPath(5, 5, "evenodd");
  }
  __name(doesSupportWinding, "doesSupportWinding");
  function renderImages(canvas, context) {
    renderTextImage(canvas, context);
    var textImage1 = canvasToString(canvas);
    var textImage2 = canvasToString(canvas);
    if (textImage1 !== textImage2) {
      return [
        "unstable",
        "unstable"
        /* ImageStatus.Unstable */
      ];
    }
    renderGeometryImage(canvas, context);
    var geometryImage = canvasToString(canvas);
    return [geometryImage, textImage1];
  }
  __name(renderImages, "renderImages");
  function renderTextImage(canvas, context) {
    canvas.width = 240;
    canvas.height = 60;
    context.textBaseline = "alphabetic";
    context.fillStyle = "#f60";
    context.fillRect(100, 1, 62, 20);
    context.fillStyle = "#069";
    context.font = '11pt "Times New Roman"';
    var printedText = "Cwm fjordbank gly ".concat(
      String.fromCharCode(55357, 56835)
      /* 😃 */
    );
    context.fillText(printedText, 2, 15);
    context.fillStyle = "rgba(102, 204, 0, 0.2)";
    context.font = "18pt Arial";
    context.fillText(printedText, 4, 45);
  }
  __name(renderTextImage, "renderTextImage");
  function renderGeometryImage(canvas, context) {
    canvas.width = 122;
    canvas.height = 110;
    context.globalCompositeOperation = "multiply";
    for (var _i = 0, _a2 = [
      ["#f2f", 40, 40],
      ["#2ff", 80, 40],
      ["#ff2", 60, 80]
    ]; _i < _a2.length; _i++) {
      var _b2 = _a2[_i], color = _b2[0], x = _b2[1], y = _b2[2];
      context.fillStyle = color;
      context.beginPath();
      context.arc(x, y, 40, 0, Math.PI * 2, true);
      context.closePath();
      context.fill();
    }
    context.fillStyle = "#f9c";
    context.arc(60, 60, 60, 0, Math.PI * 2, true);
    context.arc(60, 60, 20, 0, Math.PI * 2, true);
    context.fill("evenodd");
  }
  __name(renderGeometryImage, "renderGeometryImage");
  function canvasToString(canvas) {
    return canvas.toDataURL();
  }
  __name(canvasToString, "canvasToString");
  function doesBrowserPerformAntifingerprinting() {
    return isWebKit() && isWebKit616OrNewer() && isSafariWebKit();
  }
  __name(doesBrowserPerformAntifingerprinting, "doesBrowserPerformAntifingerprinting");
  function getTouchSupport() {
    var n = navigator;
    var maxTouchPoints = 0;
    var touchEvent;
    if (n.maxTouchPoints !== void 0) {
      maxTouchPoints = toInt(n.maxTouchPoints);
    } else if (n.msMaxTouchPoints !== void 0) {
      maxTouchPoints = n.msMaxTouchPoints;
    }
    try {
      document.createEvent("TouchEvent");
      touchEvent = true;
    } catch (_a2) {
      touchEvent = false;
    }
    var touchStart = "ontouchstart" in window;
    return {
      maxTouchPoints,
      touchEvent,
      touchStart
    };
  }
  __name(getTouchSupport, "getTouchSupport");
  function getOsCpu() {
    return navigator.oscpu;
  }
  __name(getOsCpu, "getOsCpu");
  function getLanguages() {
    var n = navigator;
    var result = [];
    var language = n.language || n.userLanguage || n.browserLanguage || n.systemLanguage;
    if (language !== void 0) {
      result.push([language]);
    }
    if (Array.isArray(n.languages)) {
      if (!(isChromium() && isChromium86OrNewer())) {
        result.push(n.languages);
      }
    } else if (typeof n.languages === "string") {
      var languages = n.languages;
      if (languages) {
        result.push(languages.split(","));
      }
    }
    return result;
  }
  __name(getLanguages, "getLanguages");
  function getColorDepth() {
    return window.screen.colorDepth;
  }
  __name(getColorDepth, "getColorDepth");
  function getDeviceMemory() {
    return replaceNaN(toFloat(navigator.deviceMemory), void 0);
  }
  __name(getDeviceMemory, "getDeviceMemory");
  function getScreenResolution() {
    if (isWebKit() && isWebKit616OrNewer() && isSafariWebKit()) {
      return void 0;
    }
    return getUnstableScreenResolution();
  }
  __name(getScreenResolution, "getScreenResolution");
  function getUnstableScreenResolution() {
    var s = screen;
    var parseDimension = /* @__PURE__ */ __name(function(value2) {
      return replaceNaN(toInt(value2), null);
    }, "parseDimension");
    var dimensions = [parseDimension(s.width), parseDimension(s.height)];
    dimensions.sort().reverse();
    return dimensions;
  }
  __name(getUnstableScreenResolution, "getUnstableScreenResolution");
  var screenFrameCheckInterval = 2500;
  var roundingPrecision = 10;
  var screenFrameBackup;
  var screenFrameSizeTimeoutId;
  function watchScreenFrame() {
    if (screenFrameSizeTimeoutId !== void 0) {
      return;
    }
    var checkScreenFrame = /* @__PURE__ */ __name(function() {
      var frameSize = getCurrentScreenFrame();
      if (isFrameSizeNull(frameSize)) {
        screenFrameSizeTimeoutId = setTimeout(checkScreenFrame, screenFrameCheckInterval);
      } else {
        screenFrameBackup = frameSize;
        screenFrameSizeTimeoutId = void 0;
      }
    }, "checkScreenFrame");
    checkScreenFrame();
  }
  __name(watchScreenFrame, "watchScreenFrame");
  function getUnstableScreenFrame() {
    var _this = this;
    watchScreenFrame();
    return function() {
      return __awaiter(_this, void 0, void 0, function() {
        var frameSize;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              frameSize = getCurrentScreenFrame();
              if (!isFrameSizeNull(frameSize)) return [3, 2];
              if (screenFrameBackup) {
                return [2, __spreadArray$1([], screenFrameBackup, true)];
              }
              if (!getFullscreenElement()) return [3, 2];
              return [4, exitFullscreen()];
            case 1:
              _a2.sent();
              frameSize = getCurrentScreenFrame();
              _a2.label = 2;
            case 2:
              if (!isFrameSizeNull(frameSize)) {
                screenFrameBackup = frameSize;
              }
              return [2, frameSize];
          }
        });
      });
    };
  }
  __name(getUnstableScreenFrame, "getUnstableScreenFrame");
  function getScreenFrame() {
    var _this = this;
    if (isWebKit() && isWebKit616OrNewer() && isSafariWebKit()) {
      return function() {
        return Promise.resolve(void 0);
      };
    }
    var screenFrameGetter = getUnstableScreenFrame();
    return function() {
      return __awaiter(_this, void 0, void 0, function() {
        var frameSize, processSize;
        return __generator(this, function(_a2) {
          switch (_a2.label) {
            case 0:
              return [4, screenFrameGetter()];
            case 1:
              frameSize = _a2.sent();
              processSize = /* @__PURE__ */ __name(function(sideSize) {
                return sideSize === null ? null : round(sideSize, roundingPrecision);
              }, "processSize");
              return [2, [processSize(frameSize[0]), processSize(frameSize[1]), processSize(frameSize[2]), processSize(frameSize[3])]];
          }
        });
      });
    };
  }
  __name(getScreenFrame, "getScreenFrame");
  function getCurrentScreenFrame() {
    var s = screen;
    return [
      replaceNaN(toFloat(s.availTop), null),
      replaceNaN(toFloat(s.width) - toFloat(s.availWidth) - replaceNaN(toFloat(s.availLeft), 0), null),
      replaceNaN(toFloat(s.height) - toFloat(s.availHeight) - replaceNaN(toFloat(s.availTop), 0), null),
      replaceNaN(toFloat(s.availLeft), null)
    ];
  }
  __name(getCurrentScreenFrame, "getCurrentScreenFrame");
  function isFrameSizeNull(frameSize) {
    for (var i = 0; i < 4; ++i) {
      if (frameSize[i]) {
        return false;
      }
    }
    return true;
  }
  __name(isFrameSizeNull, "isFrameSizeNull");
  function getHardwareConcurrency() {
    return replaceNaN(toInt(navigator.hardwareConcurrency), void 0);
  }
  __name(getHardwareConcurrency, "getHardwareConcurrency");
  function getTimezone() {
    var _a2;
    var DateTimeFormat = (_a2 = window.Intl) === null || _a2 === void 0 ? void 0 : _a2.DateTimeFormat;
    if (DateTimeFormat) {
      var timezone = new DateTimeFormat().resolvedOptions().timeZone;
      if (timezone) {
        return timezone;
      }
    }
    var offset = -getTimezoneOffset();
    return "UTC".concat(offset >= 0 ? "+" : "").concat(offset);
  }
  __name(getTimezone, "getTimezone");
  function getTimezoneOffset() {
    var currentYear = (/* @__PURE__ */ new Date()).getFullYear();
    return Math.max(
      // `getTimezoneOffset` returns a number as a string in some unidentified cases
      toFloat(new Date(currentYear, 0, 1).getTimezoneOffset()),
      toFloat(new Date(currentYear, 6, 1).getTimezoneOffset())
    );
  }
  __name(getTimezoneOffset, "getTimezoneOffset");
  function getSessionStorage() {
    try {
      return !!window.sessionStorage;
    } catch (error) {
      return true;
    }
  }
  __name(getSessionStorage, "getSessionStorage");
  function getLocalStorage() {
    try {
      return !!window.localStorage;
    } catch (e) {
      return true;
    }
  }
  __name(getLocalStorage, "getLocalStorage");
  function getIndexedDB() {
    if (isTrident() || isEdgeHTML()) {
      return void 0;
    }
    try {
      return !!window.indexedDB;
    } catch (e) {
      return true;
    }
  }
  __name(getIndexedDB, "getIndexedDB");
  function getOpenDatabase() {
    return !!window.openDatabase;
  }
  __name(getOpenDatabase, "getOpenDatabase");
  function getCpuClass() {
    return navigator.cpuClass;
  }
  __name(getCpuClass, "getCpuClass");
  function getPlatform() {
    var platform2 = navigator.platform;
    if (platform2 === "MacIntel") {
      if (isWebKit() && !isDesktopWebKit()) {
        return isIPad() ? "iPad" : "iPhone";
      }
    }
    return platform2;
  }
  __name(getPlatform, "getPlatform");
  function getVendor() {
    return navigator.vendor || "";
  }
  __name(getVendor, "getVendor");
  function getVendorFlavors() {
    var flavors = [];
    for (var _i = 0, _a2 = [
      // Blink and some browsers on iOS
      "chrome",
      // Safari on macOS
      "safari",
      // Chrome on iOS (checked in 85 on 13 and 87 on 14)
      "__crWeb",
      "__gCrWeb",
      // Yandex Browser on iOS, macOS and Android (checked in 21.2 on iOS 14, macOS and Android)
      "yandex",
      // Yandex Browser on iOS (checked in 21.2 on 14)
      "__yb",
      "__ybro",
      // Firefox on iOS (checked in 32 on 14)
      "__firefox__",
      // Edge on iOS (checked in 46 on 14)
      "__edgeTrackingPreventionStatistics",
      "webkit",
      // Opera Touch on iOS (checked in 2.6 on 14)
      "oprt",
      // Samsung Internet on Android (checked in 11.1)
      "samsungAr",
      // UC Browser on Android (checked in 12.10 and 13.0)
      "ucweb",
      "UCShellJava",
      // Puffin on Android (checked in 9.0)
      "puffinDevice"
      // UC on iOS and Opera on Android have no specific global variables
      // Edge for Android isn't checked
    ]; _i < _a2.length; _i++) {
      var key = _a2[_i];
      var value2 = window[key];
      if (value2 && typeof value2 === "object") {
        flavors.push(key);
      }
    }
    return flavors.sort();
  }
  __name(getVendorFlavors, "getVendorFlavors");
  function areCookiesEnabled() {
    var d = document;
    try {
      d.cookie = "cookietest=1; SameSite=Strict;";
      var result = d.cookie.indexOf("cookietest=") !== -1;
      d.cookie = "cookietest=1; SameSite=Strict; expires=Thu, 01-Jan-1970 00:00:01 GMT";
      return result;
    } catch (e) {
      return false;
    }
  }
  __name(areCookiesEnabled, "areCookiesEnabled");
  function getFilters() {
    var fromB64 = atob;
    return {
      abpIndo: [
        "#Iklan-Melayang",
        "#Kolom-Iklan-728",
        "#SidebarIklan-wrapper",
        '[title="ALIENBOLA" i]',
        fromB64("I0JveC1CYW5uZXItYWRz")
      ],
      abpvn: [".quangcao", "#mobileCatfish", fromB64("LmNsb3NlLWFkcw=="), '[id^="bn_bottom_fixed_"]', "#pmadv"],
      adBlockFinland: [
        ".mainostila",
        fromB64("LnNwb25zb3JpdA=="),
        ".ylamainos",
        fromB64("YVtocmVmKj0iL2NsaWNrdGhyZ2guYXNwPyJd"),
        fromB64("YVtocmVmXj0iaHR0cHM6Ly9hcHAucmVhZHBlYWsuY29tL2FkcyJd")
      ],
      adBlockPersian: [
        "#navbar_notice_50",
        ".kadr",
        'TABLE[width="140px"]',
        "#divAgahi",
        fromB64("YVtocmVmXj0iaHR0cDovL2cxLnYuZndtcm0ubmV0L2FkLyJd")
      ],
      adBlockWarningRemoval: [
        "#adblock-honeypot",
        ".adblocker-root",
        ".wp_adblock_detect",
        fromB64("LmhlYWRlci1ibG9ja2VkLWFk"),
        fromB64("I2FkX2Jsb2NrZXI=")
      ],
      adGuardAnnoyances: [
        ".hs-sosyal",
        "#cookieconsentdiv",
        'div[class^="app_gdpr"]',
        ".as-oil",
        '[data-cypress="soft-push-notification-modal"]'
      ],
      adGuardBase: [
        ".BetterJsPopOverlay",
        fromB64("I2FkXzMwMFgyNTA="),
        fromB64("I2Jhbm5lcmZsb2F0MjI="),
        fromB64("I2NhbXBhaWduLWJhbm5lcg=="),
        fromB64("I0FkLUNvbnRlbnQ=")
      ],
      adGuardChinese: [
        fromB64("LlppX2FkX2FfSA=="),
        fromB64("YVtocmVmKj0iLmh0aGJldDM0LmNvbSJd"),
        "#widget-quan",
        fromB64("YVtocmVmKj0iLzg0OTkyMDIwLnh5eiJd"),
        fromB64("YVtocmVmKj0iLjE5NTZobC5jb20vIl0=")
      ],
      adGuardFrench: [
        "#pavePub",
        fromB64("LmFkLWRlc2t0b3AtcmVjdGFuZ2xl"),
        ".mobile_adhesion",
        ".widgetadv",
        fromB64("LmFkc19iYW4=")
      ],
      adGuardGerman: ['aside[data-portal-id="leaderboard"]'],
      adGuardJapanese: [
        "#kauli_yad_1",
        fromB64("YVtocmVmXj0iaHR0cDovL2FkMi50cmFmZmljZ2F0ZS5uZXQvIl0="),
        fromB64("Ll9wb3BJbl9pbmZpbml0ZV9hZA=="),
        fromB64("LmFkZ29vZ2xl"),
        fromB64("Ll9faXNib29zdFJldHVybkFk")
      ],
      adGuardMobile: [
        fromB64("YW1wLWF1dG8tYWRz"),
        fromB64("LmFtcF9hZA=="),
        'amp-embed[type="24smi"]',
        "#mgid_iframe1",
        fromB64("I2FkX2ludmlld19hcmVh")
      ],
      adGuardRussian: [
        fromB64("YVtocmVmXj0iaHR0cHM6Ly9hZC5sZXRtZWFkcy5jb20vIl0="),
        fromB64("LnJlY2xhbWE="),
        'div[id^="smi2adblock"]',
        fromB64("ZGl2W2lkXj0iQWRGb3hfYmFubmVyXyJd"),
        "#psyduckpockeball"
      ],
      adGuardSocial: [
        fromB64("YVtocmVmXj0iLy93d3cuc3R1bWJsZXVwb24uY29tL3N1Ym1pdD91cmw9Il0="),
        fromB64("YVtocmVmXj0iLy90ZWxlZ3JhbS5tZS9zaGFyZS91cmw/Il0="),
        ".etsy-tweet",
        "#inlineShare",
        ".popup-social"
      ],
      adGuardSpanishPortuguese: ["#barraPublicidade", "#Publicidade", "#publiEspecial", "#queTooltip", ".cnt-publi"],
      adGuardTrackingProtection: [
        "#qoo-counter",
        fromB64("YVtocmVmXj0iaHR0cDovL2NsaWNrLmhvdGxvZy5ydS8iXQ=="),
        fromB64("YVtocmVmXj0iaHR0cDovL2hpdGNvdW50ZXIucnUvdG9wL3N0YXQucGhwIl0="),
        fromB64("YVtocmVmXj0iaHR0cDovL3RvcC5tYWlsLnJ1L2p1bXAiXQ=="),
        "#top100counter"
      ],
      adGuardTurkish: [
        "#backkapat",
        fromB64("I3Jla2xhbWk="),
        fromB64("YVtocmVmXj0iaHR0cDovL2Fkc2Vydi5vbnRlay5jb20udHIvIl0="),
        fromB64("YVtocmVmXj0iaHR0cDovL2l6bGVuemkuY29tL2NhbXBhaWduLyJd"),
        fromB64("YVtocmVmXj0iaHR0cDovL3d3dy5pbnN0YWxsYWRzLm5ldC8iXQ==")
      ],
      bulgarian: [fromB64("dGQjZnJlZW5ldF90YWJsZV9hZHM="), "#ea_intext_div", ".lapni-pop-over", "#xenium_hot_offers"],
      easyList: [
        ".yb-floorad",
        fromB64("LndpZGdldF9wb19hZHNfd2lkZ2V0"),
        fromB64("LnRyYWZmaWNqdW5reS1hZA=="),
        ".textad_headline",
        fromB64("LnNwb25zb3JlZC10ZXh0LWxpbmtz")
      ],
      easyListChina: [
        fromB64("LmFwcGd1aWRlLXdyYXBbb25jbGljayo9ImJjZWJvcy5jb20iXQ=="),
        fromB64("LmZyb250cGFnZUFkdk0="),
        "#taotaole",
        "#aafoot.top_box",
        ".cfa_popup"
      ],
      easyListCookie: [
        ".ezmob-footer",
        ".cc-CookieWarning",
        "[data-cookie-number]",
        fromB64("LmF3LWNvb2tpZS1iYW5uZXI="),
        ".sygnal24-gdpr-modal-wrap"
      ],
      easyListCzechSlovak: [
        "#onlajny-stickers",
        fromB64("I3Jla2xhbW5pLWJveA=="),
        fromB64("LnJla2xhbWEtbWVnYWJvYXJk"),
        ".sklik",
        fromB64("W2lkXj0ic2tsaWtSZWtsYW1hIl0=")
      ],
      easyListDutch: [
        fromB64("I2FkdmVydGVudGll"),
        fromB64("I3ZpcEFkbWFya3RCYW5uZXJCbG9jaw=="),
        ".adstekst",
        fromB64("YVtocmVmXj0iaHR0cHM6Ly94bHR1YmUubmwvY2xpY2svIl0="),
        "#semilo-lrectangle"
      ],
      easyListGermany: [
        "#SSpotIMPopSlider",
        fromB64("LnNwb25zb3JsaW5rZ3J1ZW4="),
        fromB64("I3dlcmJ1bmdza3k="),
        fromB64("I3Jla2xhbWUtcmVjaHRzLW1pdHRl"),
        fromB64("YVtocmVmXj0iaHR0cHM6Ly9iZDc0Mi5jb20vIl0=")
      ],
      easyListItaly: [
        fromB64("LmJveF9hZHZfYW5udW5jaQ=="),
        ".sb-box-pubbliredazionale",
        fromB64("YVtocmVmXj0iaHR0cDovL2FmZmlsaWF6aW9uaWFkcy5zbmFpLml0LyJd"),
        fromB64("YVtocmVmXj0iaHR0cHM6Ly9hZHNlcnZlci5odG1sLml0LyJd"),
        fromB64("YVtocmVmXj0iaHR0cHM6Ly9hZmZpbGlhemlvbmlhZHMuc25haS5pdC8iXQ==")
      ],
      easyListLithuania: [
        fromB64("LnJla2xhbW9zX3RhcnBhcw=="),
        fromB64("LnJla2xhbW9zX251b3JvZG9z"),
        fromB64("aW1nW2FsdD0iUmVrbGFtaW5pcyBza3lkZWxpcyJd"),
        fromB64("aW1nW2FsdD0iRGVkaWt1b3RpLmx0IHNlcnZlcmlhaSJd"),
        fromB64("aW1nW2FsdD0iSG9zdGluZ2FzIFNlcnZlcmlhaS5sdCJd")
      ],
      estonian: [fromB64("QVtocmVmKj0iaHR0cDovL3BheTRyZXN1bHRzMjQuZXUiXQ==")],
      fanboyAnnoyances: ["#ac-lre-player", ".navigate-to-top", "#subscribe_popup", ".newsletter_holder", "#back-top"],
      fanboyAntiFacebook: [".util-bar-module-firefly-visible"],
      fanboyEnhancedTrackers: [
        ".open.pushModal",
        "#issuem-leaky-paywall-articles-zero-remaining-nag",
        "#sovrn_container",
        'div[class$="-hide"][zoompage-fontsize][style="display: block;"]',
        ".BlockNag__Card"
      ],
      fanboySocial: ["#FollowUs", "#meteored_share", "#social_follow", ".article-sharer", ".community__social-desc"],
      frellwitSwedish: [
        fromB64("YVtocmVmKj0iY2FzaW5vcHJvLnNlIl1bdGFyZ2V0PSJfYmxhbmsiXQ=="),
        fromB64("YVtocmVmKj0iZG9rdG9yLXNlLm9uZWxpbmsubWUiXQ=="),
        "article.category-samarbete",
        fromB64("ZGl2LmhvbGlkQWRz"),
        "ul.adsmodern"
      ],
      greekAdBlock: [
        fromB64("QVtocmVmKj0iYWRtYW4ub3RlbmV0LmdyL2NsaWNrPyJd"),
        fromB64("QVtocmVmKj0iaHR0cDovL2F4aWFiYW5uZXJzLmV4b2R1cy5nci8iXQ=="),
        fromB64("QVtocmVmKj0iaHR0cDovL2ludGVyYWN0aXZlLmZvcnRobmV0LmdyL2NsaWNrPyJd"),
        "DIV.agores300",
        "TABLE.advright"
      ],
      hungarian: [
        "#cemp_doboz",
        ".optimonk-iframe-container",
        fromB64("LmFkX19tYWlu"),
        fromB64("W2NsYXNzKj0iR29vZ2xlQWRzIl0="),
        "#hirdetesek_box"
      ],
      iDontCareAboutCookies: [
        '.alert-info[data-block-track*="CookieNotice"]',
        ".ModuleTemplateCookieIndicator",
        ".o--cookies--container",
        "#cookies-policy-sticky",
        "#stickyCookieBar"
      ],
      icelandicAbp: [fromB64("QVtocmVmXj0iL2ZyYW1ld29yay9yZXNvdXJjZXMvZm9ybXMvYWRzLmFzcHgiXQ==")],
      latvian: [
        fromB64("YVtocmVmPSJodHRwOi8vd3d3LnNhbGlkemluaS5sdi8iXVtzdHlsZT0iZGlzcGxheTogYmxvY2s7IHdpZHRoOiAxMjBweDsgaGVpZ2h0OiA0MHB4OyBvdmVyZmxvdzogaGlkZGVuOyBwb3NpdGlvbjogcmVsYXRpdmU7Il0="),
        fromB64("YVtocmVmPSJodHRwOi8vd3d3LnNhbGlkemluaS5sdi8iXVtzdHlsZT0iZGlzcGxheTogYmxvY2s7IHdpZHRoOiA4OHB4OyBoZWlnaHQ6IDMxcHg7IG92ZXJmbG93OiBoaWRkZW47IHBvc2l0aW9uOiByZWxhdGl2ZTsiXQ==")
      ],
      listKr: [
        fromB64("YVtocmVmKj0iLy9hZC5wbGFuYnBsdXMuY28ua3IvIl0="),
        fromB64("I2xpdmVyZUFkV3JhcHBlcg=="),
        fromB64("YVtocmVmKj0iLy9hZHYuaW1hZHJlcC5jby5rci8iXQ=="),
        fromB64("aW5zLmZhc3R2aWV3LWFk"),
        ".revenue_unit_item.dable"
      ],
      listeAr: [
        fromB64("LmdlbWluaUxCMUFk"),
        ".right-and-left-sponsers",
        fromB64("YVtocmVmKj0iLmFmbGFtLmluZm8iXQ=="),
        fromB64("YVtocmVmKj0iYm9vcmFxLm9yZyJd"),
        fromB64("YVtocmVmKj0iZHViaXp6bGUuY29tL2FyLz91dG1fc291cmNlPSJd")
      ],
      listeFr: [
        fromB64("YVtocmVmXj0iaHR0cDovL3Byb21vLnZhZG9yLmNvbS8iXQ=="),
        fromB64("I2FkY29udGFpbmVyX3JlY2hlcmNoZQ=="),
        fromB64("YVtocmVmKj0id2Vib3JhbWEuZnIvZmNnaS1iaW4vIl0="),
        ".site-pub-interstitiel",
        'div[id^="crt-"][data-criteo-id]'
      ],
      officialPolish: [
        "#ceneo-placeholder-ceneo-12",
        fromB64("W2hyZWZePSJodHRwczovL2FmZi5zZW5kaHViLnBsLyJd"),
        fromB64("YVtocmVmXj0iaHR0cDovL2Fkdm1hbmFnZXIudGVjaGZ1bi5wbC9yZWRpcmVjdC8iXQ=="),
        fromB64("YVtocmVmXj0iaHR0cDovL3d3dy50cml6ZXIucGwvP3V0bV9zb3VyY2UiXQ=="),
        fromB64("ZGl2I3NrYXBpZWNfYWQ=")
      ],
      ro: [
        fromB64("YVtocmVmXj0iLy9hZmZ0cmsuYWx0ZXgucm8vQ291bnRlci9DbGljayJd"),
        fromB64("YVtocmVmXj0iaHR0cHM6Ly9ibGFja2ZyaWRheXNhbGVzLnJvL3Ryay9zaG9wLyJd"),
        fromB64("YVtocmVmXj0iaHR0cHM6Ly9ldmVudC4ycGVyZm9ybWFudC5jb20vZXZlbnRzL2NsaWNrIl0="),
        fromB64("YVtocmVmXj0iaHR0cHM6Ly9sLnByb2ZpdHNoYXJlLnJvLyJd"),
        'a[href^="/url/"]'
      ],
      ruAd: [
        fromB64("YVtocmVmKj0iLy9mZWJyYXJlLnJ1LyJd"),
        fromB64("YVtocmVmKj0iLy91dGltZy5ydS8iXQ=="),
        fromB64("YVtocmVmKj0iOi8vY2hpa2lkaWtpLnJ1Il0="),
        "#pgeldiz",
        ".yandex-rtb-block"
      ],
      thaiAds: [
        "a[href*=macau-uta-popup]",
        fromB64("I2Fkcy1nb29nbGUtbWlkZGxlX3JlY3RhbmdsZS1ncm91cA=="),
        fromB64("LmFkczMwMHM="),
        ".bumq",
        ".img-kosana"
      ],
      webAnnoyancesUltralist: [
        "#mod-social-share-2",
        "#social-tools",
        fromB64("LmN0cGwtZnVsbGJhbm5lcg=="),
        ".zergnet-recommend",
        ".yt.btn-link.btn-md.btn"
      ]
    };
  }
  __name(getFilters, "getFilters");
  function getDomBlockers(_a2) {
    var _b2 = _a2 === void 0 ? {} : _a2, debug = _b2.debug;
    return __awaiter(this, void 0, void 0, function() {
      var filters, filterNames, allSelectors, blockedSelectors, activeBlockers;
      var _c2;
      return __generator(this, function(_d2) {
        switch (_d2.label) {
          case 0:
            if (!isApplicable()) {
              return [2, void 0];
            }
            filters = getFilters();
            filterNames = Object.keys(filters);
            allSelectors = (_c2 = []).concat.apply(_c2, filterNames.map(function(filterName) {
              return filters[filterName];
            }));
            return [4, getBlockedSelectors(allSelectors)];
          case 1:
            blockedSelectors = _d2.sent();
            if (debug) {
              printDebug(filters, blockedSelectors);
            }
            activeBlockers = filterNames.filter(function(filterName) {
              var selectors = filters[filterName];
              var blockedCount = countTruthy(selectors.map(function(selector) {
                return blockedSelectors[selector];
              }));
              return blockedCount > selectors.length * 0.6;
            });
            activeBlockers.sort();
            return [2, activeBlockers];
        }
      });
    });
  }
  __name(getDomBlockers, "getDomBlockers");
  function isApplicable() {
    return isWebKit() || isAndroid();
  }
  __name(isApplicable, "isApplicable");
  function getBlockedSelectors(selectors) {
    var _a2;
    return __awaiter(this, void 0, void 0, function() {
      var d, root, elements, blockedSelectors, i, element, holder, i;
      return __generator(this, function(_b2) {
        switch (_b2.label) {
          case 0:
            d = document;
            root = d.createElement("div");
            elements = new Array(selectors.length);
            blockedSelectors = {};
            forceShow(root);
            for (i = 0; i < selectors.length; ++i) {
              element = selectorToElement(selectors[i]);
              if (element.tagName === "DIALOG") {
                element.show();
              }
              holder = d.createElement("div");
              forceShow(holder);
              holder.appendChild(element);
              root.appendChild(holder);
              elements[i] = element;
            }
            _b2.label = 1;
          case 1:
            if (!!d.body) return [3, 3];
            return [4, wait(50)];
          case 2:
            _b2.sent();
            return [3, 1];
          case 3:
            d.body.appendChild(root);
            try {
              for (i = 0; i < selectors.length; ++i) {
                if (!elements[i].offsetParent) {
                  blockedSelectors[selectors[i]] = true;
                }
              }
            } finally {
              (_a2 = root.parentNode) === null || _a2 === void 0 ? void 0 : _a2.removeChild(root);
            }
            return [2, blockedSelectors];
        }
      });
    });
  }
  __name(getBlockedSelectors, "getBlockedSelectors");
  function forceShow(element) {
    element.style.setProperty("visibility", "hidden", "important");
    element.style.setProperty("display", "block", "important");
  }
  __name(forceShow, "forceShow");
  function printDebug(filters, blockedSelectors) {
    var message = "DOM blockers debug:\n```";
    for (var _i = 0, _a2 = Object.keys(filters); _i < _a2.length; _i++) {
      var filterName = _a2[_i];
      message += "\n".concat(filterName, ":");
      for (var _b2 = 0, _c2 = filters[filterName]; _b2 < _c2.length; _b2++) {
        var selector = _c2[_b2];
        message += "\n  ".concat(blockedSelectors[selector] ? "🚫" : "➡️", " ").concat(selector);
      }
    }
    console.log("".concat(message, "\n```"));
  }
  __name(printDebug, "printDebug");
  function getColorGamut() {
    for (var _i = 0, _a2 = ["rec2020", "p3", "srgb"]; _i < _a2.length; _i++) {
      var gamut = _a2[_i];
      if (matchMedia("(color-gamut: ".concat(gamut, ")")).matches) {
        return gamut;
      }
    }
    return void 0;
  }
  __name(getColorGamut, "getColorGamut");
  function areColorsInverted() {
    if (doesMatch$5("inverted")) {
      return true;
    }
    if (doesMatch$5("none")) {
      return false;
    }
    return void 0;
  }
  __name(areColorsInverted, "areColorsInverted");
  function doesMatch$5(value2) {
    return matchMedia("(inverted-colors: ".concat(value2, ")")).matches;
  }
  __name(doesMatch$5, "doesMatch$5");
  function areColorsForced() {
    if (doesMatch$4("active")) {
      return true;
    }
    if (doesMatch$4("none")) {
      return false;
    }
    return void 0;
  }
  __name(areColorsForced, "areColorsForced");
  function doesMatch$4(value2) {
    return matchMedia("(forced-colors: ".concat(value2, ")")).matches;
  }
  __name(doesMatch$4, "doesMatch$4");
  var maxValueToCheck = 100;
  function getMonochromeDepth() {
    if (!matchMedia("(min-monochrome: 0)").matches) {
      return void 0;
    }
    for (var i = 0; i <= maxValueToCheck; ++i) {
      if (matchMedia("(max-monochrome: ".concat(i, ")")).matches) {
        return i;
      }
    }
    throw new Error("Too high value");
  }
  __name(getMonochromeDepth, "getMonochromeDepth");
  function getContrastPreference() {
    if (doesMatch$3("no-preference")) {
      return 0;
    }
    if (doesMatch$3("high") || doesMatch$3("more")) {
      return 1;
    }
    if (doesMatch$3("low") || doesMatch$3("less")) {
      return -1;
    }
    if (doesMatch$3("forced")) {
      return 10;
    }
    return void 0;
  }
  __name(getContrastPreference, "getContrastPreference");
  function doesMatch$3(value2) {
    return matchMedia("(prefers-contrast: ".concat(value2, ")")).matches;
  }
  __name(doesMatch$3, "doesMatch$3");
  function isMotionReduced() {
    if (doesMatch$2("reduce")) {
      return true;
    }
    if (doesMatch$2("no-preference")) {
      return false;
    }
    return void 0;
  }
  __name(isMotionReduced, "isMotionReduced");
  function doesMatch$2(value2) {
    return matchMedia("(prefers-reduced-motion: ".concat(value2, ")")).matches;
  }
  __name(doesMatch$2, "doesMatch$2");
  function isTransparencyReduced() {
    if (doesMatch$1("reduce")) {
      return true;
    }
    if (doesMatch$1("no-preference")) {
      return false;
    }
    return void 0;
  }
  __name(isTransparencyReduced, "isTransparencyReduced");
  function doesMatch$1(value2) {
    return matchMedia("(prefers-reduced-transparency: ".concat(value2, ")")).matches;
  }
  __name(doesMatch$1, "doesMatch$1");
  function isHDR() {
    if (doesMatch("high")) {
      return true;
    }
    if (doesMatch("standard")) {
      return false;
    }
    return void 0;
  }
  __name(isHDR, "isHDR");
  function doesMatch(value2) {
    return matchMedia("(dynamic-range: ".concat(value2, ")")).matches;
  }
  __name(doesMatch, "doesMatch");
  var M = Math;
  var fallbackFn = /* @__PURE__ */ __name(function() {
    return 0;
  }, "fallbackFn");
  function getMathFingerprint() {
    var acos = M.acos || fallbackFn;
    var acosh = M.acosh || fallbackFn;
    var asin = M.asin || fallbackFn;
    var asinh = M.asinh || fallbackFn;
    var atanh = M.atanh || fallbackFn;
    var atan = M.atan || fallbackFn;
    var sin = M.sin || fallbackFn;
    var sinh = M.sinh || fallbackFn;
    var cos = M.cos || fallbackFn;
    var cosh = M.cosh || fallbackFn;
    var tan = M.tan || fallbackFn;
    var tanh = M.tanh || fallbackFn;
    var exp = M.exp || fallbackFn;
    var expm1 = M.expm1 || fallbackFn;
    var log1p = M.log1p || fallbackFn;
    var powPI = /* @__PURE__ */ __name(function(value2) {
      return M.pow(M.PI, value2);
    }, "powPI");
    var acoshPf = /* @__PURE__ */ __name(function(value2) {
      return M.log(value2 + M.sqrt(value2 * value2 - 1));
    }, "acoshPf");
    var asinhPf = /* @__PURE__ */ __name(function(value2) {
      return M.log(value2 + M.sqrt(value2 * value2 + 1));
    }, "asinhPf");
    var atanhPf = /* @__PURE__ */ __name(function(value2) {
      return M.log((1 + value2) / (1 - value2)) / 2;
    }, "atanhPf");
    var sinhPf = /* @__PURE__ */ __name(function(value2) {
      return M.exp(value2) - 1 / M.exp(value2) / 2;
    }, "sinhPf");
    var coshPf = /* @__PURE__ */ __name(function(value2) {
      return (M.exp(value2) + 1 / M.exp(value2)) / 2;
    }, "coshPf");
    var expm1Pf = /* @__PURE__ */ __name(function(value2) {
      return M.exp(value2) - 1;
    }, "expm1Pf");
    var tanhPf = /* @__PURE__ */ __name(function(value2) {
      return (M.exp(2 * value2) - 1) / (M.exp(2 * value2) + 1);
    }, "tanhPf");
    var log1pPf = /* @__PURE__ */ __name(function(value2) {
      return M.log(1 + value2);
    }, "log1pPf");
    return {
      acos: acos(0.12312423423423424),
      acosh: acosh(1e308),
      acoshPf: acoshPf(1e154),
      asin: asin(0.12312423423423424),
      asinh: asinh(1),
      asinhPf: asinhPf(1),
      atanh: atanh(0.5),
      atanhPf: atanhPf(0.5),
      atan: atan(0.5),
      sin: sin(-1e300),
      sinh: sinh(1),
      sinhPf: sinhPf(1),
      cos: cos(10.000000000123),
      cosh: cosh(1),
      coshPf: coshPf(1),
      tan: tan(-1e300),
      tanh: tanh(1),
      tanhPf: tanhPf(1),
      exp: exp(1),
      expm1: expm1(1),
      expm1Pf: expm1Pf(1),
      log1p: log1p(10),
      log1pPf: log1pPf(10),
      powPI: powPI(-100)
    };
  }
  __name(getMathFingerprint, "getMathFingerprint");
  var defaultText = "mmMwWLliI0fiflO&1";
  var presets = {
    /**
     * The default font. User can change it in desktop Chrome, desktop Firefox, IE 11,
     * Android Chrome (but only when the size is ≥ than the default) and Android Firefox.
     */
    default: [],
    /** OS font on macOS. User can change its size and weight. Applies after Safari restart. */
    apple: [{ font: "-apple-system-body" }],
    /** User can change it in desktop Chrome and desktop Firefox. */
    serif: [{ fontFamily: "serif" }],
    /** User can change it in desktop Chrome and desktop Firefox. */
    sans: [{ fontFamily: "sans-serif" }],
    /** User can change it in desktop Chrome and desktop Firefox. */
    mono: [{ fontFamily: "monospace" }],
    /**
     * Check the smallest allowed font size. User can change it in desktop Chrome, desktop Firefox and desktop Safari.
     * The height can be 0 in Chrome on a retina display.
     */
    min: [{ fontSize: "1px" }],
    /** Tells one OS from another in desktop Chrome. */
    system: [{ fontFamily: "system-ui" }]
  };
  function getFontPreferences() {
    return withNaturalFonts(function(document2, container) {
      var elements = {};
      var sizes = {};
      for (var _i = 0, _a2 = Object.keys(presets); _i < _a2.length; _i++) {
        var key = _a2[_i];
        var _b2 = presets[key], _c2 = _b2[0], style = _c2 === void 0 ? {} : _c2, _d2 = _b2[1], text = _d2 === void 0 ? defaultText : _d2;
        var element = document2.createElement("span");
        element.textContent = text;
        element.style.whiteSpace = "nowrap";
        for (var _e2 = 0, _f = Object.keys(style); _e2 < _f.length; _e2++) {
          var name_1 = _f[_e2];
          var value2 = style[name_1];
          if (value2 !== void 0) {
            element.style[name_1] = value2;
          }
        }
        elements[key] = element;
        container.append(document2.createElement("br"), element);
      }
      for (var _g = 0, _h = Object.keys(presets); _g < _h.length; _g++) {
        var key = _h[_g];
        sizes[key] = elements[key].getBoundingClientRect().width;
      }
      return sizes;
    });
  }
  __name(getFontPreferences, "getFontPreferences");
  function withNaturalFonts(action, containerWidthPx) {
    if (containerWidthPx === void 0) {
      containerWidthPx = 4e3;
    }
    return withIframe(function(_, iframeWindow) {
      var iframeDocument = iframeWindow.document;
      var iframeBody = iframeDocument.body;
      var bodyStyle = iframeBody.style;
      bodyStyle.width = "".concat(containerWidthPx, "px");
      bodyStyle.webkitTextSizeAdjust = bodyStyle.textSizeAdjust = "none";
      if (isChromium()) {
        iframeBody.style.zoom = "".concat(1 / iframeWindow.devicePixelRatio);
      } else if (isWebKit()) {
        iframeBody.style.zoom = "reset";
      }
      var linesOfText = iframeDocument.createElement("div");
      linesOfText.textContent = __spreadArray$1([], Array(containerWidthPx / 20 << 0), true).map(function() {
        return "word";
      }).join(" ");
      iframeBody.appendChild(linesOfText);
      return action(iframeDocument, iframeBody);
    }, '<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1">');
  }
  __name(withNaturalFonts, "withNaturalFonts");
  function isPdfViewerEnabled() {
    return navigator.pdfViewerEnabled;
  }
  __name(isPdfViewerEnabled, "isPdfViewerEnabled");
  function getArchitecture() {
    var f = new Float32Array(1);
    var u8 = new Uint8Array(f.buffer);
    f[0] = Infinity;
    f[0] = f[0] - f[0];
    return u8[3];
  }
  __name(getArchitecture, "getArchitecture");
  function getApplePayState() {
    var ApplePaySession = window.ApplePaySession;
    if (typeof (ApplePaySession === null || ApplePaySession === void 0 ? void 0 : ApplePaySession.canMakePayments) !== "function") {
      return -1;
    }
    if (willPrintConsoleError()) {
      return -3;
    }
    try {
      return ApplePaySession.canMakePayments() ? 1 : 0;
    } catch (error) {
      return getStateFromError(error);
    }
  }
  __name(getApplePayState, "getApplePayState");
  var willPrintConsoleError = isAnyParentCrossOrigin;
  function getStateFromError(error) {
    if (error instanceof Error && error.name === "InvalidAccessError" && /\bfrom\b.*\binsecure\b/i.test(error.message)) {
      return -2;
    }
    throw error;
  }
  __name(getStateFromError, "getStateFromError");
  function getPrivateClickMeasurement() {
    var _a2;
    var link = document.createElement("a");
    var sourceId = (_a2 = link.attributionSourceId) !== null && _a2 !== void 0 ? _a2 : link.attributionsourceid;
    return sourceId === void 0 ? void 0 : String(sourceId);
  }
  __name(getPrivateClickMeasurement, "getPrivateClickMeasurement");
  var STATUS_NO_GL_CONTEXT = -1;
  var STATUS_GET_PARAMETER_NOT_A_FUNCTION = -2;
  var validContextParameters = /* @__PURE__ */ new Set([
    10752,
    2849,
    2884,
    2885,
    2886,
    2928,
    2929,
    2930,
    2931,
    2932,
    2960,
    2961,
    2962,
    2963,
    2964,
    2965,
    2966,
    2967,
    2968,
    2978,
    3024,
    3042,
    3088,
    3089,
    3106,
    3107,
    32773,
    32777,
    32777,
    32823,
    32824,
    32936,
    32937,
    32938,
    32939,
    32968,
    32969,
    32970,
    32971,
    3317,
    33170,
    3333,
    3379,
    3386,
    33901,
    33902,
    34016,
    34024,
    34076,
    3408,
    3410,
    3411,
    3412,
    3413,
    3414,
    3415,
    34467,
    34816,
    34817,
    34818,
    34819,
    34877,
    34921,
    34930,
    35660,
    35661,
    35724,
    35738,
    35739,
    36003,
    36004,
    36005,
    36347,
    36348,
    36349,
    37440,
    37441,
    37443,
    7936,
    7937,
    7938
    // SAMPLE_ALPHA_TO_COVERAGE (32926) and SAMPLE_COVERAGE (32928) are excluded because they trigger a console warning
    // in IE, Chrome ≤ 59 and Safari ≤ 13 and give no entropy.
  ]);
  var validExtensionParams = /* @__PURE__ */ new Set([
    34047,
    35723,
    36063,
    34852,
    34853,
    34854,
    34229,
    36392,
    36795,
    38449
    // MAX_VIEWS_OVR
  ]);
  var shaderTypes = ["FRAGMENT_SHADER", "VERTEX_SHADER"];
  var precisionTypes = ["LOW_FLOAT", "MEDIUM_FLOAT", "HIGH_FLOAT", "LOW_INT", "MEDIUM_INT", "HIGH_INT"];
  var rendererInfoExtensionName = "WEBGL_debug_renderer_info";
  var polygonModeExtensionName = "WEBGL_polygon_mode";
  function getWebGlBasics(_a2) {
    var _b2, _c2, _d2, _e2, _f, _g;
    var cache2 = _a2.cache;
    var gl = getWebGLContext(cache2);
    if (!gl) {
      return STATUS_NO_GL_CONTEXT;
    }
    if (!isValidParameterGetter(gl)) {
      return STATUS_GET_PARAMETER_NOT_A_FUNCTION;
    }
    var debugExtension = shouldAvoidDebugRendererInfo() ? null : gl.getExtension(rendererInfoExtensionName);
    return {
      version: ((_b2 = gl.getParameter(gl.VERSION)) === null || _b2 === void 0 ? void 0 : _b2.toString()) || "",
      vendor: ((_c2 = gl.getParameter(gl.VENDOR)) === null || _c2 === void 0 ? void 0 : _c2.toString()) || "",
      vendorUnmasked: debugExtension ? (_d2 = gl.getParameter(debugExtension.UNMASKED_VENDOR_WEBGL)) === null || _d2 === void 0 ? void 0 : _d2.toString() : "",
      renderer: ((_e2 = gl.getParameter(gl.RENDERER)) === null || _e2 === void 0 ? void 0 : _e2.toString()) || "",
      rendererUnmasked: debugExtension ? (_f = gl.getParameter(debugExtension.UNMASKED_RENDERER_WEBGL)) === null || _f === void 0 ? void 0 : _f.toString() : "",
      shadingLanguageVersion: ((_g = gl.getParameter(gl.SHADING_LANGUAGE_VERSION)) === null || _g === void 0 ? void 0 : _g.toString()) || ""
    };
  }
  __name(getWebGlBasics, "getWebGlBasics");
  function getWebGlExtensions(_a2) {
    var cache2 = _a2.cache;
    var gl = getWebGLContext(cache2);
    if (!gl) {
      return STATUS_NO_GL_CONTEXT;
    }
    if (!isValidParameterGetter(gl)) {
      return STATUS_GET_PARAMETER_NOT_A_FUNCTION;
    }
    var extensions = gl.getSupportedExtensions();
    var contextAttributes = gl.getContextAttributes();
    var unsupportedExtensions = [];
    var attributes = [];
    var parameters = [];
    var extensionParameters = [];
    var shaderPrecisions = [];
    if (contextAttributes) {
      for (var _i = 0, _b2 = Object.keys(contextAttributes); _i < _b2.length; _i++) {
        var attributeName = _b2[_i];
        attributes.push("".concat(attributeName, "=").concat(contextAttributes[attributeName]));
      }
    }
    var constants = getConstantsFromPrototype(gl);
    for (var _c2 = 0, constants_1 = constants; _c2 < constants_1.length; _c2++) {
      var constant = constants_1[_c2];
      var code = gl[constant];
      parameters.push("".concat(constant, "=").concat(code).concat(validContextParameters.has(code) ? "=".concat(gl.getParameter(code)) : ""));
    }
    if (extensions) {
      for (var _d2 = 0, extensions_1 = extensions; _d2 < extensions_1.length; _d2++) {
        var name_1 = extensions_1[_d2];
        if (name_1 === rendererInfoExtensionName && shouldAvoidDebugRendererInfo() || name_1 === polygonModeExtensionName && shouldAvoidPolygonModeExtensions()) {
          continue;
        }
        var extension = gl.getExtension(name_1);
        if (!extension) {
          unsupportedExtensions.push(name_1);
          continue;
        }
        for (var _e2 = 0, _f = getConstantsFromPrototype(extension); _e2 < _f.length; _e2++) {
          var constant = _f[_e2];
          var code = extension[constant];
          extensionParameters.push("".concat(constant, "=").concat(code).concat(validExtensionParams.has(code) ? "=".concat(gl.getParameter(code)) : ""));
        }
      }
    }
    for (var _g = 0, shaderTypes_1 = shaderTypes; _g < shaderTypes_1.length; _g++) {
      var shaderType = shaderTypes_1[_g];
      for (var _h = 0, precisionTypes_1 = precisionTypes; _h < precisionTypes_1.length; _h++) {
        var precisionType = precisionTypes_1[_h];
        var shaderPrecision = getShaderPrecision(gl, shaderType, precisionType);
        shaderPrecisions.push("".concat(shaderType, ".").concat(precisionType, "=").concat(shaderPrecision.join(",")));
      }
    }
    extensionParameters.sort();
    parameters.sort();
    return {
      contextAttributes: attributes,
      parameters,
      shaderPrecisions,
      extensions,
      extensionParameters,
      unsupportedExtensions
    };
  }
  __name(getWebGlExtensions, "getWebGlExtensions");
  function getWebGLContext(cache2) {
    if (cache2.webgl) {
      return cache2.webgl.context;
    }
    var canvas = document.createElement("canvas");
    var context;
    canvas.addEventListener("webglCreateContextError", function() {
      return context = void 0;
    });
    for (var _i = 0, _a2 = ["webgl", "experimental-webgl"]; _i < _a2.length; _i++) {
      var type = _a2[_i];
      try {
        context = canvas.getContext(type);
      } catch (_b2) {
      }
      if (context) {
        break;
      }
    }
    cache2.webgl = { context };
    return context;
  }
  __name(getWebGLContext, "getWebGLContext");
  function getShaderPrecision(gl, shaderType, precisionType) {
    var shaderPrecision = gl.getShaderPrecisionFormat(gl[shaderType], gl[precisionType]);
    return shaderPrecision ? [shaderPrecision.rangeMin, shaderPrecision.rangeMax, shaderPrecision.precision] : [];
  }
  __name(getShaderPrecision, "getShaderPrecision");
  function getConstantsFromPrototype(obj) {
    var keys = Object.keys(obj.__proto__);
    return keys.filter(isConstantLike);
  }
  __name(getConstantsFromPrototype, "getConstantsFromPrototype");
  function isConstantLike(key) {
    return typeof key === "string" && !key.match(/[^A-Z0-9_x]/);
  }
  __name(isConstantLike, "isConstantLike");
  function shouldAvoidDebugRendererInfo() {
    return isGecko();
  }
  __name(shouldAvoidDebugRendererInfo, "shouldAvoidDebugRendererInfo");
  function shouldAvoidPolygonModeExtensions() {
    return isChromium() || isWebKit();
  }
  __name(shouldAvoidPolygonModeExtensions, "shouldAvoidPolygonModeExtensions");
  function isValidParameterGetter(gl) {
    return typeof gl.getParameter === "function";
  }
  __name(isValidParameterGetter, "isValidParameterGetter");
  function getAudioContextBaseLatency() {
    var _a2;
    var isAllowedPlatform = isAndroid() || isWebKit();
    if (!isAllowedPlatform) {
      return -2;
    }
    if (!window.AudioContext) {
      return -1;
    }
    return (_a2 = new AudioContext().baseLatency) !== null && _a2 !== void 0 ? _a2 : -1;
  }
  __name(getAudioContextBaseLatency, "getAudioContextBaseLatency");
  function getDateTimeLocale() {
    if (!window.Intl) {
      return -1;
    }
    var DateTimeFormat = window.Intl.DateTimeFormat;
    if (!DateTimeFormat) {
      return -2;
    }
    var locale = DateTimeFormat().resolvedOptions().locale;
    if (!locale && locale !== "") {
      return -3;
    }
    return locale;
  }
  __name(getDateTimeLocale, "getDateTimeLocale");
  var sources = {
    // READ FIRST:
    // See https://github.com/fingerprintjs/fingerprintjs/blob/master/contributing.md#how-to-add-an-entropy-source
    // to learn how entropy source works and how to make your own.
    // The sources run in this exact order.
    // The asynchronous sources are at the start to run in parallel with other sources.
    fonts: getFonts,
    domBlockers: getDomBlockers,
    fontPreferences: getFontPreferences,
    audio: getAudioFingerprint,
    screenFrame: getScreenFrame,
    canvas: getCanvasFingerprint,
    osCpu: getOsCpu,
    languages: getLanguages,
    colorDepth: getColorDepth,
    deviceMemory: getDeviceMemory,
    screenResolution: getScreenResolution,
    hardwareConcurrency: getHardwareConcurrency,
    timezone: getTimezone,
    sessionStorage: getSessionStorage,
    localStorage: getLocalStorage,
    indexedDB: getIndexedDB,
    openDatabase: getOpenDatabase,
    cpuClass: getCpuClass,
    platform: getPlatform,
    plugins: getPlugins,
    touchSupport: getTouchSupport,
    vendor: getVendor,
    vendorFlavors: getVendorFlavors,
    cookiesEnabled: areCookiesEnabled,
    colorGamut: getColorGamut,
    invertedColors: areColorsInverted,
    forcedColors: areColorsForced,
    monochrome: getMonochromeDepth,
    contrast: getContrastPreference,
    reducedMotion: isMotionReduced,
    reducedTransparency: isTransparencyReduced,
    hdr: isHDR,
    math: getMathFingerprint,
    pdfViewerEnabled: isPdfViewerEnabled,
    architecture: getArchitecture,
    applePay: getApplePayState,
    privateClickMeasurement: getPrivateClickMeasurement,
    audioBaseLatency: getAudioContextBaseLatency,
    dateTimeLocale: getDateTimeLocale,
    // Some sources can affect other sources (e.g. WebGL can affect canvas), so it's important to run these sources
    // after other sources.
    webGlBasics: getWebGlBasics,
    webGlExtensions: getWebGlExtensions
  };
  function loadBuiltinSources(options) {
    return loadSources(sources, options, []);
  }
  __name(loadBuiltinSources, "loadBuiltinSources");
  var commentTemplate = "$ if upgrade to Pro: https://fpjs.dev/pro";
  function getConfidence(components) {
    var openConfidenceScore = getOpenConfidenceScore(components);
    var proConfidenceScore = deriveProConfidenceScore(openConfidenceScore);
    return { score: openConfidenceScore, comment: commentTemplate.replace(/\$/g, "".concat(proConfidenceScore)) };
  }
  __name(getConfidence, "getConfidence");
  function getOpenConfidenceScore(components) {
    if (isAndroid()) {
      return 0.4;
    }
    if (isWebKit()) {
      return isDesktopWebKit() && !(isWebKit616OrNewer() && isSafariWebKit()) ? 0.5 : 0.3;
    }
    var platform2 = "value" in components.platform ? components.platform.value : "";
    if (/^Win/.test(platform2)) {
      return 0.6;
    }
    if (/^Mac/.test(platform2)) {
      return 0.5;
    }
    return 0.7;
  }
  __name(getOpenConfidenceScore, "getOpenConfidenceScore");
  function deriveProConfidenceScore(openConfidenceScore) {
    return round(0.99 + 0.01 * openConfidenceScore, 1e-4);
  }
  __name(deriveProConfidenceScore, "deriveProConfidenceScore");
  function componentsToCanonicalString(components) {
    var result = "";
    for (var _i = 0, _a2 = Object.keys(components).sort(); _i < _a2.length; _i++) {
      var componentKey = _a2[_i];
      var component = components[componentKey];
      var value2 = "error" in component ? "error" : JSON.stringify(component.value);
      result += "".concat(result ? "|" : "").concat(componentKey.replace(/([:|\\])/g, "\\$1"), ":").concat(value2);
    }
    return result;
  }
  __name(componentsToCanonicalString, "componentsToCanonicalString");
  function componentsToDebugString(components) {
    return JSON.stringify(components, function(_key, value2) {
      if (value2 instanceof Error) {
        return errorToObject(value2);
      }
      return value2;
    }, 2);
  }
  __name(componentsToDebugString, "componentsToDebugString");
  function hashComponents(components) {
    return x64hash128(componentsToCanonicalString(components));
  }
  __name(hashComponents, "hashComponents");
  function makeLazyGetResult(components) {
    var visitorIdCache;
    var confidence = getConfidence(components);
    return {
      get visitorId() {
        if (visitorIdCache === void 0) {
          visitorIdCache = hashComponents(this.components);
        }
        return visitorIdCache;
      },
      set visitorId(visitorId) {
        visitorIdCache = visitorId;
      },
      confidence,
      components,
      version
    };
  }
  __name(makeLazyGetResult, "makeLazyGetResult");
  function prepareForSources(delayFallback) {
    if (delayFallback === void 0) {
      delayFallback = 50;
    }
    return requestIdleCallbackIfAvailable(delayFallback, delayFallback * 2);
  }
  __name(prepareForSources, "prepareForSources");
  function makeAgent(getComponents, debug) {
    var creationTime = Date.now();
    return {
      get: /* @__PURE__ */ __name(function(options) {
        return __awaiter(this, void 0, void 0, function() {
          var startTime, components, result;
          return __generator(this, function(_a2) {
            switch (_a2.label) {
              case 0:
                startTime = Date.now();
                return [4, getComponents()];
              case 1:
                components = _a2.sent();
                result = makeLazyGetResult(components);
                if (debug || (options === null || options === void 0 ? void 0 : options.debug)) {
                  console.log("Copy the text below to get the debug data:\n\n```\nversion: ".concat(result.version, "\nuserAgent: ").concat(navigator.userAgent, "\ntimeBetweenLoadAndGet: ").concat(startTime - creationTime, "\nvisitorId: ").concat(result.visitorId, "\ncomponents: ").concat(componentsToDebugString(components), "\n```"));
                }
                return [2, result];
            }
          });
        });
      }, "get")
    };
  }
  __name(makeAgent, "makeAgent");
  function monitor() {
    if (window.__fpjs_d_m || Math.random() >= 1e-3) {
      return;
    }
    try {
      var request = new XMLHttpRequest();
      request.open("get", "https://m1.openfpcdn.io/fingerprintjs/v".concat(version, "/npm-monitoring"), true);
      request.send();
    } catch (error) {
      console.error(error);
    }
  }
  __name(monitor, "monitor");
  function load(options) {
    var _a2;
    if (options === void 0) {
      options = {};
    }
    return __awaiter(this, void 0, void 0, function() {
      var delayFallback, debug, getComponents;
      return __generator(this, function(_b2) {
        switch (_b2.label) {
          case 0:
            if ((_a2 = options.monitoring) !== null && _a2 !== void 0 ? _a2 : true) {
              monitor();
            }
            delayFallback = options.delayFallback, debug = options.debug;
            return [4, prepareForSources(delayFallback)];
          case 1:
            _b2.sent();
            getComponents = loadBuiltinSources({ cache: {}, debug });
            return [2, makeAgent(getComponents, debug)];
        }
      });
    });
  }
  __name(load, "load");
  const DEFAULT_PARTY_URL = "https://party.dhoniaridho.com";
  const fp$ = from(load({})).pipe(
    switchMap(async (fp) => {
      return (await fp.get()).visitorId;
    })
  );
  Object.defineProperty(window, "onbeforeunload", {
    get: /* @__PURE__ */ __name(() => null, "get"),
    set: /* @__PURE__ */ __name(() => {
    }, "set"),
    configurable: true
  });
  function removeListParameter() {
    const url2 = new URL(window.location.href);
    if (!url2.searchParams.has("list")) return;
    url2.searchParams.delete("list");
    const cleanUrl = `${url2.pathname}${url2.search}${url2.hash}`;
    const reloadKey = `music-party-list-cleanup:${url2.pathname}:${url2.searchParams.get("v") || "no-video"}`;
    try {
      if (window.sessionStorage.getItem(reloadKey)) {
        window.history.replaceState(window.history.state, "", cleanUrl);
        return;
      }
      window.sessionStorage.setItem(reloadKey, "1");
      window.location.replace(cleanUrl);
    } catch {
      window.history.replaceState(window.history.state, "", cleanUrl);
    }
  }
  __name(removeListParameter, "removeListParameter");
  function removeAutogeneratedRadioList() {
    const listId = new URL(window.location.href).searchParams.get("list");
    if (listId == null ? void 0 : listId.startsWith("RDAMVM")) removeListParameter();
  }
  __name(removeAutogeneratedRadioList, "removeAutogeneratedRadioList");
  removeAutogeneratedRadioList();
  window.addEventListener("yt-navigate-finish", removeAutogeneratedRadioList);
  window.addEventListener("popstate", removeAutogeneratedRadioList);
  function getPlayerVideoData() {
    var _a2;
    const player = document.querySelector("#movie_player");
    try {
      return ((_a2 = player == null ? void 0 : player.getVideoData) == null ? void 0 : _a2.call(player)) ?? null;
    } catch {
      return null;
    }
  }
  __name(getPlayerVideoData, "getPlayerVideoData");
  function getVideoElement() {
    return document.querySelector(
      "#movie_player > div.html5-video-container > video"
    );
  }
  __name(getVideoElement, "getVideoElement");
  function getVideoPlaybackState(video) {
    if (!video || video.ended) return "standby";
    if (!video.paused) return "playing";
    if (video.currentSrc || video.src || video.readyState > 0 || getVideoId()) {
      return "paused";
    }
    return "standby";
  }
  __name(getVideoPlaybackState, "getVideoPlaybackState");
  function getVideoId() {
    var _a2, _b2;
    const playerVideoId = (_a2 = getPlayerVideoData()) == null ? void 0 : _a2.video_id;
    if (typeof playerVideoId === "string" && playerVideoId) return playerVideoId;
    const u = (_b2 = document.querySelector('[class="ytp-title-link yt-uix-sessionlink"]')) == null ? void 0 : _b2.getAttribute("href");
    if (!u) return null;
    return new URL(u, window.location.origin).searchParams.get("v");
  }
  __name(getVideoId, "getVideoId");
  function getPlaybackState() {
    var _a2, _b2;
    const el = getVideoElement();
    const song = ((_b2 = (_a2 = document.querySelector(".title.ytmusic-player-bar")) == null ? void 0 : _a2.textContent) == null ? void 0 : _b2.trim()) || "Unknown title";
    const state = getVideoPlaybackState(el);
    if (state !== "standby") {
      return {
        song,
        artist: getCurrentArtist(),
        state,
        el
      };
    }
    return {
      el,
      song,
      state: "standby",
      artist: ""
    };
  }
  __name(getPlaybackState, "getPlaybackState");
  function getNowPlaying() {
    var _a2, _b2;
    const video = getVideoElement();
    if (video == null ? void 0 : video.ended) return null;
    const playerVideoData = getPlayerVideoData();
    const videoId = getVideoId() || (typeof (playerVideoData == null ? void 0 : playerVideoData.video_id) === "string" ? playerVideoData.video_id : null) || new URL(window.location.href).searchParams.get("v");
    const title = ((_b2 = (_a2 = document.querySelector(".title.ytmusic-player-bar")) == null ? void 0 : _a2.textContent) == null ? void 0 : _b2.trim()) || (typeof (playerVideoData == null ? void 0 : playerVideoData.title) === "string" ? playerVideoData.title.trim() : "");
    if (!title) return null;
    return {
      videoId,
      title: title || "Unknown title",
      artist: getCurrentArtist(),
      artwork: videoId ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg` : null
    };
  }
  __name(getNowPlaying, "getNowPlaying");
  function navigateToQueueItem(queue) {
    const currentUrl = new URL(window.location.href);
    if (currentUrl.searchParams.get("v") === queue.url) return false;
    const targetUrl = new URL("/watch", window.location.origin);
    targetUrl.searchParams.set("v", queue.url);
    targetUrl.searchParams.set("qid", queue.id);
    window.location.assign(targetUrl.toString());
    return true;
  }
  __name(navigateToQueueItem, "navigateToQueueItem");
  function getCurrentArtist() {
    var _a2, _b2, _c2;
    const byline = document.querySelector(
      "ytmusic-player-bar yt-formatted-string.byline"
    );
    const bylineText = (byline == null ? void 0 : byline.getAttribute("title")) || (byline == null ? void 0 : byline.textContent) || "";
    const artistName = (_a2 = bylineText.split("•")[0]) == null ? void 0 : _a2.trim();
    if (artistName) return artistName;
    return ((_c2 = (_b2 = byline == null ? void 0 : byline.querySelector("a")) == null ? void 0 : _b2.textContent) == null ? void 0 : _c2.trim()) || "Unknown artist";
  }
  __name(getCurrentArtist, "getCurrentArtist");
  function play(queue) {
    const playback = getPlaybackState();
    if ((queue == null ? void 0 : queue.url) && playback.state === "standby") {
      navigateToQueueItem(queue);
      return;
    }
    if (playback.state === "paused") {
      void playback.el.play().then(
        () => window.setTimeout(removeListParameter, 250),
        removeListParameter
      );
      return;
    }
    removeListParameter();
  }
  __name(play, "play");
  function pause() {
    const VIDEO_SELECTOR = "#movie_player > div.html5-video-container > video";
    const vid = document.querySelector(VIDEO_SELECTOR);
    if (vid) {
      vid.pause();
    }
  }
  __name(pause, "pause");
  function volumeUp() {
    const event = new KeyboardEvent("keydown", { key: "=" });
    document.dispatchEvent(event);
    const video = document.querySelector(
      "#movie_player > div.html5-video-container > video"
    );
    if (video) {
      return video.volume * 100;
    }
    return 0;
  }
  __name(volumeUp, "volumeUp");
  function volumeDown() {
    const event = new KeyboardEvent("keydown", { key: "-" });
    document.dispatchEvent(event);
    const video = document.querySelector(
      "#movie_player > div.html5-video-container > video"
    );
    if (video) {
      return video.volume * 100;
    }
    return 0;
  }
  __name(volumeDown, "volumeDown");
  function mute() {
    const VIDEO_SELECTOR = ".volume";
    const el = document.querySelector(VIDEO_SELECTOR);
    if (el) {
      el.click();
    }
  }
  __name(mute, "mute");
  function lyrics() {
    const tab = document.querySelector(
      "#tabsContent > tp-yt-paper-tab:nth-child(3)"
    );
    if (!tab) return Promise.resolve(null);
    tab.click();
    return new Promise((resolve) => {
      setTimeout(() => {
        var _a2, _b2;
        const text = (_b2 = (_a2 = document.querySelector(
          "#contents > ytmusic-description-shelf-renderer > div > yt-formatted-string.non-expandable.description.style-scope.ytmusic-description-shelf-renderer"
        )) == null ? void 0 : _a2.textContent) == null ? void 0 : _b2.trim();
        tab.click();
        resolve(text || null);
      }, 1e3);
    });
  }
  __name(lyrics, "lyrics");
  function next(queue) {
    const NEXT_SELECTOR = ".next-button";
    const el = document.querySelector(NEXT_SELECTOR);
    if (el) {
      el.click();
    }
  }
  __name(next, "next");
  function prev() {
    const PREV_SELECTOR = ".previous-button";
    const el = document.querySelector(PREV_SELECTOR);
    if (el) {
      el.click();
    }
  }
  __name(prev, "prev");
  function resume() {
    const VIDEO_SELECTOR = "play-pause-button";
    const el = document.querySelector(VIDEO_SELECTOR);
    if (el) {
      el.click();
    }
  }
  __name(resume, "resume");
  function getConfig() {
    const config2 = {
      partyUrl: localStorage.getItem("partyUrl"),
      roomId: localStorage.getItem("roomId")
    };
    return config2;
  }
  __name(getConfig, "getConfig");
  function createButton({
    onClick,
    children,
    join = true
  }) {
    const btn = document.createElement("tp-yt-paper-item");
    btn.setAttribute("role", "link");
    btn.classList.add("style-scope", "ytmusic-guide-entry-renderer");
    btn.setAttribute("style-target", "host");
    btn.setAttribute("tabindex", "0");
    btn.setAttribute("aria-disabled", "false");
    btn.setAttribute("aria-current", "false");
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("fill", "none");
    svg.setAttribute("viewBox", "0 0 24 24");
    svg.setAttribute("stroke-width", "1.5");
    svg.setAttribute("stroke", "currentColor");
    svg.style.width = "20px";
    svg.style.height = "20px";
    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("stroke-linecap", "round");
    path.setAttribute("stroke-linejoin", "round");
    path.setAttribute(
      "d",
      join ? "M12 8.25v-1.5m0 1.5c-1.355 0-2.697.056-4.024.166C6.845 8.51 6 9.473 6 10.608v2.513m6-4.871c1.355 0 2.697.056 4.024.166C17.155 8.51 18 9.473 18 10.608v2.513M15 8.25v-1.5m-6 1.5v-1.5m12 9.75-1.5.75a3.354 3.354 0 0 1-3 0 3.354 3.354 0 0 0-3 0 3.354 3.354 0 0 1-3 0 3.354 3.354 0 0 0-3 0 3.354 3.354 0 0 1-3 0L3 16.5m15-3.379a48.474 48.474 0 0 0-6-.371c-2.032 0-4.034.126-6 .371m12 0c.39.049.777.102 1.163.16 1.07.16 1.837 1.094 1.837 2.175v5.169c0 .621-.504 1.125-1.125 1.125H4.125A1.125 1.125 0 0 1 3 20.625v-5.17c0-1.08.768-2.014 1.837-2.174A47.78 47.78 0 0 1 6 13.12M12.265 3.11a.375.375 0 1 1-.53 0L12 2.845l.265.265Zm-3 0a.375.375 0 1 1-.53 0L9 2.845l.265.265Zm6 0a.375.375 0 1 1-.53 0L15 2.845l.265.265Z" : "M15.75 9V5.25A2.25 2.25 0 0 0 13.5 3h-6a2.25 2.25 0 0 0-2.25 2.25v13.5A2.25 2.25 0 0 0 7.5 21h6a2.25 2.25 0 0 0 2.25-2.25V15M12 9l-3 3m0 0 3 3m-3-3h12.75"
    );
    svg.appendChild(path);
    const txt = document.createElement("span");
    txt.style.margin = "0 20px";
    txt.textContent = children;
    btn.appendChild(svg);
    btn.appendChild(txt);
    btn.addEventListener("click", onClick);
    return btn;
  }
  __name(createButton, "createButton");
  function showRoomDialog(options) {
    var _a2;
    if (!document.getElementById("ytmp-room-dialog-style")) {
      const style = document.createElement("style");
      style.id = "ytmp-room-dialog-style";
      style.textContent = `
            dialog.ytmp-room-dialog {
                width: min(420px, calc(100vw - 32px));
                max-width: calc(100vw - 32px);
                max-height: calc(100vh - 32px);
                padding: 0;
                border: 0;
                border-radius: 12px;
                color: #f1f1f1;
                background: #282828;
                box-shadow: 0 12px 32px rgba(0, 0, 0, .45);
                font: 14px/1.45 Roboto, Arial, sans-serif;
            }
            dialog.ytmp-room-dialog::backdrop { background: rgba(0, 0, 0, .64); }
            .ytmp-room-dialog form { margin: 0; }
            .ytmp-room-dialog__header { padding: 24px 24px 8px; }
            .ytmp-room-dialog__title {
                margin: 0;
                color: #f1f1f1;
                font-size: 20px;
                font-weight: 500;
                line-height: 28px;
            }
            .ytmp-room-dialog__body {
                display: grid;
                gap: 18px;
                max-height: min(60vh, 480px);
                overflow-y: auto;
                padding: 16px 24px 24px;
            }
            .ytmp-room-dialog__row, .ytmp-room-dialog__field {
                display: grid;
                gap: 6px;
                min-width: 0;
            }
            .ytmp-room-dialog__label { color: #c6c6c6; font-size: 12px; }
            .ytmp-room-dialog__value {
                margin: 0;
                color: #f1f1f1;
                overflow-wrap: anywhere;
            }
            .ytmp-room-dialog__field label { color: #f1f1f1; }
            .ytmp-room-dialog__field input {
                box-sizing: border-box;
                width: 100%;
                min-height: 44px;
                padding: 0 12px;
                border: 1px solid #777;
                border-radius: 4px;
                outline: none;
                color: #f1f1f1;
                background: #121212;
                font: inherit;
            }
            .ytmp-room-dialog__field input::placeholder { color: #aaa; }
            .ytmp-room-dialog__field input:focus-visible,
            .ytmp-room-dialog__button:focus-visible {
                outline: 2px solid #3ea6ff;
                outline-offset: 2px;
            }
            .ytmp-room-dialog__field input:focus-visible { border-color: #3ea6ff; }
            .ytmp-room-dialog__actions {
                display: flex;
                justify-content: flex-end;
                gap: 8px;
                padding: 8px 16px 16px;
            }
            .ytmp-room-dialog__button {
                min-width: 64px;
                min-height: 40px;
                padding: 0 12px;
                border: 0;
                border-radius: 20px;
                color: #3ea6ff;
                background: transparent;
                font: 500 14px Roboto, Arial, sans-serif;
                cursor: pointer;
            }
            .ytmp-room-dialog__button:hover { background: rgba(62, 166, 255, .12); }
            @media (max-width: 480px) {
                dialog.ytmp-room-dialog { border-radius: 8px; }
                .ytmp-room-dialog__header { padding: 20px 20px 8px; }
                .ytmp-room-dialog__body { padding: 16px 20px 20px; }
            }
        `;
      document.head.append(style);
    }
    const dialog = document.createElement("dialog");
    dialog.className = "ytmp-room-dialog";
    dialog.setAttribute("aria-labelledby", "ytmp-room-dialog-title");
    const form = document.createElement("form");
    const header = document.createElement("header");
    header.className = "ytmp-room-dialog__header";
    const title = document.createElement("h2");
    title.id = "ytmp-room-dialog-title";
    title.className = "ytmp-room-dialog__title";
    title.textContent = options.title;
    header.append(title);
    form.append(header);
    const body = document.createElement("div");
    body.className = "ytmp-room-dialog__body";
    for (const row of options.rows ?? []) {
      const rowElement = document.createElement("div");
      rowElement.className = "ytmp-room-dialog__row";
      const label = document.createElement("span");
      label.className = "ytmp-room-dialog__label";
      label.textContent = row.label;
      const value2 = document.createElement("p");
      value2.className = "ytmp-room-dialog__value";
      value2.textContent = row.value;
      rowElement.append(label, value2);
      body.append(rowElement);
    }
    const inputs = /* @__PURE__ */ new Map();
    for (const field of options.fields ?? []) {
      const fieldElement = document.createElement("div");
      fieldElement.className = "ytmp-room-dialog__field";
      const input = document.createElement("input");
      input.id = `ytmp-room-${field.name}`;
      input.name = field.name;
      input.type = field.type ?? "text";
      input.value = field.value;
      input.required = true;
      input.addEventListener("input", () => {
        input.setCustomValidity(input.value.trim() ? "" : "Enter a value.");
      });
      const label = document.createElement("label");
      label.htmlFor = input.id;
      label.textContent = field.label;
      fieldElement.append(label, input);
      body.append(fieldElement);
      inputs.set(field.name, input);
    }
    form.append(body);
    const actions = document.createElement("footer");
    actions.className = "ytmp-room-dialog__actions";
    const closeButton = document.createElement("button");
    closeButton.className = "ytmp-room-dialog__button";
    closeButton.type = "button";
    closeButton.textContent = options.onSubmit ? "Cancel" : "Close";
    closeButton.autofocus = true;
    closeButton.addEventListener("click", () => dialog.close());
    actions.append(closeButton);
    if (options.onSubmit) {
      const submitButton = document.createElement("button");
      submitButton.className = "ytmp-room-dialog__button";
      submitButton.type = "submit";
      submitButton.textContent = options.submitLabel ?? "Save";
      actions.append(submitButton);
      form.addEventListener("submit", (event) => {
        var _a3;
        event.preventDefault();
        for (const input of inputs.values()) {
          input.setCustomValidity(
            input.value.trim() ? "" : "Enter a value."
          );
        }
        if (!form.reportValidity()) return;
        const values = Object.fromEntries(
          [...inputs].map(([name, input]) => [name, input.value.trim()])
        );
        dialog.close();
        (_a3 = options.onSubmit) == null ? void 0 : _a3.call(options, values);
      });
    }
    form.append(actions);
    dialog.append(form);
    dialog.addEventListener("click", (event) => {
      if (event.target === dialog) dialog.close();
    });
    dialog.addEventListener("close", () => dialog.remove(), { once: true });
    document.body.append(dialog);
    dialog.showModal();
    (_a2 = inputs.values().next().value) == null ? void 0 : _a2.focus();
  }
  __name(showRoomDialog, "showRoomDialog");
  function createButtonLeave(socket, config2) {
    setTimeout(async () => {
      var _a2;
      const btn = createButton({
        children: "Leave Room",
        onClick: /* @__PURE__ */ __name(async () => {
          console.log("Leaving room");
          const fp = await firstValueFrom(fp$);
          socket.emit("leave", {
            id: config2.roomId,
            fingerprint: fp
          });
          localStorage.removeItem("roomId");
          window.location.reload();
        }, "onClick"),
        join: false
      });
      (_a2 = document.querySelector(
        "[class='scroller scroller-on-hover style-scope ytmusic-guide-section-renderer']"
      )) == null ? void 0 : _a2.append(btn);
    }, 2e3);
  }
  __name(createButtonLeave, "createButtonLeave");
  function createButtonRoomInformation(socket) {
    setTimeout(() => {
      var _a2;
      const btn = createButton({
        children: "Room Information",
        join: false,
        onClick: /* @__PURE__ */ __name(() => {
          const config2 = getConfig();
          showRoomDialog({
            title: "Room Information",
            rows: [
              { label: "Room ID", value: config2.roomId || "Not joined" },
              {
                label: "Party URL",
                value: config2.partyUrl || DEFAULT_PARTY_URL
              },
              {
                label: "Connection",
                value: socket.connected ? "Connected" : "Disconnected"
              }
            ]
          });
        }, "onClick")
      });
      (_a2 = document.querySelector(
        "[class='scroller scroller-on-hover style-scope ytmusic-guide-section-renderer']"
      )) == null ? void 0 : _a2.append(btn);
    }, 2e3);
  }
  __name(createButtonRoomInformation, "createButtonRoomInformation");
  function createJoinButton() {
    setTimeout(async () => {
      var _a2;
      const btn = createButton({
        children: "Join Room",
        onClick: /* @__PURE__ */ __name(() => {
          const currentConfig = getConfig();
          showRoomDialog({
            title: "Join Room",
            fields: [
              {
                name: "roomId",
                label: "Room ID",
                value: currentConfig.roomId || ""
              },
              {
                name: "partyUrl",
                label: "Party URL",
                value: currentConfig.partyUrl || DEFAULT_PARTY_URL,
                type: "url"
              }
            ],
            submitLabel: "Join",
            onSubmit: /* @__PURE__ */ __name((values) => {
              localStorage.setItem("roomId", values.roomId);
              localStorage.setItem("partyUrl", values.partyUrl);
              window.location.reload();
            }, "onSubmit")
          });
        }, "onClick"),
        join: true
      });
      (_a2 = document.querySelector(
        "[class='scroller scroller-on-hover style-scope ytmusic-guide-section-renderer']"
      )) == null ? void 0 : _a2.append(btn);
    }, 2e3);
  }
  __name(createJoinButton, "createJoinButton");
  function getAppInstance() {
    const app = document.querySelector("ytmusic-app");
    return app;
  }
  __name(getAppInstance, "getAppInstance");
  function getQueueInstance() {
    const q = document.querySelector("#queue");
    globalThis.queue = q;
    setInterval(() => {
      globalThis.queue = document.querySelector(
        "#queue"
      );
    }, 300);
    return globalThis.queue;
  }
  __name(getQueueInstance, "getQueueInstance");
  function collectVideoIds(value2, ids = /* @__PURE__ */ new Set(), seen = /* @__PURE__ */ new WeakSet()) {
    if (!value2 || typeof value2 !== "object" || seen.has(value2)) return ids;
    seen.add(value2);
    if (Array.isArray(value2)) {
      value2.forEach((item) => collectVideoIds(item, ids, seen));
      return ids;
    }
    for (const [key, child] of Object.entries(value2)) {
      if (key === "videoId" && typeof child === "string") {
        ids.add(child);
      } else if (child && typeof child === "object") {
        collectVideoIds(child, ids, seen);
      }
    }
    return ids;
  }
  __name(collectVideoIds, "collectVideoIds");
  function getQueueVideoIds(queue, queueState) {
    const ids = collectVideoIds(queueState);
    queue == null ? void 0 : queue.querySelectorAll('a[href*="watch?v="]').forEach((anchor) => {
      try {
        const videoId = new URL(anchor.href, window.location.origin).searchParams.get("v");
        if (videoId) ids.add(videoId);
      } catch {
      }
    });
    return ids;
  }
  __name(getQueueVideoIds, "getQueueVideoIds");
  const queueItemsBeingAdded = /* @__PURE__ */ new Set();
  async function addQueue(videoIds) {
    const uniqueVideoIds = [...new Set(videoIds.filter(Boolean))];
    if (!uniqueVideoIds.length) return;
    const app = getAppInstance();
    const queue = getQueueInstance();
    const store = queue == null ? void 0 : queue.queue.store.store;
    if (!app || !store) return;
    const queueState = store.getState().queue;
    const existingVideoIds = getQueueVideoIds(queue, queueState);
    const videoIdsToAdd = uniqueVideoIds.filter((videoId) => {
      if (existingVideoIds.has(videoId) || queueItemsBeingAdded.has(videoId)) {
        return false;
      }
      queueItemsBeingAdded.add(videoId);
      return true;
    });
    if (!videoIdsToAdd.length) return;
    const payload = {
      queueContextParams: queueState.queueContextParams,
      queueInsertPosition: "INSERT_AT_END",
      videoIds: videoIdsToAdd
    };
    try {
      const result = await app.networkManager.fetch("music/get_queue", payload);
      if (result && typeof result === "object" && "queueDatas" in result && Array.isArray(result.queueDatas)) {
        const currentQueueState = store.getState().queue;
        const queueItems = currentQueueState.items ?? [];
        const currentVideoIds = getQueueVideoIds(queue, currentQueueState);
        const addedVideoIds = /* @__PURE__ */ new Set();
        const items = result.queueDatas.map(
          (it) => typeof it === "object" && it && "content" in it ? it.content : null
        ).filter((item) => Boolean(item)).filter((item) => {
          const itemVideoIds = collectVideoIds(item);
          const videoId = videoIdsToAdd.find((requestedId) => itemVideoIds.has(requestedId));
          if (!videoId) return true;
          if (currentVideoIds.has(videoId) || addedVideoIds.has(videoId)) {
            return false;
          }
          addedVideoIds.add(videoId);
          return true;
        });
        if (!items.length) return;
        queue == null ? void 0 : queue.dispatch({
          type: "ADD_ITEMS",
          payload: {
            nextQueueItemId: currentQueueState.nextQueueItemId,
            index: queueItems.length,
            items,
            shuffleEnabled: false,
            shouldAssignIds: true
          }
        });
        removeListParameter();
      }
    } finally {
      videoIdsToAdd.forEach((videoId) => queueItemsBeingAdded.delete(videoId));
    }
  }
  __name(addQueue, "addQueue");
  document.addEventListener("DOMContentLoaded", async () => {
    const config2 = getConfig();
    const socket = lookup(config2.partyUrl || DEFAULT_PARTY_URL);
    const ROOM_ID = config2.roomId;
    createButtonRoomInformation(socket);
    if (config2.partyUrl && config2.roomId) {
      createButtonLeave(socket, config2);
    } else {
      createJoinButton();
    }
    let queues = [];
    let observedVideo = null;
    let lastPublishedPlaybackSnapshot = "";
    let playbackSyncTimer;
    const publishPlaybackState = /* @__PURE__ */ __name((state, force = false) => {
      const currentlyPlaying = getNowPlaying();
      const snapshot = JSON.stringify({ state, currentlyPlaying });
      if (!force && snapshot === lastPublishedPlaybackSnapshot) return;
      lastPublishedPlaybackSnapshot = snapshot;
      socket.emit("playbackState", { roomId: ROOM_ID, state, currentlyPlaying });
    }, "publishPlaybackState");
    const readPlaybackState = /* @__PURE__ */ __name((video) => {
      const state = getVideoPlaybackState(video);
      if (state === "playing") removeListParameter();
      publishPlaybackState(state);
    }, "readPlaybackState");
    const observePlaybackState = /* @__PURE__ */ __name((force = false) => {
      const video = document.querySelector(
        "#movie_player > div.html5-video-container > video"
      );
      if (!video) {
        observedVideo = null;
        publishPlaybackState("standby", force);
        return;
      }
      if (video !== observedVideo) {
        observedVideo = video;
        ["play", "playing", "pause", "ended", "emptied", "loadstart"].forEach(
          (eventName) => video.addEventListener(eventName, () => readPlaybackState(video))
        );
      }
      const state = getVideoPlaybackState(video);
      if (state === "playing") removeListParameter();
      publishPlaybackState(state, force);
    }, "observePlaybackState");
    socket.on("joined", async (data) => {
      queues = data;
      observePlaybackState(true);
      if (!playbackSyncTimer) {
        playbackSyncTimer = window.setInterval(() => observePlaybackState(), 1e3);
      }
      if (data[0] && getPlaybackState().state === "standby") {
        play(data[0]);
      }
      setTimeout(async () => {
        await addQueue(data.map((q) => q.url));
      }, 1e3);
    });
    socket.on("leave", async () => {
      localStorage.removeItem("roomId");
      window.location.reload();
    });
    const join$ = from(
      axios.get("https://ifconfig.me/all.json", {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json"
        }
      })
    ).pipe(
      switchMap((res) => {
        return new Promise(
          (resolve, reject) => {
            var _a2, _b2;
            try {
              const info = detect();
              const browser = [
                (((_a2 = info == null ? void 0 : info.name) == null ? void 0 : _a2.slice(0, 1).toUpperCase()) || "") + (((_b2 = info == null ? void 0 : info.name) == null ? void 0 : _b2.slice(1)) || ""),
                info == null ? void 0 : info.os
                // Mac OS, Windows
              ];
              const accountButton = document.querySelector(
                '[aria-label="Open avatar menu"]'
              );
              if (!accountButton) {
                resolve({
                  id: config2.roomId || "",
                  browser: browser.filter(Boolean).join(" ") || "",
                  ip: res.data.ip_addr || ""
                });
                return;
              }
              accountButton.click();
              const querySelector = document.querySelector(
                '[class="style-scope tp-yt-iron-dropdown"]'
              );
              if (querySelector) {
                querySelector.style.display = "hidden";
              }
              accountButton.click();
              if (querySelector) {
                querySelector.style.display = "inherit";
              }
              setTimeout(() => {
                accountButton.click();
                const user = document.querySelector("#account-name");
                if (!user) {
                  resolve({
                    id: config2.roomId || "",
                    browser: browser.filter(Boolean).join(" ") || "",
                    ip: res.data.ip_addr || ""
                  });
                  return;
                }
                browser.unshift(user == null ? void 0 : user.textContent);
                resolve({
                  id: config2.roomId || "",
                  browser: browser.filter(Boolean).join(" ") || "",
                  ip: res.data.ip_addr || ""
                });
              }, 300);
            } catch (error) {
              console.log(error);
              reject(error);
            }
          }
        );
      }),
      switchMap(async (data) => {
        const fp = await firstValueFrom(fp$);
        return {
          ...data,
          fingerprint: fp
        };
      }),
      tap(async (data) => {
        if (data.id) {
          socket.emit("join", data);
        }
      })
    );
    const playbackObserver = new MutationObserver((mutations) => {
      mutations.forEach((mutation, i) => {
        if (mutation.type === "childList" && i == 0 && mutation.target.textContent) {
          setTimeout(() => {
            const playback = getPlaybackState();
            observePlaybackState();
            const videoId = getVideoId();
            socket.emit("started", {
              roomId: ROOM_ID,
              videoId
            });
            socket.emit("notify", {
              message: `Now playing: ___"${playback.song}"___ by ${playback.artist} 🎧`,
              roomId: ROOM_ID
            });
          }, 1e3);
        }
      });
    });
    const titleElement = document.querySelector(".title.ytmusic-player-bar");
    if (titleElement) {
      playbackObserver.observe(titleElement, {
        childList: true,
        subtree: true
      });
    }
    socket.on("connect", async () => {
      console.log("Connected to WebSocket server with ID:", socket.id);
      join$.subscribe();
    });
    socket.on("play", () => {
      observePlaybackState();
      const playback = getPlaybackState();
      if (playback.state == "standby" && queues[0]) {
        play(queues[0]);
        return;
      }
      if (playback.state == "standby" && !queues[0]) {
        socket.emit("notify", {
          message: `🚫 No tracks in the queue right now.`,
          roomId: ROOM_ID
        });
        return;
      }
      play();
      socket.emit("notify", {
        message: `Now playing: ___"${playback.song}"___ by ${playback.artist} 🎧`,
        roomId: ROOM_ID
      });
    });
    socket.on("pause", () => {
      pause();
      const playback = getPlaybackState();
      socket.emit("notify", {
        message: `⏸️ ___${playback.song}___ - ${playback.artist} is now paused`,
        roomId: ROOM_ID
      });
    });
    socket.on("next", () => {
      next();
    });
    socket.on("prev", () => {
      prev();
    });
    socket.on("volumeUp", () => {
      const currentVolume = volumeUp();
      socket.emit("notify", {
        message: `🔊 Volume increased. Current volume: ${currentVolume}`,
        roomId: ROOM_ID
      });
    });
    socket.on("volumeDown", () => {
      const currentVolume = volumeDown();
      socket.emit("notify", {
        message: `🔊 Volume decreased. Current volume: ${currentVolume}`,
        roomId: ROOM_ID
      });
    });
    socket.on("mute", () => {
      mute();
      socket.emit("notify", {
        message: "🤫 Shhh... we're on mute. Enjoy the silence (for now)!",
        roomId: ROOM_ID
      });
    });
    socket.on("unmute", () => {
      mute();
      socket.emit("notify", {
        message: "🎶 We're back! Audio unmuted—let the music play!",
        roomId: ROOM_ID
      });
    });
    socket.on("lyrics", async () => {
      const txt = await lyrics() || "🤷‍♀️ No lyrics this time—guess we're freestyling!";
      socket.emit("notify", {
        message: txt,
        roomId: ROOM_ID
      });
    });
    socket.on("resume", () => {
      resume();
    });
    socket.on("addToQueue", async ({ videoId }) => {
      const playback = getPlaybackState();
      console.log("addToQueue", videoId);
      if (playback.state == "standby") {
        queues.push({
          id: crypto.randomUUID(),
          url: videoId
        });
        return;
      }
      await addQueue([videoId]);
    });
    socket.on("disconnect", () => {
      console.log("Disconnected from WebSocket server");
    });
  });
});
